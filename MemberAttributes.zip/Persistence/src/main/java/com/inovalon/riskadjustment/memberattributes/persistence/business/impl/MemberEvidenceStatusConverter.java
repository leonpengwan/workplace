package com.inovalon.riskadjustment.memberattributes.persistence.business.impl;

import com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces.ObjectConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberEvidenceStatusAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Service
public class MemberEvidenceStatusConverter implements ObjectConverter {
    /**
     * this method converts avro to service model
     * @param workerProcessMessageAvro
     * @param workerProcessMessage
     * @throws Exception
     */
    public void convertObject(WorkerProcessMessageAvro workerProcessMessageAvro, WorkerProcessMessage workerProcessMessage) throws Exception{
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<MemberEvidenceStatus>();
        List<MemberEvidenceStatusAvro> memberEvidenceStatusAvros = workerProcessMessageAvro.getMemberEvidenceStatuses();

        for(MemberEvidenceStatusAvro memberEvidenceStatusAvro : memberEvidenceStatusAvros){
            MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
            memberEvidenceStatus.setMemberAttributesRunId(memberEvidenceStatusAvro.getMemberAttributesRunId());
            memberEvidenceStatus.setMemberEvidenceId(memberEvidenceStatusAvro.getMemberEvidenceId());
            memberEvidenceStatus.setGapSetDetailId(memberEvidenceStatusAvro.getGapSetDetailId());
            memberEvidenceStatus.setMemberId(memberEvidenceStatusAvro.getMemberId());
            memberEvidenceStatus.setPersonId(memberEvidenceStatusAvro.getPersonId() == null? null : memberEvidenceStatusAvro.getPersonId().toString());
            memberEvidenceStatus.setPractitionerId(memberEvidenceStatusAvro.getPractitionerId());
            memberEvidenceStatus.setEncounterId(memberEvidenceStatusAvro.getEncounterId());
            memberEvidenceStatus.setEncounterServiceDate(memberEvidenceStatusAvro.getEncounterServiceDate() == null? null : Timestamp.valueOf(memberEvidenceStatusAvro.getEncounterServiceDate().toString()));
            memberEvidenceStatus.setHccCode(memberEvidenceStatusAvro.getHccCode() == null? null : memberEvidenceStatusAvro.getHccCode().toString());
            memberEvidenceStatus.setOriginalHccCode(memberEvidenceStatusAvro.getOriginalHccCode() == null? null : memberEvidenceStatusAvro.getOriginalHccCode().toString());
            memberEvidenceStatus.setGapConfidenceValue(memberEvidenceStatusAvro.getGapConfidenceValue());
            memberEvidenceStatus.setGapConfidenceLevel(memberEvidenceStatusAvro.getGapConfidenceLevel() == null? null : memberEvidenceStatusAvro.getGapConfidenceLevel().toString());
            memberEvidenceStatus.setGapType(memberEvidenceStatusAvro.getGapType() == null? null : memberEvidenceStatusAvro.getGapType().toString());
            memberEvidenceStatus.setExclusionId(memberEvidenceStatusAvro.getExclusionId());
            memberEvidenceStatus.setMeasureKey(memberEvidenceStatusAvro.getMeasureKey() == null ? null : memberEvidenceStatusAvro.getMeasureKey().toString());
            memberEvidenceStatus.setSaGapValue(memberEvidenceStatusAvro.getSaGapValue());
            memberEvidenceStatuses.add(memberEvidenceStatus);
        }
        workerProcessMessage.setMemberEvidenceStatuses(memberEvidenceStatuses);
    }
}

package com.inovalon.riskadjustment.memberattributes.persistence.util;


public enum PersistenceModelEnum {
    MemberAttributes,
    MemberEvidenceStatus,
    MemberValidation,
    PractitionerValiation;
}

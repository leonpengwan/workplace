package com.inovalon.riskadjustment.memberattributes.persistence.business.impl;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces.ObjectConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.PractitionerValidationAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.PractitionerValidation;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PractitionerValidationConverter implements ObjectConverter {
    @Autowired
    private LogWriter logWriter;
    /**
     * this method converts avro to service model
     * @param workerProcessMessageAvro
     * @param workerProcessMessage
     * @throws Exception
     */
    @LogAfterEvents
    public void convertObject(WorkerProcessMessageAvro workerProcessMessageAvro, WorkerProcessMessage workerProcessMessage) throws Exception{
        PractitionerValidation practitionerValidation = new PractitionerValidation();
        PractitionerValidationAvro practitionerValidationAvro = workerProcessMessageAvro.getPractitionerValidation();

        practitionerValidation.setMemberAttributesRunId(practitionerValidationAvro.getMemberAttributesRunId());
        practitionerValidation.setPractitionerId(practitionerValidationAvro.getPractitionerId());
        practitionerValidation.setInvalidName(practitionerValidationAvro.getInvalidName());
        practitionerValidation.setInvalidAddress(practitionerValidationAvro.getInvalidAddress());
        practitionerValidation.setInvalidPhone(practitionerValidationAvro.getInvalidPhone());
        practitionerValidation.setInvalidFax(practitionerValidationAvro.getInvalidFax());

        workerProcessMessage.setPractitionerValidation(practitionerValidation);

    }
}

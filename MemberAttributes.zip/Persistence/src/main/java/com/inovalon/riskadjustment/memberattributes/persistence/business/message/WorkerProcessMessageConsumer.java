package com.inovalon.riskadjustment.memberattributes.persistence.business.message;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.persistence.business.Manager;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.output.PersistenceMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import com.inovalon.riskadjustment.shared.messagebus.consumer.KafkaMessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.enums.MessageAcknowledgment;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.model.MessageMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class WorkerProcessMessageConsumer implements MessageBusListener<WorkerProcessMessageAvro> {
    @Autowired
    private KafkaMessageBusListener<WorkerProcessMessageAvro> kafkaMessageBusListener;

    @PostConstruct
    public void Initialize(){
        kafkaMessageBusListener.subscribe(this, WorkerProcessMessageAvro.class);
    }

    @Autowired private Manager manager;

    @Autowired private PersistenceMessageProducer persistenceMessageProducer;
    @Autowired
    private LogWriter logWriter;

    @Override
    public MessageAcknowledgment OnQueueMessageReceived(WorkerProcessMessageAvro workerProcessMessageAvro, MessageMetadata messageMetadata) {

        logWriter.info("Received message : " + workerProcessMessageAvro);

        if(workerProcessMessageAvro != null){
            try{
                boolean persistenceReturn = manager.manage(workerProcessMessageAvro);
                // prepare output message
                PersistenceMessageAvro persistenceMessageAvro = new PersistenceMessageAvro();
                persistenceMessageAvro.setRunProfielId(workerProcessMessageAvro.getRunProfileId());
                persistenceMessageAvro.setMemberAttributesRunId(workerProcessMessageAvro.getMemberAttributesRunId());
                persistenceMessageAvro.setMemberId(workerProcessMessageAvro.getMemberAttributes().getMemberId());

                if(persistenceReturn) {
                    persistenceMessageAvro.setMessageStatus(true);
                }else{
                    persistenceMessageAvro.setMessageStatus(false);
                }
                // push output message
                boolean status = persistenceMessageProducer.producePersistenceMessage(persistenceMessageAvro);
                logWriter.info("Pushed MemberId: " + persistenceMessageAvro.getMemberId() + " into aggregator");
                if(status) {
                    return MessageAcknowledgment.Commit;
                }else {
                    logWriter.info("MemberAttributesPersistence: push message failed");
                    return MessageAcknowledgment.DoNotCommit;
                }

            }catch (Exception ex){
                logWriter.error("MemberAttributesPersistence: kafka queue consuemer exception--" + ex.getMessage());
                return MessageAcknowledgment.DoNotCommit;
            }
        }
        else{
            logWriter.info("MemberAttributesPersistence: kafka queue consumed an null avro message");
        }
        return MessageAcknowledgment.Unknown;
    }
}

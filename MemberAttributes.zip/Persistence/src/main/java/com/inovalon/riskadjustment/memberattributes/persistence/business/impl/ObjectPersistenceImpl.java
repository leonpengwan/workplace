package com.inovalon.riskadjustment.memberattributes.persistence.business.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces.ObjectPersistence;
import com.inovalon.riskadjustment.memberattributes.persistence.configuration.PersistenceConfiguration;
import com.inovalon.riskadjustment.memberattributes.persistence.util.PersistenceModelEnum;
import com.inovalon.riskadjustment.memberattributes.persistence.util.PersistenceStatusLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ObjectPersistenceImpl implements ObjectPersistence {
    @Autowired private RestTemplate restTemplate;
    @Autowired private PersistenceConfiguration persistenceConfiguration;
    @Autowired private HttpHeaders httpHeaders;
    @Autowired private ObjectMapper objectMapper;
    @Autowired
    private LogWriter logWriter;

    /**
     * this method persist object to db thru DataAccess
     * @param object
     * @param url
     * @param persistenceModelEnum
     * @return
     * @throws Exception
     */
    @LogBeforeEvents
    @LogAfterEvents
    public boolean persistModel(Object object, String url, PersistenceModelEnum persistenceModelEnum) throws Exception{

        try {
            String json = objectMapper.writeValueAsString(object);
            url = persistenceConfiguration.getRiskAnalyticsResultBaseUrl() + url;
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> httpEntity = json == null ? new HttpEntity<String>(httpHeaders) : new HttpEntity<String>(json, httpHeaders);
            ResponseEntity<Integer> responseEntity = restTemplate.postForEntity(url, httpEntity, Integer.class);
            Integer status = responseEntity.getBody();
            PersistenceStatusLogger.logStatus(status, persistenceModelEnum);
          }catch(Exception ex){
            logWriter.error("MemberAttributesWorkerProcess: kafka queue consuemer exception--" + ex.getMessage());
            return false;
        }
        return true;
    }
}

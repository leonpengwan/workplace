package com.inovalon.riskadjustment.memberattributes.persistence.util;



public class PersistenceStatusLogger {
    /**
     * this method logs different status returned from DataAccess
     * @param status
     * @param persistenceModelEnum
     */
    public static void logStatus(Integer status, PersistenceModelEnum persistenceModelEnum){
        switch (status) {
            case (0):
                System.out.println("Persistence succeeded" );
                break;
            case (1):
                System.out.println("Posted empty json body ");
                break;
            case (2):
                System.out.println( persistenceModelEnum + " Table Integrity Violation: Unique key");
                break;
            case (99):
                System.out.println("Persistence failed - for more information, refer data access log");
                break;
            default:
                System.out.print("Unknown error!");
        }
    }
}

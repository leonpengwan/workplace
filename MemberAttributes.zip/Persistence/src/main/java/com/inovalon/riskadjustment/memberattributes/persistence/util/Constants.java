package com.inovalon.riskadjustment.memberattributes.persistence.util;


public class Constants {
    // Riak Analytics model related constants
    public static final String SAVE_MEMBER_ATTRIBUTES = "/risk-analytics/intervention-result/member-attributes";
    public static final String SAVE_MEMBER_EVIDENCE_STATUS = "/risk-analytics/intervention-result/member-evidence-statuses";
    public static final String SAVE_MEMBER_VALIDATION = "/risk-analytics/intervention-result/member-validation";
    public static final String SAVE_PRACTITIONER_VALIDATION = "/risk-analytics/intervention-result/practitioner-validation";

}

package com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces;


import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;

public interface ObjectConverter {
    void convertObject(WorkerProcessMessageAvro workerProcessMessageAvro, WorkerProcessMessage workerProcessMessage) throws Exception;
}

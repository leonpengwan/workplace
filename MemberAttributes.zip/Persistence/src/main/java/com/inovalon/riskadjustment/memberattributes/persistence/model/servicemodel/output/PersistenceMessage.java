package com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.output;


import com.inovalon.riskadjustment.shared.messagebus.model.MessageEnvelope;

public class PersistenceMessage extends MessageEnvelope {
    private long runProfielId;
    private int MemberAttributesRunId;
    private int memberId;

    public PersistenceMessage() {
    }

    public PersistenceMessage(long runProfielId, int memberAttributesRunId, int memberId) {
        this.runProfielId = runProfielId;
        MemberAttributesRunId = memberAttributesRunId;
        this.memberId = memberId;
    }

    public long getRunProfielId() {
        return runProfielId;
    }

    public void setRunProfielId(long runProfielId) {
        this.runProfielId = runProfielId;
    }

    public int getMemberAttributesRunId() {
        return MemberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        MemberAttributesRunId = memberAttributesRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
}

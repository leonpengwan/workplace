package com.inovalon.riskadjustment.memberattributes.persistence.business.message;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.persistence.configuration.PersistenceConfiguration;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.output.PersistenceMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class PersistenceMessageProducer {
    @Autowired private PersistenceConfiguration persistenceConfiguration;
    @Autowired
    private LogWriter logWriter;

    @Autowired @Qualifier("messageBusPublisher")
    private MessageBusPublisher<PersistenceMessageAvro> messageBusPublisher;

    public boolean producePersistenceMessage(PersistenceMessageAvro persistenceMessageAvro) throws Exception{
        try{
            logWriter.info("publishMessage to topic: " + persistenceConfiguration.getKafkaProducerTopic());
            messageBusPublisher.publishMessage(persistenceConfiguration.getKafkaProducerTopic(), persistenceMessageAvro);
        }catch (Exception ex){
            logWriter.error("MemberAttributesWorkerProcess: kafka queue consuemer exception--" + ex.getMessage());
            return false;
        }
        return true;
    }
}

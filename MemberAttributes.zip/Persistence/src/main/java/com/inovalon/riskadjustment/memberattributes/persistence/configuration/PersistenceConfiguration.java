package com.inovalon.riskadjustment.memberattributes.persistence.configuration;

import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.output.PersistenceMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import com.inovalon.riskadjustment.shared.messagebus.producer.KafkaMessageBusPublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.context.config.annotation.RefreshScope;

@Configuration
@RefreshScope
public class PersistenceConfiguration {

    @Value("${inovalon.risk-adjustment.data-services.results-url}")
    private  String riskAnalyticsResultBaseUrl;
    @Value("${spring.kafka.producer.topic}")
    private String kafkaProducerTopic;

    public  String getRiskAnalyticsResultBaseUrl() {
        return riskAnalyticsResultBaseUrl;
    }

    @Override
    public String toString() {
        return "PersistenceConfiguration{" +
                "riskAnalyticsResultBaseUrl='" + riskAnalyticsResultBaseUrl + '\'' +
                ", kafkaProducerTopic='" + kafkaProducerTopic + '\'' +
                '}';
    }

    public String getKafkaProducerTopic() {
        return kafkaProducerTopic;
    }

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
    @Bean
    public HttpHeaders httpHeaders() { return new HttpHeaders();}
    @Bean
    public MessageBusPublisher<PersistenceMessageAvro> messageBusPublisher(){
        return new KafkaMessageBusPublisher<PersistenceMessageAvro>(PersistenceMessageAvro.class);
    }
    @Bean
    public WorkerProcessMessage workerProcessMessage(){
        return new WorkerProcessMessage();
    }
}

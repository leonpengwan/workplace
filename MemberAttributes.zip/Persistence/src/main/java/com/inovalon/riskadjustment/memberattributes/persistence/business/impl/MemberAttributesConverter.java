package com.inovalon.riskadjustment.memberattributes.persistence.business.impl;

import com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces.ObjectConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberAttributesAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberAttributes;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberAttributesConverter implements ObjectConverter{
      /**
     * this method converts avro to service model
     * @param workerProcessMessageAvro
     * @param workerProcessMessage
     * @throws Exception
     */

    public void convertObject(WorkerProcessMessageAvro workerProcessMessageAvro, WorkerProcessMessage workerProcessMessage) throws Exception{
        MemberAttributes memberAttributes = new MemberAttributes();
        MemberAttributesAvro memberAttributesAvro = workerProcessMessageAvro.getMemberAttributes();

        //memberAttributes.setMemberAttributesId(memberAttributesAvro.getMemberAttributesId());
        memberAttributes.setMemberAttributesRunId(memberAttributesAvro.getMemberAttributesRunId());
        memberAttributes.setMemberId(memberAttributesAvro.getMemberId());
        memberAttributes.setPersonId(memberAttributesAvro.getPersonId() == null? "": memberAttributesAvro.getPersonId().toString());
        memberAttributes.setMissingProfile(memberAttributesAvro.getMissingProfile());
        memberAttributes.setNewEnrollee(memberAttributesAvro.getNewEnrollee());
        memberAttributes.setTermed(memberAttributesAvro.getTermed());
        memberAttributes.setMissingLastName(memberAttributesAvro.getMissingLastName());
        memberAttributes.setMissingFirstName(memberAttributesAvro.getMissingFirstName());
        memberAttributes.setMissingDateOfBirth(memberAttributesAvro.getMissingDateOfBirth());
        memberAttributes.setCurrentlyEnrolled(memberAttributesAvro.getCurrentlyEnrolled());
        memberAttributes.setDeceased(memberAttributesAvro.getDeceased());
        memberAttributes.setHospice(memberAttributesAvro.getHospice());
        memberAttributes.setHomebound(memberAttributesAvro.getHomebound());
        memberAttributes.setAgeGroup(memberAttributesAvro.getAgeGroup() == null? "" : memberAttributesAvro.getAgeGroup().toString());
        memberAttributes.setAgeExclusionLessThan3(memberAttributesAvro.getAgeExclusionLessThan3());
        memberAttributes.setAge(memberAttributesAvro.getAge());
        memberAttributes.setAgeGroupId(memberAttributesAvro.getAgeGroupId());
        memberAttributes.setMetalLevel(memberAttributesAvro.getMetalLevel() == null ? "": memberAttributesAvro.getMetalLevel().toString());
        memberAttributes.setGroupPlanType(memberAttributesAvro.getGroupPlanType() == null? "" : memberAttributesAvro.getGroupPlanType().toString());
        memberAttributes.setState(memberAttributesAvro.getState() == null? "" : memberAttributesAvro.getState().toString());
        memberAttributes.setAttributedPractitionerId(memberAttributesAvro.getAttributedPractitionerId());
        memberAttributes.setWinningEnrollmentId(memberAttributesAvro.getWinningEnrollmentId());
        memberAttributes.setNoPreviousIntervention(memberAttributesAvro.getNoPreviousIntervention());
        memberAttributes.setPastEfIntervention(memberAttributesAvro.getPastEfIntervention());
        memberAttributes.setPastSmeIntervention(memberAttributesAvro.getPastSmeIntervention());
        memberAttributes.setPcpVisit(memberAttributesAvro.getPcpVisit());
        memberAttributes.setTotalReachAttempts(memberAttributesAvro.getTotalReachAttempts());
        memberAttributes.setSuccessfulReachAttempts(memberAttributesAvro.getSuccessfulReachAttempts());
        memberAttributes.setNotReached(memberAttributesAvro.getNotReached());
        memberAttributes.setReachRateCategoryId(memberAttributesAvro.getReachRateCategoryId());
        memberAttributes.setCompletedEfSoapNote(memberAttributesAvro.getCompletedEfSoapNote());
        memberAttributes.setInstitutional(memberAttributesAvro.getInstitutional());

        workerProcessMessage.setMemberAttributes(memberAttributes);
    }
}

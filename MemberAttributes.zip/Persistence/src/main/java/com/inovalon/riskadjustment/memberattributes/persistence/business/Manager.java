package com.inovalon.riskadjustment.memberattributes.persistence.business;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.*;
import com.inovalon.riskadjustment.memberattributes.persistence.configuration.PersistenceConfiguration;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import com.inovalon.riskadjustment.memberattributes.persistence.util.Constants;
import com.inovalon.riskadjustment.memberattributes.persistence.util.PersistenceModelEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Manager {
    @Autowired private MemberAttributesConverter memberAttributesConverter;
    @Autowired private MemberEvidenceStatusConverter memberEvidenceStatusConverter;
    @Autowired private MemberValidationConverter memberValidationConverter;
    @Autowired private PractitionerValidationConverter practitionerValidationConverter;
    @Autowired private ObjectPersistenceImpl objectPersistence;
    @Autowired private WorkerProcessMessage workerProcessMessage;

    /**
     * this method manages work flow of the microservice
     * @param workerProcessMessageAvro
     * @throws Exception
     */
    public boolean manage(WorkerProcessMessageAvro workerProcessMessageAvro) throws Exception{

        boolean ret = true;

        // member attributes model
        if(workerProcessMessageAvro.getMemberAttributes() != null) {
            memberAttributesConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);
            boolean persistenceReturn = objectPersistence.persistModel(workerProcessMessage.getMemberAttributes(),
                    Constants.SAVE_MEMBER_ATTRIBUTES,
                    PersistenceModelEnum.MemberAttributes);
            if(!persistenceReturn) {
                ret = persistenceReturn;
            }
        }
        // member evidence status model
        if(workerProcessMessageAvro.getMemberEvidenceStatuses() != null && workerProcessMessageAvro.getMemberEvidenceStatuses().size() != 0) {
            memberEvidenceStatusConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);
            boolean persistenceReturn = objectPersistence.persistModel(workerProcessMessage.getMemberEvidenceStatuses(),
                    Constants.SAVE_MEMBER_EVIDENCE_STATUS,
                    PersistenceModelEnum.MemberEvidenceStatus);
            if(!persistenceReturn) {
                ret = persistenceReturn;
            }
        }
        // Member Validation
        if(workerProcessMessageAvro.getMemberValidation() != null) {
            memberValidationConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);
            boolean persistenceReturn = objectPersistence.persistModel(workerProcessMessage.getMemberValidation(),
                    Constants.SAVE_MEMBER_VALIDATION,
                    PersistenceModelEnum.MemberValidation);
            if(!persistenceReturn) {
                ret = persistenceReturn;
            }
        }
        // Practitioner Validation
        if(workerProcessMessageAvro.getPractitionerValidation() != null) {
            practitionerValidationConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);
            boolean persistenceReturn = objectPersistence.persistModel(workerProcessMessage.getPractitionerValidation(),
                    Constants.SAVE_PRACTITIONER_VALIDATION,
                    PersistenceModelEnum.PractitionerValiation);
            if(!persistenceReturn) {
                ret = persistenceReturn;
            }
        }

        return ret;
    }
}

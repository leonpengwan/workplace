package com.inovalon.riskadjustment.memberattributes.persistence.business.impl;

import com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces.ObjectConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberValidationAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberValidationConverter implements ObjectConverter{
    /**
     * this method converts avro to service model
     * @param workerProcessMessageAvro
     * @param workerProcessMessage
     * @throws Exception
     */
    public void convertObject(WorkerProcessMessageAvro workerProcessMessageAvro, WorkerProcessMessage workerProcessMessage) throws Exception{
        MemberValidation memberValidation = new MemberValidation();
        MemberValidationAvro memberValidationAvro = workerProcessMessageAvro.getMemberValidation();

        memberValidation.setMemberAttributesRunId(memberValidationAvro.getMemberAttributesRunId());
        memberValidation.setMemberId(memberValidationAvro.getMemberId());
        memberValidation.setPersonId( memberValidationAvro.getPersonId() == null? null : memberValidationAvro.getPersonId().toString());
        memberValidation.setInValidAddress(memberValidationAvro.getInValidAddress());
        memberValidation.setInValidPhone(memberValidationAvro.getInValidPhone());

        workerProcessMessage.setMemberValidation(memberValidation);
    }
}

package com.inovalon.riskadjustment.memberattributes.persistence;

import com.inovalon.riskadjustment.memberattributes.persistence.configuration.PersistenceConfiguration;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.output.PersistenceMessage;
import com.inovalon.riskadjustment.shared.messagebus.common.Utilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan(basePackages = {"com.inovalon.riskadjustment"})
public class PersistenceMain {

    @Autowired
    private PersistenceConfiguration persistenceConfiguration;

    public static void main(String[] args) {
        SpringApplication.run(PersistenceMain.class, args);

        //System.out.println(Utilities.getAvroSchema(new WorkerProcessMessage()));
        //System.out.println(Utilities.getAvroSchema(new PersistenceMessage()));
    }

    @PostConstruct
    private void initialize() {

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++++++ SERVICE STARTED  ++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Config-test:" + persistenceConfiguration.toString() );
    }
}

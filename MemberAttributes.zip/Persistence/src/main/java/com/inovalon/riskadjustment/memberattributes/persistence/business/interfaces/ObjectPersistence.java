package com.inovalon.riskadjustment.memberattributes.persistence.business.interfaces;


import com.inovalon.riskadjustment.memberattributes.persistence.util.PersistenceModelEnum;

public interface ObjectPersistence {
    boolean persistModel(Object object, String url, PersistenceModelEnum persistenceModelEnum) throws Exception;
}

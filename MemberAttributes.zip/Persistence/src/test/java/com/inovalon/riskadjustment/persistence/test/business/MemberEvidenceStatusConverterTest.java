package com.inovalon.riskadjustment.persistence.test.business;

import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.MemberEvidenceStatusConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberEvidenceStatusAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class MemberEvidenceStatusConverterTest {
    private static int ID;
    private WorkerProcessMessageAvro workerProcessMessageAvro;
    private WorkerProcessMessage workerProcessMessage;
    private MemberEvidenceStatusAvro memberEvidenceStatusAvro;
    private List<MemberEvidenceStatusAvro> memberEvidenceStatusAvros;
    @InjectMocks private MemberEvidenceStatusConverter memberEvidenceStatusConverter;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        this.ID = 1;
        workerProcessMessageAvro = new WorkerProcessMessageAvro();
        memberEvidenceStatusAvro = new MemberEvidenceStatusAvro();
        memberEvidenceStatusAvros = new ArrayList<MemberEvidenceStatusAvro>();
        workerProcessMessage = new WorkerProcessMessage();
        memberEvidenceStatusAvro.setMemberAttributesRunId(ID);
        memberEvidenceStatusAvro.setMemberEvidenceId(new Long(ID));
        memberEvidenceStatusAvro.setGapSetDetailId(ID);
        memberEvidenceStatusAvro.setMemberId(ID);
        memberEvidenceStatusAvro.setPersonId(String.valueOf(ID));
        memberEvidenceStatusAvro.setPractitionerId(ID);
        memberEvidenceStatusAvro.setEncounterId(ID);
        memberEvidenceStatusAvro.setEncounterServiceDate("2017-12-09 12:12:12.0");
        memberEvidenceStatusAvro.setHccCode(String.valueOf(ID));
        memberEvidenceStatusAvro.setOriginalHccCode(String.valueOf(ID));
        memberEvidenceStatusAvro.setGapConfidenceValue(3223.1);
        memberEvidenceStatusAvro.setGapConfidenceLevel("High");
        memberEvidenceStatusAvro.setGapType("CEDI");
        memberEvidenceStatusAvro.setExclusionId(ID);
        memberEvidenceStatusAvros.add(memberEvidenceStatusAvro);
        workerProcessMessageAvro.setMemberEvidenceStatuses(memberEvidenceStatusAvros);
    }

    @Test
    public void convertObjectTest() throws Exception{
        this.memberEvidenceStatusConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);

        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().size() == 1);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0) instanceof MemberEvidenceStatus);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getMemberEvidenceId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getGapSetDetailId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getMemberId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getPersonId().equals(String.valueOf(ID)));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getPractitionerId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getEncounterId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getEncounterServiceDate().toString().equals("2017-12-09 12:12:12.0"));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getHccCode().equals(String.valueOf(ID)));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getOriginalHccCode().equals(String.valueOf(ID)));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getGapConfidenceValue() == 3223.1);
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getGapConfidenceLevel().equals("High"));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getGapType().equals("CEDI"));
        Assert.assertTrue(workerProcessMessage.getMemberEvidenceStatuses().get(0).getExclusionId() == ID);


    }
}

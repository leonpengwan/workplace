package com.inovalon.riskadjustment.persistence.test.model.avro;

import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberAttributesAvro;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MemberAttributesAvroTest {
    @Mock
    private MemberAttributesAvro memberAttributesAvro;

    private static int ID;

    @Before
    public void setUp(){
        ID = 1;
    }

    @Test
    public void testEmptyConstructorAndSetterGetter(){
        memberAttributesAvro = new MemberAttributesAvro();

        Assert.assertTrue(memberAttributesAvro instanceof  MemberAttributesAvro);

        memberAttributesAvro.setMemberAttributesId(ID);
        memberAttributesAvro.setMemberAttributesRunId(ID);
        memberAttributesAvro.setMemberId(ID);
        memberAttributesAvro.setPersonId(String.valueOf(ID));
        memberAttributesAvro.setMissingProfile(false);
        memberAttributesAvro.setNewEnrollee(false);
        memberAttributesAvro.setTermed(false);
        memberAttributesAvro.setMissingFirstName(false);
        memberAttributesAvro.setMissingLastName(false);
        memberAttributesAvro.setMissingDateOfBirth(false);
        memberAttributesAvro.setCurrentlyEnrolled(true);
        memberAttributesAvro.setDeceased(false);
        memberAttributesAvro.setHomebound(true);
        memberAttributesAvro.setHospice(true);
        memberAttributesAvro.setAgeGroup("Infant");
        memberAttributesAvro.setAge(1);
        memberAttributesAvro.setAgeGroupId(ID);
        memberAttributesAvro.setMetalLevel("silver");
        memberAttributesAvro.setGroupPlanType("ID");
        memberAttributesAvro.setState("MD");
        memberAttributesAvro.setAttributedPractitionerId(ID);
        memberAttributesAvro.setWinningEnrollmentId(1L);
        memberAttributesAvro.setNoPreviousIntervention(false);
        memberAttributesAvro.setPastEfIntervention(false);
        memberAttributesAvro.setPastSmeIntervention(false);
        memberAttributesAvro.setPcpVisit(false);
        memberAttributesAvro.setTotalReachAttempts(10);
        memberAttributesAvro.setSuccessfulReachAttempts(9);
        memberAttributesAvro.setNotReached(1);
        memberAttributesAvro.setReachRateCategoryId(ID);
        memberAttributesAvro.setCompletedEfSoapNote(false);
        memberAttributesAvro.setInstitutional(true);
        memberAttributesAvro.setAgeExclusionLessThan3(false);


        Assert.assertTrue(memberAttributesAvro.getMemberAttributesId() == ID );
        Assert.assertTrue(memberAttributesAvro.getMemberAttributesRunId() == ID);
        Assert.assertTrue(memberAttributesAvro.getMemberId() == ID);
        Assert.assertTrue(memberAttributesAvro.getPersonId().equals(String.valueOf(ID)));
        Assert.assertTrue(!memberAttributesAvro.getMissingDateOfBirth());
        Assert.assertTrue(!memberAttributesAvro.getTermed());
        Assert.assertTrue(!memberAttributesAvro.getMissingProfile());
        Assert.assertTrue(!memberAttributesAvro.getNewEnrollee());
        Assert.assertTrue(!memberAttributesAvro.getTermed());
        Assert.assertTrue(!memberAttributesAvro.getMissingFirstName());
        Assert.assertTrue(!memberAttributesAvro.getMissingLastName());
        Assert.assertTrue(!memberAttributesAvro.getMissingDateOfBirth());
        Assert.assertTrue(memberAttributesAvro.getCurrentlyEnrolled());
        Assert.assertTrue(!memberAttributesAvro.getDeceased());
        Assert.assertTrue(memberAttributesAvro.getHospice());
        Assert.assertTrue(memberAttributesAvro.getHomebound());
        Assert.assertTrue(memberAttributesAvro.getAge() == 1);
        Assert.assertTrue(memberAttributesAvro.getAgeGroupId() == ID);
        Assert.assertTrue(memberAttributesAvro.getAgeGroup().equals("Infant"));
        Assert.assertTrue(memberAttributesAvro.getMetalLevel().equals("silver"));
        Assert.assertTrue(memberAttributesAvro.getGroupPlanType().equals("ID"));
        Assert.assertTrue(memberAttributesAvro.getState().equals("MD"));
        Assert.assertTrue(memberAttributesAvro.getAttributedPractitionerId() == ID);
        Assert.assertTrue(memberAttributesAvro.getWinningEnrollmentId() == ID);
        Assert.assertTrue(!memberAttributesAvro.getNoPreviousIntervention());
        Assert.assertTrue(!memberAttributesAvro.getPcpVisit());
        Assert.assertTrue(memberAttributesAvro.getTotalReachAttempts() == 10);
        Assert.assertTrue(memberAttributesAvro.getSuccessfulReachAttempts() == 9);
        Assert.assertTrue(memberAttributesAvro.getNotReached() == 1);
        Assert.assertTrue(memberAttributesAvro.getReachRateCategoryId() == ID);
        Assert.assertTrue(!memberAttributesAvro.getCompletedEfSoapNote());
        Assert.assertTrue(memberAttributesAvro.getInstitutional());
        Assert.assertTrue(!memberAttributesAvro.getAgeExclusionLessThan3());
    }

    @Test
    public void testFullConstructor(){
        memberAttributesAvro = new MemberAttributesAvro(
                ID, ID, ID, String.valueOf(ID), false, false, false, false, false, false, true, false, true, true, "Infant", true, 1, ID, "silver", "ID", "MD", ID, 1L, false, false, false, false, 10, 9, 1, ID, false, false
        );

        Assert.assertTrue(memberAttributesAvro.getMemberAttributesId() == ID );
        Assert.assertTrue(memberAttributesAvro.getMemberAttributesRunId() == ID);
        Assert.assertTrue(memberAttributesAvro.getMemberId() == ID);
        Assert.assertTrue(memberAttributesAvro.getPersonId().equals(String.valueOf(ID)));
        Assert.assertTrue(!memberAttributesAvro.getMissingDateOfBirth());
        Assert.assertTrue(!memberAttributesAvro.getTermed());
        Assert.assertTrue(!memberAttributesAvro.getMissingProfile());
        Assert.assertTrue(!memberAttributesAvro.getNewEnrollee());
        Assert.assertTrue(!memberAttributesAvro.getTermed());
        Assert.assertTrue(!memberAttributesAvro.getMissingFirstName());
        Assert.assertTrue(!memberAttributesAvro.getMissingLastName());
        Assert.assertTrue(!memberAttributesAvro.getMissingDateOfBirth());
        Assert.assertTrue(memberAttributesAvro.getCurrentlyEnrolled());
        Assert.assertTrue(!memberAttributesAvro.getDeceased());
        Assert.assertTrue(memberAttributesAvro.getHospice());
        Assert.assertTrue(memberAttributesAvro.getHomebound());
        Assert.assertTrue(memberAttributesAvro.getAge() == 1);
        Assert.assertTrue(memberAttributesAvro.getAgeGroupId() == ID);
        Assert.assertTrue(memberAttributesAvro.getAgeGroup().equals("Infant"));
        Assert.assertTrue(memberAttributesAvro.getMetalLevel().equals("silver"));
        Assert.assertTrue(memberAttributesAvro.getGroupPlanType().equals("ID"));
        Assert.assertTrue(memberAttributesAvro.getState().equals("MD"));
        Assert.assertTrue(memberAttributesAvro.getAttributedPractitionerId() == ID);
        Assert.assertTrue(memberAttributesAvro.getWinningEnrollmentId() == ID);
        Assert.assertTrue(!memberAttributesAvro.getNoPreviousIntervention());
        Assert.assertTrue(!memberAttributesAvro.getPcpVisit());
        Assert.assertTrue(memberAttributesAvro.getTotalReachAttempts() == 10);
        Assert.assertTrue(memberAttributesAvro.getSuccessfulReachAttempts() == 9);
        Assert.assertTrue(memberAttributesAvro.getNotReached() == 1);
        Assert.assertTrue(memberAttributesAvro.getReachRateCategoryId() == ID);
        Assert.assertTrue(!memberAttributesAvro.getCompletedEfSoapNote());
        Assert.assertTrue(!memberAttributesAvro.getInstitutional());
        Assert.assertTrue(memberAttributesAvro.getAgeExclusionLessThan3());
    }
}

package com.inovalon.riskadjustment.persistence.test.business;

import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.PractitionerValidationConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.PractitionerValidationAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.PractitionerValidation;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PractitionerValidationConverterTest {
    @InjectMocks private PractitionerValidationConverter practitionerValidationConverter;
    private WorkerProcessMessageAvro workerProcessMessageAvro;
    private WorkerProcessMessage workerProcessMessage;
    private PractitionerValidationAvro practitionerValidationAvro;
    private static int ID;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        this.ID = 1;
        workerProcessMessage = new WorkerProcessMessage();
        workerProcessMessageAvro = new WorkerProcessMessageAvro();
        practitionerValidationAvro = new PractitionerValidationAvro();
        practitionerValidationAvro.setInvalidAddress(true);
        practitionerValidationAvro.setInvalidFax(false);
        practitionerValidationAvro.setInvalidName(true);
        practitionerValidationAvro.setInvalidPhone(false);
        practitionerValidationAvro.setMemberAttributesRunId(ID);
        practitionerValidationAvro.setPractitionerId(ID);

        workerProcessMessageAvro.setPractitionerValidation(practitionerValidationAvro);
    }

    @Test
    public void convertObjectTest() throws Exception{
        this.practitionerValidationConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);

        Assert.assertTrue(workerProcessMessage.getPractitionerValidation() instanceof PractitionerValidation);
        Assert.assertTrue(workerProcessMessage.getPractitionerValidation().getMemberAttributesRunId() == ID );
        Assert.assertTrue(workerProcessMessage.getPractitionerValidation().getPractitionerId() == ID);
        Assert.assertTrue(workerProcessMessage.getPractitionerValidation().isInvalidAddress());
        Assert.assertTrue(workerProcessMessage.getPractitionerValidation().isInvalidName());
        Assert.assertTrue(!workerProcessMessage.getPractitionerValidation().isInvalidPhone());
        Assert.assertTrue(!workerProcessMessage.getPractitionerValidation().isInvalidFax());

    }
}

package com.inovalon.riskadjustment.persistence.test.business;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.ObjectPersistenceImpl;
import com.inovalon.riskadjustment.memberattributes.persistence.configuration.PersistenceConfiguration;
import com.inovalon.riskadjustment.memberattributes.persistence.util.PersistenceModelEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class ObjectPersistenceTest {
    @InjectMocks private ObjectPersistenceImpl objectPersistence;
    @Mock private RestTemplate restTemplate;
    @Mock private PersistenceConfiguration persistenceConfiguration;
    @Mock private HttpHeaders httpHeaders;
    @Mock private ObjectMapper objectMapper;
    private Object object;
    private String url;
    private PersistenceModelEnum persistenceModelEnum;


    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);

        object = new Object();
        url = "mock string";
        persistenceModelEnum = PersistenceModelEnum.PractitionerValiation;

        ResponseEntity<Integer> responseEntity = new ResponseEntity<>(0, HttpStatus.OK);
        Mockito.when(persistenceConfiguration.getRiskAnalyticsResultBaseUrl()).thenReturn("");

        Mockito.when(restTemplate.postForEntity(Matchers.anyString(), Matchers.<HttpEntity<String>>any(), Matchers.eq(Integer.class))).thenReturn(responseEntity);
    }

    @Test
    public void convertObjectTest() throws Exception{
        boolean ret =  this.objectPersistence.persistModel(object, url, persistenceModelEnum);
        Assert.assertTrue(ret);
    }
}

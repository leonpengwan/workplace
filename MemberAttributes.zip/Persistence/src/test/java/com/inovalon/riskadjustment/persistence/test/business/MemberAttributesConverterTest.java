package com.inovalon.riskadjustment.persistence.test.business;

import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.MemberAttributesConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberAttributesAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberAttributes;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MemberAttributesConverterTest {
    private WorkerProcessMessageAvro workerProcessMessageAvro;
    private WorkerProcessMessage workerProcessMessage;
    private MemberAttributesAvro memberAttributesAvro;
    @InjectMocks private MemberAttributesConverter memberAttributesConverter;
    private static int ID;

    @Before
    public void setUp() throws Exception{
        this.ID = 1;
        MockitoAnnotations.initMocks(this);
        workerProcessMessage = new WorkerProcessMessage();
        workerProcessMessageAvro = new WorkerProcessMessageAvro();
        memberAttributesAvro = new MemberAttributesAvro();
        memberAttributesAvro.setMemberAttributesId(ID);
        memberAttributesAvro.setMemberAttributesRunId(ID);
        memberAttributesAvro.setMemberId(ID);
        memberAttributesAvro.setPersonId(String.valueOf(ID));
        memberAttributesAvro.setMissingProfile(false);
        memberAttributesAvro.setNewEnrollee(false);
        memberAttributesAvro.setTermed(false);
        memberAttributesAvro.setMissingLastName(false);
        memberAttributesAvro.setMissingFirstName(false);
        memberAttributesAvro.setMissingDateOfBirth(false);
        memberAttributesAvro.setCurrentlyEnrolled(false);
        memberAttributesAvro.setDeceased(false);
        memberAttributesAvro.setHospice(true);
        memberAttributesAvro.setHomebound(false);
        memberAttributesAvro.setAgeGroup("Adult");
        memberAttributesAvro.setAgeExclusionLessThan3(false);
        memberAttributesAvro.setAge(33);
        memberAttributesAvro.setAgeGroupId(3);
        memberAttributesAvro.setMetalLevel("Bronze");
        memberAttributesAvro.setGroupPlanType("ID");
        memberAttributesAvro.setState("MD");
        memberAttributesAvro.setAttributedPractitionerId(ID);
        memberAttributesAvro.setWinningEnrollmentId(new Long(ID));
        memberAttributesAvro.setNoPreviousIntervention(true);
        memberAttributesAvro.setPastEfIntervention(false);
        memberAttributesAvro.setPastSmeIntervention(false);
        memberAttributesAvro.setPcpVisit(true);
        memberAttributesAvro.setTotalReachAttempts(10);
        memberAttributesAvro.setSuccessfulReachAttempts(9);
        memberAttributesAvro.setNotReached(1);
        memberAttributesAvro.setReachRateCategoryId(ID);
        memberAttributesAvro.setCompletedEfSoapNote(false);
        workerProcessMessageAvro.setMemberAttributes(memberAttributesAvro);

    }

    @Test
    public void convertObjectTest() throws Exception{
        this.memberAttributesConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);

        Assert.assertTrue(workerProcessMessage.getMemberAttributes() instanceof MemberAttributes );
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getMemberAttributesRunId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getMemberId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getPersonId().equals(String.valueOf(ID))) ;
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isMissingProfile());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isNewEnrollee());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isTermed());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isMissingLastName());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isMissingFirstName());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isMissingDateOfBirth());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isCurrentlyEnrolled());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isDeceased());
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().isHospice());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isHomebound());
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getAgeGroup().equals("Adult"));
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isAgeExclusionLessThan3());
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getAge() == 33);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getAgeGroupId() == 3);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getMetalLevel().equals("Bronze"));
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getGroupPlanType().equals("ID"));
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getState().equals("MD"));
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getAttributedPractitionerId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getWinningEnrollmentId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().isNoPreviousIntervention());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isPastEfIntervention());
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isPastSmeIntervention());
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().isPcpVisit());
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getTotalReachAttempts()==10);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getSuccessfulReachAttempts() == 9);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getNotReached() == 1);
        Assert.assertTrue(workerProcessMessage.getMemberAttributes().getReachRateCategoryId() == ID);
        Assert.assertTrue(!workerProcessMessage.getMemberAttributes().isCompletedEfSoapNote());
    }
}

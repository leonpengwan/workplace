package com.inovalon.riskadjustment.persistence.test.business;

import com.inovalon.riskadjustment.memberattributes.persistence.business.impl.MemberValidationConverter;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.MemberValidationAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.avro.input.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.persistence.model.servicemodel.input.WorkerProcessMessage;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MemberValidationConverterTest {
    @InjectMocks private MemberValidationConverter memberValidationConverter;
    private static int ID;
    private WorkerProcessMessage workerProcessMessage;
    private WorkerProcessMessageAvro workerProcessMessageAvro;
    private MemberValidationAvro memberValidationAvro;

    @Before
    public void setUp(){
        this.ID = 1;
        MockitoAnnotations.initMocks(this);
        workerProcessMessage = new WorkerProcessMessage();
        workerProcessMessageAvro = new WorkerProcessMessageAvro();
        memberValidationAvro = new MemberValidationAvro();
        memberValidationAvro.setMemberAttributesRunId(ID);
        memberValidationAvro.setMemberId(ID);
        memberValidationAvro.setPersonId(String.valueOf(ID));
        memberValidationAvro.setInValidAddress(true);
        memberValidationAvro.setInValidPhone(false);
        workerProcessMessageAvro.setMemberValidation(memberValidationAvro);
    }

    @Test
    public void convertObjectTest() throws Exception{
        this.memberValidationConverter.convertObject(workerProcessMessageAvro, workerProcessMessage);

        Assert.assertTrue(workerProcessMessage.getMemberValidation() instanceof MemberValidation);
        Assert.assertTrue(workerProcessMessage.getMemberValidation().getMemberAttributesRunId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberValidation().getMemberId() == ID);
        Assert.assertTrue(workerProcessMessage.getMemberValidation().getPersonId().equals(String.valueOf(ID)));
        Assert.assertTrue(workerProcessMessage.getMemberValidation().isInValidAddress());
        Assert.assertTrue(!workerProcessMessage.getMemberValidation().isInValidPhone());

    }
}

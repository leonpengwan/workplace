node {

    // This one liner is what limits concurrent builds
    properties([disableConcurrentBuilds()])

    deleteDir()
    // Java Home path setup
    env.JAVA_HOME = "C:\\Jenkins\\tools\\hudson.model.JDK\\Java8"

    //###############################################################
    // Custom Pipeline Service Based Attributes
    def Jenkins_Job_Name = "Risk Adjustment :: MemberAttributes_Pipeline"
    def ProjectName = "MemberAttributes"
    def EmailRecipients="akoduru@inovalon.com,pbhalani@inovalon.com,djose@inovalon.com,fmaradirangaiah@inovalon.com,jkaruppiah@inovalon.com,jdasamxp@inovalon.com,kraju@inovalon.com,krajagopalaiah@inovalon.com,npuranik@inovalon.com,pwan@inovalon.com,pkatta@inovalon.com,pvasanthakumar@inovalon.com,spande@inovalon.com,sshrivastavaxp@inovalon.com,sdasani@inovalon.com,twalters@inovalon.com"
    //def EmailRecipients="fmaradirangaiah@inovalon.com"
    //###############################################################
    //PCF Details
    def PCF_LOGIN_URL = "api.system.rs-nonprod-int2-pcf.medassurant.local"
    def PCF_Credentials = "Ram_Inovalon_PCF"
    def organization = "RANG-DEV"
    def QA_PCF_LOGIN_URL = "api.system.rs-nonprod-int2-pcf.medassurant.local"
    //###############################################################

    def pomFilePath = "pom.xml"
    MavenSettingsConfig_Cucumber = "878f5950-cd56-4aa9-99db-7f44435c97ce"
    MavenSettingsConfig_Artifactory = "24f90c32-edf1-4aaf-a835-f7167e3bdbd9"

    //###############################################################
    //Define all the RANG Clients and Projects
    //PLEASE KEEP THIS ALL $$$ lower case $$$$
    def RANGClients = [
            ["centene", "projecta"]
    ]
    //###############################################################

    def ModuleDetails = [
            ["Worker"]

    ]

    //Artifactory details
    def server = Artifactory.server('Artifactory_RANG')
    def rtMaven = Artifactory.newMavenBuild()
    def buildInfo = ""
    def arifactpath = "./target/" + ProjectName + "-0.0.1-SNAPSHOT-${BUILD_NUMBER}.jar"
    def snapshotRepoName = "RANG_Demo_Snapshot"
    def releaseRepoName = "release-repo"
    def artifactory_Credential_ID = "Rang_Maven_Artifactory"
    def arifactoryURL = "http://rsartfpocdev02.medassurant.local/artifactory"
    def fileFormat = "*.jar"
    def VSTC_Credentials = "Ram_VSTS_Credentials"
    def checkOutInformation = ""
    //Pull code from GIT
    stage('Git Pull') {
        checkOutInformation = checkout scm
    }

    //Building Project
    stage('Building Project') {
        try {
            configFileProvider([configFile(fileId: MavenSettingsConfig_Artifactory, variable: 'MAVEN_SETTINGS')]) {

                //Configuring Artifactory server and repo
                rtMaven.deployer server: server, snapshotRepo: snapshotRepoName, releaseRepo: releaseRepoName

                //this will stop the uploading artifacts to artifactory after build the solution
                rtMaven.deployer.deployArtifacts = false

                //Configuring Maven tool
                rtMaven.tool = 'M3'

                //building project using Artifactory plugin
                buildInfo = rtMaven.run pom: pomFilePath, goals: 'clean install -Dbuild.number=${BUILD_NUMBER}  -s \"${MAVEN_SETTINGS}\"'
                junit allowEmptyResults: true, testResults: '**/target/surefire-reports/*.xml'
                jacoco execPattern: '**/target/**.exec'

                Send_Spark_Notification("Project Build Successful", ProjectName)
            }

        }
        catch (err) {
            SendMail(ProjectName, EmailRecipients, "FAILED", "Building Project", checkOutInformation)
            junit allowEmptyResults: true, testResults: '**/target/surefire-reports/*.xml'
            jacoco execPattern: '**/target/**.exec'

            Send_Spark_Notification("Project Build Failed", ProjectName)
            throw err
        }
    }

    //Deploying app to PCF
    stage('Deploying to PCF -DEV') {
        try {
            //Reading PCF credentials from Jenkins credential object.
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: PCF_Credentials, passwordVariable: 'CF_JENKINS_PW', usernameVariable: 'CF_JENKINS_USER']]) {

                for (clientProject in RANGClients) {
                    def Environment = "dev"
                   def space = clientProject[0]

                    def DATACentre = PCF_LOGIN_URL.tokenize('.')[2].split('-')[0]


                    //login to PCF
                    bat "cf login --skip-ssl-validation -a ${PCF_LOGIN_URL} -o ${organization} -s ${space} -u ${env.CF_JENKINS_USER} -p ${env.CF_JENKINS_PW}"
                    for (module in ModuleDetails) {
                        dir("${module[0]}") {

                            def App_Name = Environment + "_" + clientProject[0] + "_" + clientProject[1] + "_" + ProjectName + "_" + "${module[0]}"
                            def ManifestPath = "deployment/manifest_dev.yml"
                            def CloudConfigService = "http://" + Environment + "_cloud-config-server.apps.rs-nonprod-int2-pcf.medassurant.local"

                            //Push artifacts to PCF
                            bat """
                                 cmd.exe /c cf delete ${App_Name} -r -f
                                 cf delete-orphaned-routes -f
                                 cf push ${App_Name} -f ${ManifestPath} --hostname ${App_Name} -u none
                                 cf set-env ${App_Name} rang_env ${Environment}
                                 cf set-env ${App_Name} rang_client-name ${clientProject[0]}
                                 cf set-env ${App_Name} rang_project-name ${clientProject[1]}
                                 cf set-env ${App_Name} rang_data-center ${DATACentre}
                                 cf set-env ${App_Name} spring_cloud_config_uri ${CloudConfigService}
                                 cf set-env ${App_Name} rang_system  pcf
								 cf set-env ${App_Name} TZ 'America/New_York'
                                 cf restage ${App_Name}
                                """
                            Send_Spark_Notification("${App_Name} Deployed to ${Environment}  ", ProjectName)
                        }
                    }
                    bat "cf logout"

                }

            }

            Send_Spark_Notification("Deployment To DEV PCF Complete", ProjectName)
        }
        catch (err) {
            SendMail(ProjectName, EmailRecipients, "FAILED", "Deploying to PCF", checkOutInformation)
            Send_Spark_Notification("Deployment To DEV PCF Failed", ProjectName)
            throw err
        }
    }

    //Push Artifacts to Artifactory
    stage('Push to Artifactory') {
        try {
            // deploying artifacts to artifactory and updating buildInfo
            rtMaven.deployer.deployArtifacts buildInfo

            //Publishing Build info to artifactory
            server.publishBuildInfo buildInfo
        }
        catch (err) {
            //Sending Build status email
            SendMail(ProjectName, EmailRecipients, "FAILED", "Push to Artifactory", checkOutInformation)
            Send_Spark_Notification("JAR's FAILED Push to Artifactory", ProjectName)
            throw err
        }
        //Sending Build status email
        SendMail(ProjectName, EmailRecipients, "SUCCESS", "Push to Artifactory", checkOutInformation)
        Send_Spark_Notification("JAR's Pushed to Artifactory", ProjectName)

    }

    //Porting artifacts from snapshot repo to release repo
    stage('Build Promotion') {
        try {
            def promotionConfig = [// Mandatory parameters
                                   'buildName'          : buildInfo.name,
                                   'buildNumber'        : buildInfo.number,
                                   'targetRepo'         : releaseRepoName,

                                   // Optional parameters
                                   'comment'            : 'Promoting build from Snapshot REPO to Release REPO',
                                   'sourceRepo'         : snapshotRepoName,
                                   'status'             : 'Released',
                                   'includeDependencies': false,
                                   'copy'               : false,
                                   // 'failFast' is true by default.
                                   // Set it to false, if you don't want the promotion to abort upon receiving the first error.
                                   'failFast'           : true]

            // Promote build
            server.promote promotionConfig

        }
        catch (err) {
            //Sending Build status email
            SendMail(ProjectName, EmailRecipients, "FAILED", "Build Promotion", checkOutInformation)
            Send_Spark_Notification("Build Promotion Failed", ProjectName)
            throw err
        }
    }

    //Downloading latest artifact
    stage('Downloading latest Artifacts') {
        try {
            def artifactsDownloadPath = ".\\artifacts\\"
            def explode = "false"

            //verify artifacts is exists or not. if not exists create
            bat "if not exist ${artifactsDownloadPath} mkdir ${artifactsDownloadPath}"
            bat "powershell -c \"Remove-Item ${artifactsDownloadPath}\\* -Force -Recurse \""

            def artifactFullPath = FindLatestArtifact(arifactoryURL, artifactory_Credential_ID, releaseRepoName, Jenkins_Job_Name, fileFormat)
            def artifactName = artifactFullPath.split('/')
            arifactpath = "./artifacts/${artifactName[artifactName.length - 1]}"
            DownloadArtifacts(server, artifactFullPath, artifactsDownloadPath, explode, false)
        }
        catch (err) {
            //Sending Build status email
            SendMail(ProjectName, EmailRecipients, "FAILED", "Downloading latest Artifacts", checkOutInformation)
            Send_Spark_Notification("Download Latest Artifact Failed", ProjectName)
            throw err
        }
    }


}

//###############################################################################
// Custom Functions
//###############################################################################

def DownloadArtifacts(server, pattern, target, explode, publish) {
    def downloadSpec = """{
                "files":[
                    {
                        "pattern": "${pattern}",
                        "target": "${target}",
                        "explode": "${explode}",
                        "flat": "true"
                    }
                ]
            }"""
    def buildInfo = server.download(downloadSpec)
    if (publish) {
        server.publishBuildInfo(buildInfo)
    }
}

import groovy.json.JsonSlurper

def FindLatestArtifact(arifactoryURL, credentialID, source_repo, Jenkins_Job_Name, fileFormat) {
    def query = """items.find({
                    '@build.name':{'\$eq':'${Jenkins_Job_Name}'}
                    , 'repo':{'\$eq':'${source_repo}'}
                    ,'name':{'\$match':'${fileFormat}'}
                }).sort({'\$desc': ['created']}).limit(1)"""
    def response = httpRequest authentication: credentialID, url: "${arifactoryURL}/api/search/aql", httpMode: "POST", contentType: "TEXT_PLAIN", requestBody: query.replace('\'', '\"')
    def result = new JsonSlurper().parseText(response.content)
    if ("${result.range.total}" < 1) {
        error("artifacts not found")
    }
    return "${result.results[0].repo}/${result.results[0].path}/${result.results[0].name}"
}

def SendMail(ProjectName, EmailRecipients, BuildStatus, FailedStage, checkOutInformation) {

    //Configuring Status color
    def statusColor = "red"
    if ("${BuildStatus}" == "SUCCESS") {
        statusColor = "green"
    }

    //Configuring Email body
    def emailBody = """<table style='border: 1px solid black;border-collapse: collapse;'>
        <tr>
            <td colspan='2' style='background-color:${statusColor}; color:white; text-align:middle;font-size: 20px;white-space: nowrap;padding: 5px;'>
            ${ProjectName} - Build #${BUILD_NUMBER} - ${BuildStatus}</td>
        </tr>
        <tr>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>Jenkins Job Name</td>
            <td>: ${JOB_NAME}</td>
        </tr>
        <tr style='background-color: #f2f2f2'>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>Build Status </td>
            <td>: ${BuildStatus}</td>
        </tr>
        <tr>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>Console Output</td>
            <td>: <a href="${BUILD_URL}/console">Click here</a></td>
        </tr>
        <!--
        <tr>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>Junit Test Results</td>
            <td>: <a href='${BUILD_URL}/console'>Click here</a></td>
        </tr> -->

        <tr>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>GIT Branch</td>
            <td>: ${checkOutInformation.GIT_BRANCH}</td>
        </tr>
        <tr style='background-color: #f2f2f2'>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>GIT Commit SHA</td>
            <td>: ${checkOutInformation.GIT_COMMIT}</td>
        </tr>
        <tr>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>GIT URL</td>
            <td>: <a href='${checkOutInformation.GIT_URL}'>Click here</a></td>
        </tr>"""

    //Adding failed stage to email body
    if ("${BuildStatus}" == "FAILED") {
        emailBody = emailBody + """
        <tr style='background-color: #f2f2f2'>
            <td style='font-weight:bold; white-space: nowrap; padding: 5px;'>Failed Stage</td>
            <td>: ${FailedStage}</td>
        </tr>
        """
    }
    emailBody = emailBody + """</table>"""

    //sending email
    emailext body: emailBody,
            attachLog: true,
            subject: 'RANG Build Status',
            mimeType: 'text/html',
            to: EmailRecipients

}

def Send_Spark_Notification(spark_Message, ProjectName) {
    def spark_Space_ID = "b8d85b40-0b56-11e8-9dc4-d9eb86a305d1"
    def spark_Credential_ID = "Spark_Token_Sankalp"
    def spark_formatted_Message = "<blockquote> <h2> RISK Adjustment&copy Jenkins Pipeline Message for " + ProjectName + "</h2> <p>" + spark_Message + "</p> </blockquote>"
    sparkSend credentialsId: spark_Credential_ID, message: spark_formatted_Message, messageType: 'markdown', spaceList: [[spaceId: spark_Space_ID, spaceName: 'Spark_Space']]
}
import com.inovalon.riskadjustment.memberattributes.aggregator.config.AggregatorConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan(basePackages = "com.inovalon.riskadjustment")
public class Aggregator {

    @Autowired
    private AggregatorConfiguration aggregatorConfiguration;

    public static void main(String[] args) {
        SpringApplication.run ( Aggregator.class, args );

        //System.out.println( Utilities.getAvroSchema(new MemberStatusWrapper ()));
    }
    @PostConstruct
    private void initialize() {

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++++++ SERVICE STARTED  ++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("aggregatorConfiguration :" + aggregatorConfiguration.toString() );
    }

}

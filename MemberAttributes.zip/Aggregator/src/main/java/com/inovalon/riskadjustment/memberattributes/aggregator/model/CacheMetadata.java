package com.inovalon.riskadjustment.memberattributes.aggregator.model;

import java.io.Serializable;
import java.util.HashSet;

/**
 * AggregatorCacheMetadata Model class to house Aggregator's current run statistics regarding run counts.
 * Created by krajagopalaiah on 12/27/2017.
 */
public class CacheMetadata implements Serializable{

    /**
     * Holds the total members for the concernted runProfile (MemberValuation table member count for the concerned runId.
     */
    private long totalMemberPopulation;
    /**
     * Hashset to maintain a unique list of members for a runid
     */
    private HashSet<Long> members;

    public long getTotalMemberPopulation() {
        return totalMemberPopulation;
    }

    public void setTotalMemberPopulation(int totalMemberPopulation) {
        this.totalMemberPopulation = totalMemberPopulation;
    }

    public HashSet<Long> getMembers() {
        return members;
    }

    public void setMembers(HashSet<Long> members) {
        this.members = members;
    }

    public CacheMetadata() {

    }
}

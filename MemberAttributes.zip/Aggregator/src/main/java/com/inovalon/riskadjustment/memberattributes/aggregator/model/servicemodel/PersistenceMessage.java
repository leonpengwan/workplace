package com.inovalon.riskadjustment.memberattributes.aggregator.model.servicemodel;


import com.inovalon.riskadjustment.shared.messagebus.model.MessageEnvelope;

public class PersistenceMessage extends MessageEnvelope {
    private long runProfielId;
    private int MemberAttributesRunId;
    private int parentRunId;
    private int memberId;

    public PersistenceMessage() {
    }

    public PersistenceMessage(long runProfielId, int memberAttributesRunId, int parentRunId, int memberId) {
        this.runProfielId = runProfielId;
        MemberAttributesRunId = memberAttributesRunId;
        this.parentRunId = parentRunId;
        this.memberId = memberId;
    }

    public long getRunProfielId() {
        return runProfielId;
    }

    public void setRunProfielId(long runProfielId) {
        this.runProfielId = runProfielId;
    }

    public int getMemberAttributesRunId() {
        return MemberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        MemberAttributesRunId = memberAttributesRunId;
    }

    public int getParentRunId() {
        return parentRunId;
    }

    public void setParentRunId(int parentRunId) {
        this.parentRunId = parentRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
}

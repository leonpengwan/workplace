package com.inovalon.riskadjustment.memberattributes.aggregator.business.common;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.logger.LogWriter;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class to make REST Api calls.
 */
@Component
public  class RestApiGateway {

    private RestTemplate restTemplate;
    @Autowired
    private LogWriter logWriter;

    public RestApiGateway() {
    }

    @PostConstruct
    public void setRestTemplate(){
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        // Need to define this in Property file
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(2000).setConnectTimeout(2000)
                .setSocketTimeout(2000).setStaleConnectionCheckEnabled(false).build();
        SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setTcpNoDelay(true).build();
        // Need to define this in Property file
        PoolingHttpClientConnectionManager poolingHttpClientConnectionManager = new PoolingHttpClientConnectionManager();
        poolingHttpClientConnectionManager.setMaxTotal(800);
        poolingHttpClientConnectionManager.setDefaultMaxPerRoute(700);

        CloseableHttpClient httpClientBuilder = HttpClientBuilder.create()
                .setConnectionManager(poolingHttpClientConnectionManager).setDefaultRequestConfig(requestConfig)
                .setDefaultSocketConfig(socketConfig).build();

        requestFactory.setHttpClient(httpClientBuilder);
        restTemplate = new RestTemplate ( requestFactory );
        //restTemplate.setMessageConverters ( messageConverters() );
    }

    private List<HttpMessageConverter<?>> messageConverters(){
        List<HttpMessageConverter<?>> converters = new ArrayList <HttpMessageConverter <?>> (  );
        converters.add ( jsonMessageConverter () );
        return converters;
    }

    private HttpMessageConverter jsonMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion( JsonInclude.Include.NON_NULL);
        objectMapper.configure( DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure( DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
        converter.setObjectMapper(objectMapper );
        return converter;
    }


    /**
     * @param url url to connect to.
     * @param classz class type of the object being referenced.
     * @param <T> returns Type of Class.
     */
    public <T> T getData(String url , Class <T> classz){
        ResponseEntity<T> responseEntity =  restTemplate.getForEntity ( url,classz );
        return responseEntity.getBody ();
    }

    public <T> ResponseEntity<T> getForEntity(String url , Class <T> classz){

        ResponseEntity<T> responseEntity =  restTemplate.getForEntity ( url,classz );

        return responseEntity;
    }


    public <T> T postData(String url, String json, Class<T> classz) throws Exception {
        HttpEntity<String> entity = getEntity(json);
        ResponseEntity<T> resposne = restTemplate.postForEntity(url, entity, classz);
        if(resposne.getStatusCode ()!= HttpStatus.OK){
            throw new Exception("Not able to Communicate with Service");
        }
        return resposne.getBody();
    }

    public HttpEntity<String> getEntity(String json) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> httpEntity = json != null ? new HttpEntity<String>(json, headers)
                : new HttpEntity<String>(headers);
        return httpEntity;
    }

    public <T> T getData(String url , TypeReference<T> type) throws IOException {
        try{
            ObjectMapper objectMapper = new ObjectMapper(  );
            objectMapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
            objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            ResponseEntity<String> responseEntity =  restTemplate.getForEntity ( url,String.class );
            return objectMapper.readValue(responseEntity.getBody (), type);
        }
        catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
        }
        return null;
    }
    public String getBaseUrl(String url , String updateMember) {

        return url+updateMember;
    }

    public String getRequestData(Object object) {
        ObjectMapper mapper = new ObjectMapper(  );
        try {
            return mapper.writeValueAsString ( object );
        } catch (JsonProcessingException ex) {
            logWriter.error(ex.getMessage(),ex);
        }
        return null;
    }


    public HttpEntity getHttpEntity(String jsonString) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType ( MediaType.APPLICATION_JSON );
        HttpEntity<String> httpEntity = new HttpEntity<String> (jsonString,headers );
        return httpEntity;
    }
}

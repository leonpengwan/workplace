package com.inovalon.riskadjustment.memberattributes.aggregator.business;


import com.inovalon.riskadjustment.memberattributes.aggregator.model.avro.input.PersistenceMessageAvro;

/**
 * Created by krajagopalaiah on 12/19/2017.
 * Interface to define a contract for the Aggregator service
 */
public interface AggregatorService {

    /**
     * Interface method to perform the aggregation of the total member counts.
     * @param persistenceMessageAvro input avro message.
     */
    public void gatherMembersAndSetRunStatus(PersistenceMessageAvro persistenceMessageAvro) throws Exception;
}

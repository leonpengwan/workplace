package com.inovalon.riskadjustment.memberattributes.aggregator.messagebus;


import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.aggregator.business.AggregatorManager;
import com.inovalon.riskadjustment.memberattributes.aggregator.model.avro.input.PersistenceMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.consumer.KafkaMessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.enums.MessageAcknowledgment;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.model.MessageMetadata;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * listener service to listen to microservice complex persistence service.
 */
@Service
public class AggregatorListener implements MessageBusListener<PersistenceMessageAvro> {
    @Autowired
    private KafkaMessageBusListener<PersistenceMessageAvro> kafkaMessageBusListener;

    @Autowired
    private AggregatorManager aggregatorManager;

    @Autowired
    private LogWriter logWriter;

    @PostConstruct
    public void Initialize()    {
        //Subscribe to the listener.

        kafkaMessageBusListener.subscribe(this,PersistenceMessageAvro.class);
    }
    @LogBeforeEvents
    @Override
    public MessageAcknowledgment OnQueueMessageReceived(PersistenceMessageAvro persistenceMessageAvro, MessageMetadata messageMetadata) {


        logWriter.info("+++ Received a message from Staging +++ ");
        logWriter.debug("Message CacheMetadata: " + persistenceMessageAvro.toString());

        if (persistenceMessageAvro != null) {
            try {

                aggregatorManager.gatherMembersAndSetRunStatus(persistenceMessageAvro);

                return MessageAcknowledgment.Commit;

            } catch (Exception e) {
                logWriter.error(String.format("++ Error in Aggregator. Message=%s",persistenceMessageAvro.toString()),e);
                return MessageAcknowledgment.DoNotCommit;
            }

        }

        return MessageAcknowledgment.Unknown;
    }
}

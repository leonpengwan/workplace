package com.inovalon.riskadjustment.memberattributes.aggregator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;


/**
 * Created by krajagopalaiah on 12/19/2017.
 * Class to house all configurations related to Aggregator class.
 */
@Configuration
@RefreshScope
public class AggregatorConfiguration {

    @Value("${inovalon.risk-adjustment.data-services.results-url}")
    private String riskAnalyticsResultBaseUrl;
    @Value("${inovalon.risk-adjustment.data-services.configuration-url}")
    private String configurationDatabaseServiceBaseUrl;
    @Value("${spring.kafka.consumer.topic}")
    private String kafkaConsumerTopic;

    public String getRiskAnalyticsResultBaseUrl() {
        return riskAnalyticsResultBaseUrl;
    }

    public String getConfigurationDatabaseServiceBaseUrl() {
        return configurationDatabaseServiceBaseUrl;
    }

    @Override
    public String toString() {
        return "AggregatorConfiguration{" +
                "riskAnalyticsResultBaseUrl='" + riskAnalyticsResultBaseUrl + '\'' +
                ", configurationDatabaseServiceBaseUrl='" + configurationDatabaseServiceBaseUrl + '\'' +
                ", kafkaConsumerTopic='" + kafkaConsumerTopic + '\'' +
                '}';
    }
}

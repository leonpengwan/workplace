package com.inovalon.riskadjustment.memberattributes.aggregator.business;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.cachewrapper.constant.CacheLoadConstant;
import com.inovalon.riskadjustment.cachewrapper.constant.CacheRetrieveConstant;
import com.inovalon.riskadjustment.cachewrapper.controller.CacheLoadService;
import com.inovalon.riskadjustment.cachewrapper.controller.DeleteCacheService;
import com.inovalon.riskadjustment.cachewrapper.controller.RetrieveCacheService;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.aggregator.business.common.CasheNameConstant;
import com.inovalon.riskadjustment.memberattributes.aggregator.business.common.RestApiGateway;
import com.inovalon.riskadjustment.memberattributes.aggregator.config.AggregatorConfiguration;
import com.inovalon.riskadjustment.memberattributes.aggregator.model.CacheMetadata;
import com.inovalon.riskadjustment.memberattributes.aggregator.model.avro.input.PersistenceMessageAvro;
import com.inovalon.riskadjustment.model.enums.Status;
import com.inovalon.riskadjustment.model.servicemodel.cache.RunProfileModel;
import com.inovalon.riskadjustment.model.servicemodel.cache.constant.CacheNameConstant;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.apache.log4j.Logger;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Created by krajagopalaiah on 12/19/2017.
 * Class to implement main core business logic of the aggregator service.
 */
@Component
@ComponentScan(basePackages = "com.inovalon.riskadjustment.memberattributes")
public class AggregatorManager implements AggregatorService {
    private static Logger logger;
    //@Autowired
   // private RedissonClient redissonClient;
    @Autowired
    private RestApiGateway restApiGateway;
    @Autowired
    private AggregatorConfiguration aggregatorConfiguration;
    @Autowired
    private RetrieveCacheService retrieveCacheService;
    @Autowired
    private CacheLoadService cacheLoadService;
    @Autowired
    private DeleteCacheService deleteCacheService;
    @Autowired
    private LogWriter logWriter;

    @PostConstruct
    private void initialize() {
        logger = Logger.getLogger(this.getClass());
    }


    /**
     * Interface method to perform the aggregation of the total member counts.
     *
     * @param persistenceMessageAvro input avro message.
     */
    @LogBeforeEvents
    @Override
    public void gatherMembersAndSetRunStatus(PersistenceMessageAvro persistenceMessageAvro) throws Exception {

        logWriter.info("Gathering member...");

        int memberAttributesRunId = persistenceMessageAvro.getMemberAttributesRunId();

        long runProfileId = persistenceMessageAvro.getRunProfielId();

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName());
        CacheMetadata cacheMetadata  = (CacheMetadata) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);


        if (cacheMetadata == null || cacheMetadata.getMembers().size() == 0 /*|| redissonClientMap.get(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName()) == null*/) {
            logWriter.info("Redisson aggregator cache map is empty. A new mapped object is being created...");
            Map<String,Object> map = new HashMap<>();
            CacheMetadata metadata = new CacheMetadata();
            metadata.setMembers(new HashSet<>());
            cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
            cacheRetrieveConstant.setKey(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName());

            RunProfileModel runProfileModel  = (RunProfileModel) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.registerModule(new JSR310Module());
            RunProfile runProfile = objectMapper.readValue(runProfileModel.getProfile(), RunProfile.class);
            String gapSetId = runProfile.getSections().getGapDataSelection().getGapDataSelections().stream().filter(t -> t.getSelected()).findFirst().get().getGapSetId();
            metadata.setTotalMemberPopulation(this.getCurrentRunTotalPopulation(gapSetId));
            CacheLoadConstant< Map<String,Object>> cacheLoadConstant = new CacheLoadConstant();
            cacheLoadConstant.setCacheName(String.valueOf(runProfileId));
            map.put(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName(),metadata);
            cacheLoadConstant.setValue(map);
            cacheLoadService.loadDataToCache(cacheLoadConstant);

        }

        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName());
        CacheMetadata metadata = (CacheMetadata) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);//redissonClientMap.get(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName());

        //Add the member to the hashSet. This will take care of any duplicate member messages if in case happens due to unavoidable circumstances.
        metadata.getMembers().add(Long.valueOf(persistenceMessageAvro.getMemberId()));

        logWriter.info(String.format("Current Aggregator stats for the runId: %s is <%s/%s>",memberAttributesRunId,metadata.getMembers().size(),metadata.getTotalMemberPopulation()));
        //Update the redission cache map.
            Map<String,Object> map = new HashMap<>();
            CacheLoadConstant< Map<String,Object>> cacheLoadConstant = new CacheLoadConstant();
            cacheLoadConstant.setCacheName(String.valueOf(runProfileId));
            map.put(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName(),metadata);
            cacheLoadConstant.setValue(map);
            cacheLoadService.loadDataToCache(cacheLoadConstant);
        //Check the count of the members in the Hashset to the total population. If it matches, update the run Statut to 'Complete'
        if (metadata.getTotalMemberPopulation() == metadata.getMembers().size()) {
            logWriter.info(String.format("Run is Complete for the RunId: %s with RunProfile: %s", memberAttributesRunId, persistenceMessageAvro.getRunProfielId()));
            //All the population evaluations are done. Update the run status to 'Complete'
            this.setCurrentRunStatusToComplete(persistenceMessageAvro.getMemberAttributesRunId());
            cacheRetrieveConstant.setCacheName(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName());
            deleteCacheService.deleteCacheData(cacheRetrieveConstant);

        }


        logWriter.info(String.format("Aggregator sucessfully gathered member <%s> for the runid<%s>.",persistenceMessageAvro.getMemberId(),memberAttributesRunId));
    }

    /**
     * Gets the current run total population based on the runProfile Id.
     *
     * @param gapSetId parentRunId (Respective complex source data runId)
     * @return Total Population
     */
    @LogBeforeEvents
    private int getCurrentRunTotalPopulation(String gapSetId) {

        String urlSuffix = "/risk-analytics/gap-result/getMemberCount";

        String url = aggregatorConfiguration.getRiskAnalyticsResultBaseUrl()
                .concat(urlSuffix)//This is not generic. This has to be implemented for each Microservice complex.
                .concat("/")
                .concat(gapSetId);

        int totalPopulation = restApiGateway.getData(url, Integer.class);

        return totalPopulation;
    }

    /**
     * Methods which calls the DAL layer to update the respective Run table status to 'Complete' for the corresponding runId.
     * Note: This method is generic enough to suit each microservice complex.
     *
     * @param runId Current runId in the message.
     */
    @LogBeforeEvents
    private void setCurrentRunStatusToComplete(int runId) {

        String url = aggregatorConfiguration.getConfigurationDatabaseServiceBaseUrl()
                .concat(CasheNameConstant.CONFIG_DB_DAL_PATH_PREFIX)
                .concat(CasheNameConstant.DAL_PATH_SUFFIX_TO_SET_RUN_STATUS)
                .concat("?microserviceType=").concat(CasheNameConstant.MICROSERVICE_TYPE.toString())
                .concat("&runId=").concat(String.valueOf(runId))
                .concat("&status=").concat(Status.COMPLETE.toString());
        logWriter.info(url);

        runId = restApiGateway.getData(url, Integer.class);

    }
}

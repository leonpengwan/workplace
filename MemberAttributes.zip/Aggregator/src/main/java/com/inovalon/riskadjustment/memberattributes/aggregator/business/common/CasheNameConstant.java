package com.inovalon.riskadjustment.memberattributes.aggregator.business.common;

import com.inovalon.riskadjustment.model.enums.MicroserviceType;

/**
 * A Class to house all the module constants.
 * Created by krajagopalaiah on 12/19/2017.
 */
public class CasheNameConstant {

    public final static MicroserviceType MICROSERVICE_TYPE =  MicroserviceType.MEMBER_ATTRIBUTES; //note: SET this for respective microservice

    public final static String CONFIG_DB_DAL_PATH_PREFIX="/configdbservice"; //Do not change this.

    public final static String DAL_PATH_SUFFIX_TO_SET_RUN_STATUS="/setRunStatusAndRetrieveRunProfileId"; //Do not change this.

}

package com.inovalon.riskadjustment.memberattributes.staging.test.business;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.business.message.StagingMessageProducer;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.StagingMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class StagingMessageProducerTest {
    @Mock(name="messageBusPublisher")
    private MessageBusPublisher<StagingMessageAvro> messageAvroMessageBusPublisher;

    @Mock
    LogWriter logWriter;

    @InjectMocks
    private StagingMessageProducer stagingMessageProducer;

    @Mock
    private StagingMessageAvro stagingMessageAvro;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testProduceStagingMessage() throws Exception{

        boolean ret = stagingMessageProducer.produceStagingMessage(stagingMessageAvro);

        Assert.assertTrue(ret);
    }
}


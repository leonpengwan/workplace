package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output;

import java.sql.Timestamp;


public class InterventionPlanRun {

    private int interventionPlanRunId;
    private long runProfileId;
    private String runProfileName;
    private String runProfileDescription;
    private int statusId;
    private String statusComment;
    private String statusName;
    private String statusDescription;
    private Timestamp processStartDate;
    private Timestamp processEndDate;
    private int clientId;
    private Integer planYear;
    private Integer planMonth;


    public int getInterventionPlanRunId() {
        return this.interventionPlanRunId;
    }

    public void setInterventionPlanRunId( int interventionPlanRunId ) {
        this.interventionPlanRunId = interventionPlanRunId;
    }

    public long getRunProfileId() {
        return this.runProfileId;
    }

    public void setRunProfileId( long runProfileId ) {
        this.runProfileId = runProfileId;
    }

    public String getRunProfileName() {
        return this.runProfileName;
    }

    public void setRunProfileName( String runProfileName ) {
        this.runProfileName = runProfileName;
    }

    public String getRunProfileDescription() {
        return this.runProfileDescription;
    }

    public void setRunProfileDescription( String runProfileDescription ) {
        this.runProfileDescription = runProfileDescription;
    }

    public int getStatusId() {
        return this.statusId;
    }

    public void setStatusId( int statusId ) {
        this.statusId = statusId;
    }

    public String getStatusComment() {
        return this.statusComment;
    }

    public void setStatusComment( String statusComment ) {
        this.statusComment = statusComment;
    }

    public String getStatusName() {
        return this.statusName;
    }

    public void setStatusName( String statusName ) {
        this.statusName = statusName;
    }

    public String getStatusDescription() {
        return this.statusDescription;
    }

    public void setStatusDescription( String statusDescription ) {
        this.statusDescription = statusDescription;
    }

    public Timestamp getProcessStartDate() {
        return this.processStartDate;
    }

    public void setProcessStartDate( Timestamp processStartDate ) {
        this.processStartDate = processStartDate;
    }

    public Timestamp getProcessEndDate() {
        return this.processEndDate;
    }

    public void setProcessEndDate( Timestamp processEndDate ) {
        this.processEndDate = processEndDate;
    }

    public int getClientId() {
        return this.clientId;
    }

    public void setClientId( int clientId ) {
        this.clientId = clientId;
    }

    public Integer getPlanYear() {
        return this.planYear;
    }

    public void setPlanYear( Integer planYear ) {
        this.planYear = planYear;
    }

    public Integer getPlanMonth() {
        return this.planMonth;
    }

    public void setPlanMonth( Integer planMonth ) {
        this.planMonth = planMonth;
    }


    }

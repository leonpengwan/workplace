package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile;

import java.util.List;

public class RxClaim {

    private int pharmacyClaimId;
    private String clientMemberId;
    private String payerClaimControlNumber;
    private String prescribingClientProviderId;
    private String dispensedDate;
    private String claimStatusCode;
    private String dispensedSupplyDayCount;
    private String supplementalSourceCode;
    private String ndc;
    private String patientPlaceOfServiceCode;
    private List<String> rxClaimAltIds;
    private int feedInstanceId;
    private int udfActiveInd;
    private String prescribingNpi;
    private String dispensingNpi;
    private String metricQuantity;
    private String ingredientCostPaidAmt;
    private String prescribingDea;
    private String allowedAmt;
    private String chargeAmt;
    private String copayAmt;
    private String paidAmt;
    private String totalCost;


    public RxClaim() {
    }

    public RxClaim(int pharmacyClaimId, String clientMemberId, String payerClaimControlNumber, String prescribingClientProviderId, String dispensedDate, String claimStatusCode, String dispensedSupplyDayCount, String supplementalSourceCode, String ndc, String patientPlaceOfServiceCode, List<String> rxClaimAltIds, int feedInstanceId, int udfActiveInd, String prescribingNpi, String dispensingNpi, String metricQuantity, String ingredientCostPaidAmt, String prescribingDea, String allowedAmt, String chargeAmt, String copayAmt, String paidAmt, String totalCost) {
        this.pharmacyClaimId = pharmacyClaimId;
        this.clientMemberId = clientMemberId;
        this.payerClaimControlNumber = payerClaimControlNumber;
        this.prescribingClientProviderId = prescribingClientProviderId;
        this.dispensedDate = dispensedDate;
        this.claimStatusCode = claimStatusCode;
        this.dispensedSupplyDayCount = dispensedSupplyDayCount;
        this.supplementalSourceCode = supplementalSourceCode;
        this.ndc = ndc;
        this.patientPlaceOfServiceCode = patientPlaceOfServiceCode;
        this.rxClaimAltIds = rxClaimAltIds;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.prescribingNpi = prescribingNpi;
        this.dispensingNpi = dispensingNpi;
        this.metricQuantity = metricQuantity;
        this.ingredientCostPaidAmt = ingredientCostPaidAmt;
        this.prescribingDea = prescribingDea;
        this.allowedAmt = allowedAmt;
        this.chargeAmt = chargeAmt;
        this.copayAmt = copayAmt;
        this.paidAmt = paidAmt;
        this.totalCost = totalCost;
    }

    public int getPharmacyClaimId() {
        return pharmacyClaimId;
    }

    public void setPharmacyClaimId(int pharmacyClaimId) {
        this.pharmacyClaimId = pharmacyClaimId;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getPayerClaimControlNumber() {
        return payerClaimControlNumber;
    }

    public void setPayerClaimControlNumber(String payerClaimControlNumber) {
        this.payerClaimControlNumber = payerClaimControlNumber;
    }

    public String getPrescribingClientProviderId() {
        return prescribingClientProviderId;
    }

    public void setPrescribingClientProviderId(String prescribingClientProviderId) {
        this.prescribingClientProviderId = prescribingClientProviderId;
    }

    public String getDispensedDate() {
        return dispensedDate;
    }

    public void setDispensedDate(String dispensedDate) {
        this.dispensedDate = dispensedDate;
    }

    public String getClaimStatusCode() {
        return claimStatusCode;
    }

    public void setClaimStatusCode(String claimStatusCode) {
        this.claimStatusCode = claimStatusCode;
    }

    public String getDispensedSupplyDayCount() {
        return dispensedSupplyDayCount;
    }

    public void setDispensedSupplyDayCount(String dispensedSupplyDayCount) {
        this.dispensedSupplyDayCount = dispensedSupplyDayCount;
    }

    public String getSupplementalSourceCode() {
        return supplementalSourceCode;
    }

    public void setSupplementalSourceCode(String supplementalSourceCode) {
        this.supplementalSourceCode = supplementalSourceCode;
    }

    public String getNdc() {
        return ndc;
    }

    public void setNdc(String ndc) {
        this.ndc = ndc;
    }

    public String getPatientPlaceOfServiceCode() {
        return patientPlaceOfServiceCode;
    }

    public void setPatientPlaceOfServiceCode(String patientPlaceOfServiceCode) {
        this.patientPlaceOfServiceCode = patientPlaceOfServiceCode;
    }

    public List<String> getRxClaimAltIds() {
        return rxClaimAltIds;
    }

    public void setRxClaimAltIds(List<String> rxClaimAltIds) {
        this.rxClaimAltIds = rxClaimAltIds;
    }

    public int getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(int feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public int getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(int udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    public String getPrescribingNpi() {
        return prescribingNpi;
    }

    public void setPrescribingNpi(String prescribingNpi) {
        this.prescribingNpi = prescribingNpi;
    }

    public String getDispensingNpi() {
        return dispensingNpi;
    }

    public void setDispensingNpi(String dispensingNpi) {
        this.dispensingNpi = dispensingNpi;
    }

    public String getMetricQuantity() {
        return metricQuantity;
    }

    public void setMetricQuantity(String metricQuantity) {
        this.metricQuantity = metricQuantity;
    }

    public String getIngredientCostPaidAmt() {
        return ingredientCostPaidAmt;
    }

    public void setIngredientCostPaidAmt(String ingredientCostPaidAmt) {
        this.ingredientCostPaidAmt = ingredientCostPaidAmt;
    }

    public String getPrescribingDea() {
        return prescribingDea;
    }

    public void setPrescribingDea(String prescribingDea) {
        this.prescribingDea = prescribingDea;
    }

    public String getAllowedAmt() {
        return allowedAmt;
    }

    public void setAllowedAmt(String allowedAmt) {
        this.allowedAmt = allowedAmt;
    }

    public String getChargeAmt() {
        return chargeAmt;
    }

    public void setChargeAmt(String chargeAmt) {
        this.chargeAmt = chargeAmt;
    }

    public String getCopayAmt() {
        return copayAmt;
    }

    public void setCopayAmt(String copayAmt) {
        this.copayAmt = copayAmt;
    }

    public String getPaidAmt() {
        return paidAmt;
    }

    public void setPaidAmt(String paidAmt) {
        this.paidAmt = paidAmt;
    }

    public String getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(String totalCost) {
        this.totalCost = totalCost;
    }

    @Override
    public String toString() {
        return "RxClaim{" +
                "pharmacyClaimId=" + pharmacyClaimId +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", payerClaimControlNumber='" + payerClaimControlNumber + '\'' +
                ", prescribingClientProviderId='" + prescribingClientProviderId + '\'' +
                ", dispensedDate='" + dispensedDate + '\'' +
                ", claimStatusCode='" + claimStatusCode + '\'' +
                ", dispensedSupplyDayCount='" + dispensedSupplyDayCount + '\'' +
                ", supplementalSourceCode='" + supplementalSourceCode + '\'' +
                ", ndc='" + ndc + '\'' +
                ", patientPlaceOfServiceCode='" + patientPlaceOfServiceCode + '\'' +
                ", rxClaimAltIds=" + rxClaimAltIds +
                ", feedInstanceId='" + feedInstanceId + '\'' +
                ", udfActiveInd='" + udfActiveInd + '\'' +
                ", prescribingNpi='" + prescribingNpi + '\'' +
                ", dispensingNpi='" + dispensingNpi + '\'' +
                ", metricQuantity='" + metricQuantity + '\'' +
                ", ingredientCostPaidAmt='" + ingredientCostPaidAmt + '\'' +
                ", prescribingDea='" + prescribingDea + '\'' +
                ", allowedAmt='" + allowedAmt + '\'' +
                ", chargeAmt='" + chargeAmt + '\'' +
                ", copayAmt='" + copayAmt + '\'' +
                ", paidAmt='" + paidAmt + '\'' +
                ", totalCost='" + totalCost + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RxClaim rxClaim = (RxClaim) o;

        if (pharmacyClaimId != rxClaim.pharmacyClaimId) return false;
        if (feedInstanceId != rxClaim.feedInstanceId) return false;
        if (udfActiveInd != rxClaim.udfActiveInd) return false;
        if (clientMemberId != null ? !clientMemberId.equals(rxClaim.clientMemberId) : rxClaim.clientMemberId != null)
            return false;
        if (payerClaimControlNumber != null ? !payerClaimControlNumber.equals(rxClaim.payerClaimControlNumber) : rxClaim.payerClaimControlNumber != null)
            return false;
        if (prescribingClientProviderId != null ? !prescribingClientProviderId.equals(rxClaim.prescribingClientProviderId) : rxClaim.prescribingClientProviderId != null)
            return false;
        if (dispensedDate != null ? !dispensedDate.equals(rxClaim.dispensedDate) : rxClaim.dispensedDate != null)
            return false;
        if (claimStatusCode != null ? !claimStatusCode.equals(rxClaim.claimStatusCode) : rxClaim.claimStatusCode != null)
            return false;
        if (dispensedSupplyDayCount != null ? !dispensedSupplyDayCount.equals(rxClaim.dispensedSupplyDayCount) : rxClaim.dispensedSupplyDayCount != null)
            return false;
        if (supplementalSourceCode != null ? !supplementalSourceCode.equals(rxClaim.supplementalSourceCode) : rxClaim.supplementalSourceCode != null)
            return false;
        if (ndc != null ? !ndc.equals(rxClaim.ndc) : rxClaim.ndc != null) return false;
        if (patientPlaceOfServiceCode != null ? !patientPlaceOfServiceCode.equals(rxClaim.patientPlaceOfServiceCode) : rxClaim.patientPlaceOfServiceCode != null)
            return false;
        if (rxClaimAltIds != null ? !rxClaimAltIds.equals(rxClaim.rxClaimAltIds) : rxClaim.rxClaimAltIds != null)
            return false;
        if (prescribingNpi != null ? !prescribingNpi.equals(rxClaim.prescribingNpi) : rxClaim.prescribingNpi != null)
            return false;
        if (dispensingNpi != null ? !dispensingNpi.equals(rxClaim.dispensingNpi) : rxClaim.dispensingNpi != null)
            return false;
        if (metricQuantity != null ? !metricQuantity.equals(rxClaim.metricQuantity) : rxClaim.metricQuantity != null)
            return false;
        if (ingredientCostPaidAmt != null ? !ingredientCostPaidAmt.equals(rxClaim.ingredientCostPaidAmt) : rxClaim.ingredientCostPaidAmt != null)
            return false;
        if (prescribingDea != null ? !prescribingDea.equals(rxClaim.prescribingDea) : rxClaim.prescribingDea != null)
            return false;
        if (allowedAmt != null ? !allowedAmt.equals(rxClaim.allowedAmt) : rxClaim.allowedAmt != null) return false;
        if (chargeAmt != null ? !chargeAmt.equals(rxClaim.chargeAmt) : rxClaim.chargeAmt != null) return false;
        if (copayAmt != null ? !copayAmt.equals(rxClaim.copayAmt) : rxClaim.copayAmt != null) return false;
        if (paidAmt != null ? !paidAmt.equals(rxClaim.paidAmt) : rxClaim.paidAmt != null) return false;
        return totalCost != null ? totalCost.equals(rxClaim.totalCost) : rxClaim.totalCost == null;
    }

    @Override
    public int hashCode() {
        int result = pharmacyClaimId;
        result = 31 * result + (clientMemberId != null ? clientMemberId.hashCode() : 0);
        result = 31 * result + (payerClaimControlNumber != null ? payerClaimControlNumber.hashCode() : 0);
        result = 31 * result + (prescribingClientProviderId != null ? prescribingClientProviderId.hashCode() : 0);
        result = 31 * result + (dispensedDate != null ? dispensedDate.hashCode() : 0);
        result = 31 * result + (claimStatusCode != null ? claimStatusCode.hashCode() : 0);
        result = 31 * result + (dispensedSupplyDayCount != null ? dispensedSupplyDayCount.hashCode() : 0);
        result = 31 * result + (supplementalSourceCode != null ? supplementalSourceCode.hashCode() : 0);
        result = 31 * result + (ndc != null ? ndc.hashCode() : 0);
        result = 31 * result + (patientPlaceOfServiceCode != null ? patientPlaceOfServiceCode.hashCode() : 0);
        result = 31 * result + (rxClaimAltIds != null ? rxClaimAltIds.hashCode() : 0);
        result = 31 * result + feedInstanceId;
        result = 31 * result + udfActiveInd;
        result = 31 * result + (prescribingNpi != null ? prescribingNpi.hashCode() : 0);
        result = 31 * result + (dispensingNpi != null ? dispensingNpi.hashCode() : 0);
        result = 31 * result + (metricQuantity != null ? metricQuantity.hashCode() : 0);
        result = 31 * result + (ingredientCostPaidAmt != null ? ingredientCostPaidAmt.hashCode() : 0);
        result = 31 * result + (prescribingDea != null ? prescribingDea.hashCode() : 0);
        result = 31 * result + (allowedAmt != null ? allowedAmt.hashCode() : 0);
        result = 31 * result + (chargeAmt != null ? chargeAmt.hashCode() : 0);
        result = 31 * result + (copayAmt != null ? copayAmt.hashCode() : 0);
        result = 31 * result + (paidAmt != null ? paidAmt.hashCode() : 0);
        result = 31 * result + (totalCost != null ? totalCost.hashCode() : 0);
        return result;
    }
}

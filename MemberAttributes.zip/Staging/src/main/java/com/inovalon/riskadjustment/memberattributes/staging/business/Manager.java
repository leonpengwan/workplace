package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.business.message.StagingMessageProducer;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.InterventionPlanAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.MemberEvidenceAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.StagingMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlanRun;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.staging.util.LocalCacheObject;
import com.inovalon.riskadjustment.memberattributes.staging.util.RetrieveInterventionPlanPeriod;
import com.inovalon.riskadjustment.memberattributes.staging.util.StagingUtil;
import com.inovalon.riskadjustment.model.enums.Status;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.GapDataSelection;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class Manager {
    @Autowired
    RetrieveInterventionPlan retrieveInterventionPlans;
    @Autowired
    RetrieveInterventionPlanPeriod retrieveInterventionPlanPeriod;
    @Autowired
    private StagingMessageProducer stagingMessageProducer;
    @Autowired
    private LocalCacheObject localCacheObject;
    @Autowired
    private RunProfileRetrieve runProfileRetrieve;
    @Autowired
    private GapSetDetailIdentification gapSetDetailIdentification;
    @Autowired
    private MemberEvidenceStaging memberEvidenceStaging;
    @Autowired
    private RunRetrieveAndStatusUpdate runRetrieveAndStatusUpdate;
    @Autowired
    private PatientProfileStaging patientProfileStaging;
    @Autowired
    private StagingUtil stagingUtil;
    @Autowired
    private ProviderProfileStaging providerProfileStaging;
    @Autowired
    private InterventionPlanStaging interventionPlanRetrieve;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method is to control data flow
     *
     * @param runProfileId
     * @return
     * @throws Exception
     */
    @LogBeforeEvents
    public boolean manage( long runProfileId ) throws Exception {
        logWriter.info("Beginning of Manage method");

        try {

            int memberAttributesRunId = runRetrieveAndStatusUpdate.retrieveRunId(runProfileId);

            logWriter.info("MemberAttributesRunId:" + memberAttributesRunId);

            if (memberAttributesRunId != 0) {
                boolean statusUpdate = runRetrieveAndStatusUpdate.updateStatus(runProfileId, Status.INPROGRESS);

                // Get run profile
                RunProfile runProfile = runProfileRetrieve.getRunProfileByRunProfileId(runProfileId);

                // Get selected gapset section
                GapDataSelection gapDataSelection = gapSetDetailIdentification.getGapSetDetail(runProfile);
                String gapSetId = gapDataSelection.getGapSetId();

                logWriter.info("GapSetID:" + gapSetId);

                localCacheObject.setRunProfileId(runProfileId);
                localCacheObject.setGapSetId(gapSetId);
                localCacheObject.setMemberId(0);

                // Get data by batch
                while (true) {

                    List<Integer> memberIds = memberEvidenceStaging.stageMemberIds(gapSetId, localCacheObject.getMemberId());

                    logWriter.info("List of MemberIds " + memberIds);

                    // if get null member or 0 in the list
                    // break loop
                    if (memberIds != null) {
                        if (memberIds.size() == 0) {
                            break;
                        }
                    }
                    Date lookBackDate = retrieveInterventionPlanPeriod.getInterventionPlanPeriod(runProfileId);

                    Date planningDate = runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod().getStart();

                    List<InterventionPlanRun> interventionPlanRuns = retrieveInterventionPlans.retrieveInterventionPlanData(runProfile.getClientId(), lookBackDate, planningDate, 4);

                    logWriter.info("InterventionPlanRuns:" + interventionPlanRuns);

                    List<Integer> interventionPlanRunIds = interventionPlanRuns.stream().map(interventionPlanRun -> interventionPlanRun.getInterventionPlanRunId()).collect(Collectors.toList());

                    logWriter.info("InterventionPlanRunIds:" + interventionPlanRunIds);

                    List<InterventionPlan> interventionPlans = interventionPlanRetrieve.getInterventionPlanData(interventionPlanRunIds);

                    // Collect all member evidences
                    List<MemberEvidence> memberEvidences = memberEvidenceStaging.stageMemberEvidences(gapSetId, localCacheObject.getMemberId(), memberIds);

                    logWriter.info("MemberEvidences:" + memberEvidences);

                    // Collect all patient profiles
                    List<PatientProfile> patientProfiles = patientProfileStaging.stagePatientProfile(memberIds, runProfile);

                    memberEvidences.sort(Comparator.naturalOrder());

                    logWriter.info("Staging member evidence successfully to the last memberId = " + memberIds.get(memberIds.size() - 1));

                    for (int memberId : memberIds) {

                        StagingMessageAvro stagingMessageAvro = new StagingMessageAvro();
                        stagingMessageAvro.setRunProfileId(runProfileId);
                        stagingMessageAvro.setMemberAttributesRunId(memberAttributesRunId);

                        List<MemberEvidenceAvro> memberEvidenceAvros = new ArrayList<>();
                        List<MemberEvidence> localMemberEvidences = memberEvidences.stream().filter(p -> p.getMemberId() == memberId).collect(Collectors.toList());

                        stagingUtil.getMemberEvidences(memberEvidenceAvros, localMemberEvidences);
                        stagingMessageAvro.setMemberEvidences(memberEvidenceAvros);

                        List<InterventionPlanAvro> interventionPlanAvros = stagingUtil.getInterventionPlanAvros(interventionPlans, memberId);

                        stagingMessageAvro.setInterventionPlans(interventionPlanAvros);

                        PatientProfile localPatientProfile = patientProfiles.stream().filter(p -> p.getMemberId() == memberId).findAny().orElse(null);
                        if (localPatientProfile != null) {

                            List<String> clientProviderIds = localPatientProfile.getEnrollments().stream().map(enrollment -> enrollment.getClientProviderId()).collect(Collectors.toList());

                            List<ProviderProfile> providerProfiles = providerProfileStaging.stageProviderProfile(clientProviderIds, runProfile);

                            stagingUtil.getPatientProfile(stagingMessageAvro, localPatientProfile);

                            stagingUtil.getProviderProfile(stagingMessageAvro, providerProfiles);
                        }

                        // Produce avro message into kafka

                        this.stagingMessageProducer.produceStagingMessage(stagingMessageAvro);

                        logWriter.info("Staging pushed member id " + memberId + " to worker process queue");
                        // Update cache object
                        localCacheObject.setMemberId(memberId);

                        logWriter.info("Ending of Manage method");

                    }
                }
            } else {
                logWriter.info("MemberAttributesStaging: No MemberAttributesRunId found for runProfileId = " + runProfileId);
                return false;
            }
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
        }
        return true;
    }

}

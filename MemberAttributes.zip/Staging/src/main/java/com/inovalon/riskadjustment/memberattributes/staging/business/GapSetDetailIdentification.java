package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.GapDataSelection;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
public class GapSetDetailIdentification {
    private static Logger logger;
    @Autowired
    private Gateway gateway;
    @Autowired
    private LogWriter logWriter;
    @LogBeforeEvents
    public GapDataSelection getGapSetDetail( RunProfile runProfile ) throws Exception {
        logWriter.info("Beginning of getGapSetDetail method");
        GapDataSelection gapDataSelection = new GapDataSelection();
        try {
            // only return the selected gapset summary info
            gapDataSelection = runProfile.getSections().getGapDataSelection().getGapDataSelections().stream().filter(
                    f -> f.getSelected()).collect(Collectors.toList()).get(0);
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);

        }
        logWriter.info("Ending of getGapSetDetail method");
        return gapDataSelection;
    }
}

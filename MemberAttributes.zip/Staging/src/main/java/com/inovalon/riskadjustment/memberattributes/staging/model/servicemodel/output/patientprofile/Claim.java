package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile;

import java.util.List;

public class Claim {

    private int claimId;
    private String payerClaimControlNumber;
    private String cost;
    private String admissionDate;
    private String dischargeDate;
    private String supplementalSourceCode;
    private String patientStatusCode;
    private String claimStatusCode;
    private String deniedDayOrVisitCount;
    private String roomBoardInd;
    private String majorSurgeryInd;
    private String serviceUnitCount;
    private String excludeFromDischargeInd;
    private String pcpInd;
    private String clientProviderId;
    private String clientMemberId;
    private String presentOnAdmission;
    private String feedInstanceId;
    private String udfActiveInd;
    private List<List<String>> icddxCodes;
    private List<List<String>> icdpxCodes;
    private List<List<String>> icddx10Codes;
    private List<List<String>> icdpx10codes;
    private List<String> cptpxCodes;
    private List<String> hcpcspxCodes;
    private List<String> providerSpecialty;
    private List<String> tob;
    private List<List<String>> hpx;
    private List<String> drgCodes;
    private List<String> msdrgCodes;
    private List<String> apdrgCodes;
    private List<String> aprdrgCodes;
    private List<String> claimAltIds;
    private List<String> cptModCodes;
    private List<String> hcfaposCodes;
    private List<String> hcpcsModCodes;
    private List<String> providerTypeCodes;
    private List<String> ubRevenueCodes;

    public Claim(){}

    public Claim(int claimId, String payerClaimControlNumber, String cost, String admissionDate, String dischargeDate, String supplementalSourceCode, String patientStatusCode, String claimStatusCode, String deniedDayOrVisitCount, String roomBoardInd, String majorSurgeryInd, String serviceUnitCount, String excludeFromDischargeInd, String pcpInd, String clientProviderId, String clientMemberId, String presentOnAdmission, String feedInstanceId, String udfActiveInd, List<List<String>> icddxCodes, List<List<String>> icdpxCodes, List<List<String>> icddx10Codes, List<List<String>> icdpx10codes, List<String> cptpxCodes, List<String> hcpcspxCodes, List<String> providerSpecialty, List<String> tob, List<List<String>> hpx, List<String> drgCodes, List<String> msdrgCodes, List<String> apdrgCodes, List<String> aprdrgCodes, List<String> claimAltIds, List<String> cptModCodes, List<String> hcfaposCodes, List<String> hcpcsModCodes, List<String> providerTypeCodes, List<String> ubRevenueCodes) {
        this.claimId = claimId;
        this.payerClaimControlNumber = payerClaimControlNumber;
        this.cost = cost;
        this.admissionDate = admissionDate;
        this.dischargeDate = dischargeDate;
        this.supplementalSourceCode = supplementalSourceCode;
        this.patientStatusCode = patientStatusCode;
        this.claimStatusCode = claimStatusCode;
        this.deniedDayOrVisitCount = deniedDayOrVisitCount;
        this.roomBoardInd = roomBoardInd;
        this.majorSurgeryInd = majorSurgeryInd;
        this.serviceUnitCount = serviceUnitCount;
        this.excludeFromDischargeInd = excludeFromDischargeInd;
        this.pcpInd = pcpInd;
        this.clientProviderId = clientProviderId;
        this.clientMemberId = clientMemberId;
        this.presentOnAdmission = presentOnAdmission;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.icddxCodes = icddxCodes;
        this.icdpxCodes = icdpxCodes;
        this.icddx10Codes = icddx10Codes;
        this.icdpx10codes = icdpx10codes;
        this.cptpxCodes = cptpxCodes;
        this.hcpcspxCodes = hcpcspxCodes;
        this.providerSpecialty = providerSpecialty;
        this.tob = tob;
        this.hpx = hpx;
        this.drgCodes = drgCodes;
        this.msdrgCodes = msdrgCodes;
        this.apdrgCodes = apdrgCodes;
        this.aprdrgCodes = aprdrgCodes;
        this.claimAltIds = claimAltIds;
        this.cptModCodes = cptModCodes;
        this.hcfaposCodes = hcfaposCodes;
        this.hcpcsModCodes = hcpcsModCodes;
        this.providerTypeCodes = providerTypeCodes;
        this.ubRevenueCodes = ubRevenueCodes;
    }

    //    public ClaimIdObject getClaimId() {
//        return claimId;
//    }
//
//    public void setClaimId(ClaimIdObject claimId) {
//        this.claimId = claimId;
//    }
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public String getPayerClaimControlNumber() {
        return payerClaimControlNumber;
    }

    public void setPayerClaimControlNumber(String payerClaimControlNumber) {
        this.payerClaimControlNumber = payerClaimControlNumber;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        this.admissionDate = admissionDate;
    }

    public String getDischargeDate() {
        return dischargeDate;
    }

    public void setDischargeDate(String dischargeDate) {
        this.dischargeDate = dischargeDate;
    }

    public String getSupplementalSourceCode() {
        return supplementalSourceCode;
    }

    public void setSupplementalSourceCode(String supplementalSourceCode) {
        this.supplementalSourceCode = supplementalSourceCode;
    }

    public String getPatientStatusCode() {
        return patientStatusCode;
    }

    public void setPatientStatusCode(String patientStatusCode) {
        this.patientStatusCode = patientStatusCode;
    }

    public String getClaimStatusCode() {
        return claimStatusCode;
    }

    public void setClaimStatusCode(String claimStatusCode) {
        this.claimStatusCode = claimStatusCode;
    }

    public String getDeniedDayOrVisitCount() {
        return deniedDayOrVisitCount;
    }

    public void setDeniedDayOrVisitCount(String deniedDayOrVisitCount) {
        this.deniedDayOrVisitCount = deniedDayOrVisitCount;
    }

    public String getRoomBoardInd() {
        return roomBoardInd;
    }

    public void setRoomBoardInd(String roomBoardInd) {
        this.roomBoardInd = roomBoardInd;
    }

    public String getMajorSurgeryInd() {
        return majorSurgeryInd;
    }

    public void setMajorSurgeryInd(String majorSurgeryInd) {
        this.majorSurgeryInd = majorSurgeryInd;
    }

    public String getServiceUnitCount() {
        return serviceUnitCount;
    }

    public void setServiceUnitCount(String serviceUnitCount) {
        this.serviceUnitCount = serviceUnitCount;
    }

    public String getExcludeFromDischargeInd() {
        return excludeFromDischargeInd;
    }

    public void setExcludeFromDischargeInd(String excludeFromDischargeInd) {
        this.excludeFromDischargeInd = excludeFromDischargeInd;
    }

    public String getPcpInd() {
        return pcpInd;
    }

    public void setPcpInd(String pcpInd) {
        this.pcpInd = pcpInd;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getPresentOnAdmission() {
        return presentOnAdmission;
    }

    public void setPresentOnAdmission(String presentOnAdmission) {
        this.presentOnAdmission = presentOnAdmission;
    }

    public String getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(String feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public String getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(String udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    public List<List<String>> getIcddxCodes() {
        return icddxCodes;
    }

    public void setIcddxCodes(List<List<String>> icddxCodes) {
        this.icddxCodes = icddxCodes;
    }

    public List<List<String>> getIcdpxCodes() {
        return icdpxCodes;
    }

    public void setIcdpxCodes(List<List<String>> icdpxCodes) {
        this.icdpxCodes = icdpxCodes;
    }

    public List<List<String>> getIcddx10Codes() {
        return icddx10Codes;
    }

    public void setIcddx10Codes(List<List<String>> icddx10Codes) {
        this.icddx10Codes = icddx10Codes;
    }

    public List<List<String>> getIcdpx10codes() {
        return icdpx10codes;
    }

    public void setIcdpx10codes(List<List<String>> icdpx10codes) {
        this.icdpx10codes = icdpx10codes;
    }

    public List<String> getCptpxCodes() {
        return cptpxCodes;
    }

    public void setCptpxCodes(List<String> cptpxCodes) {
        this.cptpxCodes = cptpxCodes;
    }

    public List<String> getHcpcspxCodes() {
        return hcpcspxCodes;
    }

    public void setHcpcspxCodes(List<String> hcpcspxCodes) {
        this.hcpcspxCodes = hcpcspxCodes;
    }

    public List<String> getProviderSpecialty() {
        return providerSpecialty;
    }

    public void setProviderSpecialty(List<String> providerSpecialty) {
        this.providerSpecialty = providerSpecialty;
    }

    public List<String> getTob() {
        return tob;
    }

    public void setTob(List<String> tob) {
        this.tob = tob;
    }

    public List<List<String>> getHpx() {
        return hpx;
    }

    public void setHpx(List<List<String>> hpx) {
        this.hpx = hpx;
    }

    public List<String> getDrgCodes() {
        return drgCodes;
    }

    public void setDrgCodes(List<String> drgCodes) {
        this.drgCodes = drgCodes;
    }

    public List<String> getMsdrgCodes() {
        return msdrgCodes;
    }

    public void setMsdrgCodes(List<String> msdrgCodes) {
        this.msdrgCodes = msdrgCodes;
    }

    public List<String> getApdrgCodes() {
        return apdrgCodes;
    }

    public void setApdrgCodes(List<String> apdrgCodes) {
        this.apdrgCodes = apdrgCodes;
    }

    public List<String> getAprdrgCodes() {
        return aprdrgCodes;
    }

    public void setAprdrgCodes(List<String> aprdrgCodes) {
        this.aprdrgCodes = aprdrgCodes;
    }

    public List<String> getClaimAltIds() {
        return claimAltIds;
    }

    public void setClaimAltIds(List<String> claimAltIds) {
        this.claimAltIds = claimAltIds;
    }

    public List<String> getCptModCodes() {
        return cptModCodes;
    }

    public void setCptModCodes(List<String> cptModCodes) {
        this.cptModCodes = cptModCodes;
    }

    public List<String> getHcfaposCodes() {
        return hcfaposCodes;
    }

    public void setHcfaposCodes(List<String> hcfaposCodes) {
        this.hcfaposCodes = hcfaposCodes;
    }

    public List<String> getHcpcsModCodes() {
        return hcpcsModCodes;
    }

    public void setHcpcsModCodes(List<String> hcpcsModCodes) {
        this.hcpcsModCodes = hcpcsModCodes;
    }

    public List<String> getProviderTypeCodes() {
        return providerTypeCodes;
    }

    public void setProviderTypeCodes(List<String> providerTypeCodes) {
        this.providerTypeCodes = providerTypeCodes;
    }

    public List<String> getUbRevenueCodes() {
        return ubRevenueCodes;
    }

    public void setUbRevenueCodes(List<String> ubRevenueCodes) {
        this.ubRevenueCodes = ubRevenueCodes;
    }


    @Override
    public String toString() {
        return "ClaimDTO{" +
                "claimId='" + claimId + '\'' +
                ", payerClaimControlNumber='" + payerClaimControlNumber + '\'' +
                ", cost='" + cost + '\'' +
                ", admissionDate='" + admissionDate + '\'' +
                ", dischargeDate='" + dischargeDate + '\'' +
                ", supplementalSourceCode='" + supplementalSourceCode + '\'' +
                ", patientStatusCode='" + patientStatusCode + '\'' +
                ", claimStatusCode='" + claimStatusCode + '\'' +
                ", deniedDayOrVisitCount='" + deniedDayOrVisitCount + '\'' +
                ", roomBoardInd='" + roomBoardInd + '\'' +
                ", majorSurgeryInd='" + majorSurgeryInd + '\'' +
                ", serviceUnitCount='" + serviceUnitCount + '\'' +
                ", excludeFromDischargeInd='" + excludeFromDischargeInd + '\'' +
                ", pcpInd='" + pcpInd + '\'' +
                ", clientProviderId='" + clientProviderId + '\'' +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", presentOnAdmission='" + presentOnAdmission + '\'' +
                ", feedInstanceId='" + feedInstanceId + '\'' +
                ", udfActiveInd='" + udfActiveInd + '\'' +
                ", icddxCodes=" + icddxCodes +
                ", icdpxCodes=" + icdpxCodes +
                ", icddx10Codes=" + icddx10Codes +
                ", icdpx10codes=" + icdpx10codes +
                ", cptpxCodes=" + cptpxCodes +
                ", hcpcspxCodes=" + hcpcspxCodes +
                ", providerSpecialty=" + providerSpecialty +
                ", tob=" + tob +
                ", hpx=" + hpx +
                ", drgCodes=" + drgCodes +
                ", msdrgCodes=" + msdrgCodes +
                ", apdrgCodes=" + apdrgCodes +
                ", aprdrgCodes=" + aprdrgCodes +
                ", claimAltIds=" + claimAltIds +
                ", cptModCodes=" + cptModCodes +
                ", hcfaposCodes=" + hcfaposCodes +
                ", hcpcsModCodes=" + hcpcsModCodes +
                ", providerTypeCodes=" + providerTypeCodes +
                ", ubRevenueCodes=" + ubRevenueCodes +
                '}';
    }
}

package com.inovalon.riskadjustment.memberattributes.staging.service;

import com.inovalon.riskadjustment.memberattributes.staging.business.Manager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/memberAttributesStaging")
@Api
public class StagingController {
    @Autowired
    private Manager manager;

    @ApiOperation(value = "Invocation of Staging starts here, which accepts runprofileId")
    @GetMapping(value = "stage")
    public void stage(@RequestParam(value="runProfileId", required = true) Long runProfileId) throws Exception{
        manager.manage(runProfileId);
    }
}

package com.inovalon.riskadjustment.memberattributes.staging.util;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ProviderProfilePayload<T> {

    @JsonProperty(value = "clientShortName")
    public String clientShortName;

    @JsonProperty(value = "projectShortName")
    public String projectShortName;

    @JsonProperty(value = "ids")
    public List<T> ids;

}

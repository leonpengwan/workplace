package com.inovalon.riskadjustment.memberattributes;

import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.StagingMessage;
import com.inovalon.riskadjustment.shared.messagebus.common.Utilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan("com.inovalon.riskadjustment")
public class StagingMain {

    @Autowired
    StagingConfiguration stagingConfiguration;
    public static void main(String[] args) {
        SpringApplication.run(StagingMain.class, args);

        //System.out.println(Utilities.getAvroSchema(new WorkerProcess()));
    }

    @PostConstruct
    private void initialize() {

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++++++ SERVICE STARTED  ++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Config-test:" + stagingConfiguration.toString() );
    }
}

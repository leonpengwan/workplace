package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlanData;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class InterventionPlanStaging extends Gateway {
    private static Logger logger;
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;
    @Autowired
    private Gateway gateway;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the list of intervention plans based on interventionPlanRunId
     *
     * @param interventionPlanRunIds
     * @return It returns list of interventionPlans   *
     * @throws JsonProcessingException
     */
    @LogBeforeEvents
    @LogAfterEvents
    public List<InterventionPlan> getInterventionPlanData( List<Integer> interventionPlanRunIds ) throws Exception {
        logWriter.info("Beginning of getInterventionPlanData method");
        List<InterventionPlan> interventionPlans = new ArrayList<>();

        try {
            InterventionPlanData interventionPlanData = new InterventionPlanData();
            interventionPlanData.interventionPlanRunIds = interventionPlanRunIds;
            String url = stagingConfiguration.getResultsDatabaseServiceBaseUrl() + MemberAttributesConstants.GET_INTERVENTION_PLANS;
            String json = objectMapper.writeValueAsString(interventionPlanData);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(json, headers);
            ResponseEntity<List<InterventionPlan>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<InterventionPlan>>() {
            });
            interventionPlans = responseEntity.getBody();
            logWriter.info("InterventionPlan:" + interventionPlans);
        } catch (RestClientException restException) {
            logWriter.error(restException.getMessage(), restException);
        }
        logWriter.info("Ending of getInterventionPlanData method");
        return interventionPlans;
    }
}


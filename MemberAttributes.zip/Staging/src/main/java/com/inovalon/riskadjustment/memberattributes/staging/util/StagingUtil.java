package com.inovalon.riskadjustment.memberattributes.staging.util;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.InterventionPlanAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.MemberEvidenceAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.StagingMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.patientprofile.*;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.ProviderProfileAvro;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile.*;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile.Address;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile.AlternateIds;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile.Name;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile.ProviderProfile;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class StagingUtil {
    @LogBeforeEvents
    public static List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AddressAvro> modelToAvro( List<Address> addresses ) {
        List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AddressAvro> addressList = new ArrayList<>();

        for (Address address : addresses) {
            com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AddressAvro addressAvro = new com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AddressAvro();
            addressAvro.setAddressActivationDate(address.getAddressActivationDate());
            addressAvro.setAddressLine1(address.getAddressLine1());
            addressAvro.setAddressLine2(address.getAddressLine2());
            addressAvro.setAddressRetirementDate(address.getAddressRetirementDate());
            addressAvro.setAddressType(address.getAddressType());
            addressAvro.setCity(address.getCity());
            addressAvro.setState(address.getState());
            addressAvro.setPhoneNumber2(address.getPhoneNumber2());
            addressAvro.setFaxNumber1(address.getFaxNumber1());
            addressAvro.setLocationKey(address.getLocationKey());
            addressAvro.setPhone(address.getPhone());
            addressAvro.setPhoneNumber2(address.getPhoneNumber2());
            addressAvro.setProviderId(address.getProviderId());
            addressAvro.setZip(address.getZip());
            addressList.add(addressAvro);


        }
        return addressList;
    }
    @LogAfterEvents
    public static List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.NameAvro> modelToAvroNameList( List<Name> names ) {
        List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.NameAvro> namesList = new ArrayList<>();

        for (Name name : names) {
            com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.NameAvro nameAvro = new com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.NameAvro();
            nameAvro.setFirstName(name.getFirstName() == null ? null : name.getFirstName());

            nameAvro.setFullName(name.getFullName() == null ? null : name.getFullName());
            nameAvro.setLastName(name.getLastName() == null ? null : name.getFullName());
            nameAvro.setMiddleName(name.getMiddleName() == null ? null : name.getFullName());
            nameAvro.setNameActivationDate(name.getNameActivationDate());
            nameAvro.setNameRetirementDate(name.getNameRetirementDate());
            nameAvro.setNameType(name.getNameType());
            nameAvro.setProviderId(name.getProviderId());

            namesList.add(nameAvro);

        }
        return namesList;
    }

    public static List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AlternateIdsAvro> modelToAvroAltIds( List<AlternateIds> alternateIds ) {
        List<com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AlternateIdsAvro> alternateIdsAvroList = new ArrayList<>();

        for (AlternateIds alternateId : alternateIds) {
            com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AlternateIdsAvro alternateIdsAvro = new com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.providerprofile.AlternateIdsAvro();
            alternateIdsAvro.setProviderAltId1(alternateId.getProviderAltId1());
            alternateIdsAvro.setProviderAltId2(alternateId.getProviderAltId2() == null ? null : alternateId.getProviderAltId2());
            alternateIdsAvro.setProviderAltid3(alternateId.getProviderAltid3());
            alternateIdsAvro.setProviderAltId4(alternateId.getProviderAltId4());
            alternateIdsAvro.setProviderAltId2(alternateId.getProviderAltId5() == null ? null : alternateId.getProviderAltId5());
            //  alternateIdsAvro.setProviderAltId5(alternateId.getProviderAltId5());
            alternateIdsAvro.setProviderAltId6(alternateId.getProviderAltId6());
            alternateIdsAvro.setProviderAltId7(alternateId.getProviderAltId7() == null ? null : alternateId.getProviderAltId7());
            alternateIdsAvro.setProviderAltid8(alternateId.getProviderAltid8());
            alternateIdsAvro.setProviderAltid9(alternateId.getProviderAltid9() == null ? null : alternateId.getProviderAltId7());
            alternateIdsAvro.setProviderAltId10(alternateId.getProviderAltId10() == null ? null : alternateId.getProviderAltId7());
            alternateIdsAvro.setProviderId(alternateId.getProviderId());

            alternateIdsAvroList.add(alternateIdsAvro);

        }
        return alternateIdsAvroList;
    }
    @LogAfterEvents
    public void getMemberEvidences( List<MemberEvidenceAvro> memberEvidenceAvros, List<MemberEvidence> localMemberEvidences ) {
        for (MemberEvidence memberEvidence : localMemberEvidences) {
            MemberEvidenceAvro memberEvidenceAvro = new MemberEvidenceAvro();

            memberEvidenceAvro.setMemberEvidenceId(memberEvidence.getMemberEvidenceId());
            memberEvidenceAvro.setMemberId(memberEvidence.getMemberId());
            memberEvidenceAvro.setPersonId(memberEvidence.getPersonId());
            memberEvidenceAvro.setPractitionerId(memberEvidence.getPractitionerId());
            memberEvidenceAvro.setEncounterId(memberEvidence.getEncounterId());
            //memberEvidenceAvro.setEncounterServiceDate(memberEvidence.getEncounterServiceDate()); // comment out because avro is unable to parse any time data type
            memberEvidenceAvro.setHcc(memberEvidence.getHcc());
            memberEvidenceAvro.setGapConfidenceValue(memberEvidence.getGapConfidenceValue());
            memberEvidenceAvro.setGapConfidenceLevel(memberEvidence.getGapConfidenceLevel());
            memberEvidenceAvro.setGapType(memberEvidence.getGapType());
            memberEvidenceAvro.setMeasureKey(memberEvidence.getMeasureKey());
            memberEvidenceAvro.setSaGapValue(memberEvidence.getSaGapValue());


            memberEvidenceAvros.add(memberEvidenceAvro);
        }
    }
    @LogAfterEvents
    public List<InterventionPlanAvro> getInterventionPlanAvros( List<InterventionPlan> interventionPlans, int memberId ) {
        List<InterventionPlanAvro> interventionPlanAvros = new ArrayList<>();
        if (interventionPlans != null && interventionPlans.size() > 0) {


            List<InterventionPlan> localInterventionPlans = interventionPlans.stream().filter(p -> p.getMemberId() == memberId).collect(Collectors.toList());

            for (InterventionPlan interventionPlan : localInterventionPlans) {
                InterventionPlanAvro interventionPlanAvro = new InterventionPlanAvro();
                interventionPlanAvro.setInterventionPlanRunId(interventionPlan.getInterventionPlanRunId());
                interventionPlanAvro.setInterventionPlanId(interventionPlan.getInterventionPlanId());
                interventionPlanAvro.setInterventionTypeId(interventionPlan.getInterventionTypeId());
                interventionPlanAvro.setMemberId(interventionPlan.getMemberId());
                interventionPlanAvro.setPersonId(interventionPlan.getPersonId() == null ? null : interventionPlan.getPersonId());
                interventionPlanAvro.setInterventionYear(interventionPlan.getInterventionYear());
                interventionPlanAvro.setInterventionMonth(interventionPlan.getInterventionMonth());
                interventionPlanAvro.setInterventionPrefix(interventionPlan.getInterventionPrefix() == null ? null : interventionPlan.getInterventionPrefix());

                interventionPlanAvros.add(interventionPlanAvro);
            }
        }
        return interventionPlanAvros;
    }

    public void getPatientProfile( StagingMessageAvro stagingMessageAvro, PatientProfile patientProfile ) {
        PatientProfileAvro patientProfileAvro = new PatientProfileAvro();

        patientProfileAvro.setMemberId(patientProfile.getMemberId());
        patientProfileAvro.setAddressLine1(patientProfile.getAddressLine1());
        patientProfileAvro.setAddressLine2(patientProfile.getAddressLine2());
        patientProfileAvro.setBirthDate(patientProfile.getBirthDate());
        patientProfileAvro.setCity(patientProfile.getCity());
        patientProfileAvro.setClientMemberId(patientProfile.getClientMemberId());
        patientProfileAvro.setCounty(patientProfile.getCounty());
        patientProfileAvro.setDeceasedDate(patientProfile.getDeceasedDate());
        patientProfileAvro.setEmailAddress(patientProfile.getEmailAddress());
        patientProfileAvro.setEmailUsagePreferenceCode(patientProfile.getEmailUsagePreferenceCode());
        patientProfileAvro.setEmailUsageTypeCode(patientProfile.getEmailUsageTypeCode());
        patientProfileAvro.setEthnicityCode(patientProfile.getEthnicityCode());
        patientProfileAvro.setEthnicitySource(patientProfile.getEthnicitySource());
        patientProfileAvro.setZip(patientProfile.getZip());
        patientProfileAvro.setEthnicityType(patientProfile.getEthnicityType());
        patientProfileAvro.setFirstName(patientProfile.getFirstName());
        patientProfileAvro.setFullName(patientProfile.getFullName());
        patientProfileAvro.setGenderCode(patientProfile.getGenderCode());
        patientProfileAvro.setLastName(patientProfile.getLastName());
        patientProfileAvro.setLanguageOther(patientProfile.getLanguageOther());
        patientProfileAvro.setLanguageOtherSource(patientProfile.getLanguageOtherSource());
        patientProfileAvro.setLanguageSpokenSource(patientProfile.getLanguageSpokenSource());
        patientProfileAvro.setLanguagesWritten(patientProfile.getLanguagesWritten());
        patientProfileAvro.setMaritalStatus(patientProfile.getMaritalStatus());
        patientProfileAvro.setEthnicityType(patientProfile.getEthnicityType());
        patientProfileAvro.setMedicaidId(patientProfile.getMedicaidId());
        patientProfileAvro.setMemberIdentifier1(patientProfile.getMemberIdentifier1());
        patientProfileAvro.setMemberIdentifier2(patientProfile.getMemberIdentifier2());
        patientProfileAvro.setMemberIdentifier3(patientProfile.getMemberIdentifier3());
        patientProfileAvro.setMemberIdentifier4(patientProfile.getMemberIdentifier4());
        patientProfileAvro.setMemberIdentifier5(patientProfile.getMemberIdentifier5());
        patientProfileAvro.setMemberIdentifier6(patientProfile.getMemberIdentifier6());
        patientProfileAvro.setMemberIdentifier7(patientProfile.getMemberIdentifier7());
        patientProfileAvro.setMemberIdentifier8(patientProfile.getMemberIdentifier8());
        patientProfileAvro.setMemberIdentifier9(patientProfile.getMemberIdentifier9());
        patientProfileAvro.setMemberIdentifier10(patientProfile.getMemberIdentifier10());
        patientProfileAvro.setMemberIdentifier11(patientProfile.getMemberIdentifier11());
        patientProfileAvro.setMemberIdentifier12(patientProfile.getMemberIdentifier12());
        patientProfileAvro.setMemberIdentifier13(patientProfile.getMemberIdentifier13());
        patientProfileAvro.setMemberIdentifier14(patientProfile.getMemberIdentifier14());
        patientProfileAvro.setMemberIdentifier15(patientProfile.getMemberIdentifier15());
        patientProfileAvro.setMemberIdentifier16(patientProfile.getMemberIdentifier16());
        patientProfileAvro.setMemberIdentifier17(patientProfile.getMemberIdentifier16());
        patientProfileAvro.setMemberIdentifier18(patientProfile.getMemberIdentifier18());
        patientProfileAvro.setMemberIdentifier19(patientProfile.getMemberIdentifier19());
        patientProfileAvro.setMemberIdentifier20(patientProfile.getMemberIdentifier20());
        patientProfileAvro.setMiddleName(patientProfile.getMiddleName());
        patientProfileAvro.setPhoneNumber(patientProfile.getPhoneNumber());
        patientProfileAvro.setPhoneNumber2(patientProfile.getPhoneNumber());
        patientProfileAvro.setPhoneUsagePreferenceCode(patientProfile.getPhoneUsagePreferenceCode());
        patientProfileAvro.setPhoneUsageTypeCode(patientProfile.getPhoneUsageTypeCode());
        patientProfileAvro.setMaritalStatus(patientProfile.getMaritalStatus());
        patientProfileAvro.setSsn(patientProfile.getSsn());
        patientProfileAvro.setFeedInstanceId(patientProfile.getFeedInstanceId());
        patientProfileAvro.setLanguageUsageTypeCode(patientProfile.getLanguageUsageTypeCode());
        patientProfileAvro.setLocationUsagePreferenceCode(patientProfile.getLocationUsagePreferenceCode());
        patientProfileAvro.setLanguageWrittenSource(patientProfile.getLanguageWrittenSource());

        patientProfileAvro.setStateCode(patientProfile.getStateCode());
        patientProfileAvro.setSubscriberKey(patientProfile.getSubscriberKey());


        List<ClaimAvro> claimAvros = claimsAvroToModel(patientProfile.getClaims());
        patientProfileAvro.setClaims(claimAvros);


        List<EnrollmentAvro> EnrollmentAvros = new ArrayList<>();
        for (Enrollment enrollment : patientProfile.getEnrollments()) {
            EnrollmentAvro enrollmentAvro = modelToAvro(enrollment);
            EnrollmentAvros.add(enrollmentAvro);

        }

        patientProfileAvro.setEnrollments(EnrollmentAvros);

        List<LabClaimAvro> labClaimAvros = new ArrayList<>();
        for (LabClaim labClaim : patientProfile.getLabClaims()) {
            LabClaimAvro labClaimAvro = modelToAvro(labClaim);
            labClaimAvros.add(labClaimAvro);


        }
        patientProfileAvro.setLabClaims(labClaimAvros);
        List<RxClaimAvro> rxClaimAvros = new ArrayList<>();
        for (RxClaim rxClaim : patientProfile.getRxClaims()) {
            RxClaimAvro rxClaimAvro = new RxClaimAvro();
            rxClaimAvro.setClaimStatusCode(rxClaim.getClaimStatusCode());
            rxClaimAvro.setClientMemberId(rxClaim.getClientMemberId());
            rxClaimAvro.setClaimStatusCode(rxClaim.getClaimStatusCode());
            rxClaimAvro.setDispensedDate(rxClaim.getDispensedDate());
            rxClaimAvro.setDispensedSupplyDayCount(rxClaim.getDispensedSupplyDayCount());
            rxClaimAvro.setFeedInstanceId(rxClaim.getFeedInstanceId());
            rxClaimAvro.setNdc(rxClaim.getNdc());
            rxClaimAvro.setPatientPlaceOfServiceCode(rxClaim.getPatientPlaceOfServiceCode());
            rxClaimAvro.setPayerClaimControlNumber(rxClaim.getPayerClaimControlNumber());
            rxClaimAvro.setPharmacyClaimId(rxClaim.getPharmacyClaimId());
            rxClaimAvro.setPrescribingClientProviderId(rxClaim.getPrescribingClientProviderId());
            rxClaimAvro.setSupplementalSourceCode(rxClaim.getSupplementalSourceCode());
            rxClaimAvro.setUdfActiveInd(rxClaim.getUdfActiveInd());

            rxClaimAvros.add(rxClaimAvro);

        }
        patientProfileAvro.setRxClaims(rxClaimAvros);

        stagingMessageAvro.setPatientProfile(patientProfileAvro);
    }

    private List<ClaimAvro> claimsAvroToModel( List<Claim> claims ) {
        List<ClaimAvro> claimAvros = new ArrayList<>();
        for (Claim claim : claims) {
            ClaimAvro claimavro = modelToAvro(claim);
            claimAvros.add(claimavro);
            //claimavro.setProviderSpecialty(String.valueOf(claim.getProviderSpecialty()));
            //claimavro.setProviderTypeCodes(claim.getProviderTypeCodes().toString());
            //claimavro.setMsdrgCodes(claim.getMsdrgCodes());

        }
        return claimAvros;
    }

    private LabClaimAvro modelToAvro( LabClaim labClaim ) {
        LabClaimAvro labClaimAvro = new LabClaimAvro();
        labClaimAvro.setClientMemberId(labClaim.getClientMemberId());
        labClaimAvro.setClientProviderId(labClaim.getClientProviderId());
        labClaimAvro.setLabClaimId(labClaim.getLabClaimId());
        labClaimAvro.setLoinc(labClaim.getLoinc());
        labClaimAvro.setObservationCode(labClaim.getObservationCode());
        labClaimAvro.setObservationResultStatusCode(labClaim.getObservationResultStatusCode());
        labClaimAvro.setObservationResultValue(labClaim.getObservationResultValue());
        labClaimAvro.setPosNegResult(labClaim.getPosNegResult());
        labClaimAvro.setProcedureCodeQualifier(labClaim.getProcedureCodeQualifier());
        labClaimAvro.setOrderingOrderNumber(labClaim.getOrderingOrderNumber());
        labClaimAvro.setOrderingRequestDate(labClaim.getOrderingRequestDate());
        labClaimAvro.setFeedInstanceId(labClaim.getFeedInstanceId());
        labClaimAvro.setResult(labClaim.getResult());
        labClaimAvro.setSnomed(labClaim.getSnomed());
        labClaimAvro.setSource(labClaim.getSource());
        labClaimAvro.setUdfActiveInd(labClaim.getUdfActiveInd());
        labClaimAvro.setSupplementalSourceCode(labClaim.getSupplementalSourceCode());

        /***********Future reference**********/
        /*List list = new ArrayList<>();
        labClaim.getCptCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, labClaim.getCptCodes());
        labClaimAvro.setCptCodes(list);
        labClaim.getHcpcsCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, labClaim.getHcpcsCodes());
        labClaimAvro.setHcpcsCodes(list);
        labClaim.getHcpcsModCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, labClaim.getHcpcsModCodes());
        labClaimAvro.setHcpcsModCodes(list);
        if(labClaim.getLabClaimAltIds()!= null &&labClaim.getLabClaimAltIds().size()>0) {
            Collections.copy(list, labClaim.getLabClaimAltIds());
            labClaimAvro.setLabClaimAltIds(list);
        }*/

        return labClaimAvro;
    }

    private EnrollmentAvro modelToAvro( Enrollment enrollment ) {
        EnrollmentAvro enrollmentAvro = new EnrollmentAvro();
        enrollmentAvro.setBenefitCode(enrollment.getBenefitCode());
        enrollmentAvro.setChemicalDependency24HourInd(enrollment.getChemicalDependency24HourInd());
        enrollmentAvro.setChemicalDependencyAmbulatoryInd(enrollment.getChemicalDependencyAmbulatoryInd());
        enrollmentAvro.setChemicalDependencyInpatientInd(enrollment.getChemicalDependencyInpatientInd());
        enrollmentAvro.setClientMemberEnrollmentId(enrollment.getClientMemberEnrollmentId());
        enrollmentAvro.setClientProviderId(enrollment.getClientProviderId());
        enrollmentAvro.setClientMemberId(enrollment.getClientMemberId());
        enrollmentAvro.setCoverageBeginDate(enrollment.getCoverageBeginDate());
        enrollmentAvro.setCoverageEndDate(enrollment.getCoverageEndDate());
        enrollmentAvro.setDiseaseManagementProgramInd(enrollment.getDiseaseManagementProgramInd());
        enrollmentAvro.setDiseaseManagementSeverityFactor(enrollment.getDiseaseManagementSeverityFactor());
        enrollmentAvro.setDentalInd(enrollment.getDentalInd());
        enrollmentAvro.setEnrollmentBenefitPlanId(enrollment.getEnrollmentBenefitPlanId());
        enrollmentAvro.setEnrollmentContractId(enrollment.getEnrollmentContractId());
        enrollmentAvro.setMemberEnrollmentId(enrollment.getMemberEnrollmentId());
        enrollmentAvro.setMemberEnrollmentQhpState(enrollment.getMemberEnrollmentQhpState());
        enrollmentAvro.setMentalHealth24HourInd(enrollment.getMentalHealth24HourInd());
        enrollmentAvro.setMentalHealthAmbulatoryInd(enrollment.getMentalHealthAmbulatoryInd());
        enrollmentAvro.setMentalHealthInpatientInd(enrollment.getMentalHealthInpatientInd());
        enrollmentAvro.setFeedInstanceId(enrollment.getFeedInstanceId());
        enrollmentAvro.setHospiceInd(enrollment.getHospiceInd());
        enrollmentAvro.setPayerCode(enrollment.getPayerCode());
        enrollmentAvro.setPlanEmployeeInd(enrollment.getPlanEmployeeInd());
        enrollmentAvro.setProviderTypeCode(enrollment.getProviderTypeCode());
        enrollmentAvro.setProductCode(enrollment.getProductCode());
        enrollmentAvro.setPrescriptionDrugInd(enrollment.getPrescriptionDrugInd());
        enrollmentAvro.setSubscriberMemberId(enrollment.getSubscriberMemberId());
        enrollmentAvro.setUdfActiveInd(enrollment.getUdfActiveInd());
        enrollmentAvro.setVisionInd(enrollment.getVisionInd());
        enrollmentAvro.setMetalLevel(enrollment.getMetalLevel());
        return enrollmentAvro;
    }

    private ClaimAvro modelToAvro( Claim claim ) {
        ClaimAvro claimavro = new ClaimAvro();
        claimavro.setAdmissionDate(claim.getAdmissionDate());
        claimavro.setClaimId(claim.getClaimId());
        claimavro.setClaimStatusCode(claim.getClaimStatusCode());
        claimavro.setClientMemberId(claim.getClientMemberId());
        claimavro.setClientProviderId(claim.getClientProviderId());
        claimavro.setCost(claim.getCost());
        claimavro.setDeniedDayOrVisitCount(claim.getDeniedDayOrVisitCount());
        claimavro.setDischargeDate(claim.getDischargeDate());
        claimavro.setExcludeFromDischargeInd(claim.getExcludeFromDischargeInd());
        claimavro.setMajorSurgeryInd(claim.getMajorSurgeryInd());
        claimavro.setPatientStatusCode(claim.getPatientStatusCode());
        claimavro.setPayerClaimControlNumber(claim.getPayerClaimControlNumber());
        claimavro.setPcpInd(claim.getPcpInd());
        claimavro.setPresentOnAdmission(claim.getPresentOnAdmission());

        // cpt code
        claim.getCptpxCodes().removeAll(Collections.singleton(null));
        if (listToAvroList(claim.getCptpxCodes()) != null) {
            claimavro.setCptpxCodes(listToAvroList(claim.getCptpxCodes()));
        }

        // hcpcs code
        claim.getHcpcspxCodes().removeAll(Collections.singleton(null));
        if (listToAvroList(claim.getHcpcspxCodes()) != null) {
            claimavro.setHcpcspxCodes(listToAvroList(claim.getHcpcspxCodes()));
        }

        // icd code
        claim.getIcddxCodes().removeAll(Collections.singleton(null));
        if (listListToAvroListList(claim.getIcddxCodes()) != null) {
            claimavro.setIcddxCodes(listListToAvroListList(claim.getIcddxCodes()));
        }

        // icd 10 code
        claim.getIcddx10Codes().removeAll(Collections.singleton(null));
        if (listListToAvroListList(claim.getIcddx10Codes()) != null) {
            claimavro.setIcddx10Codes(listListToAvroListList(claim.getIcddx10Codes()));
        }

        /************ Future reference****************/
        //System.out.println("successful claimid: " + claim.getClaimId());
        /*List list = new ArrayList<>();

        claim.getIcddxCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getIcddxCodes());
        claimavro.setIcddxCodes(list);
        claim.getIcddx10Codes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getIcddx10Codes());
        claimavro.setIcddx10Codes(list);
        claim.getIcdpx10codes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getIcdpx10codes());
        claimavro.setIcdpx10codes(list);
        claim.getCptpxCodes().removeAll(Collections.singleton(null));
        //Collections.copy(claimavro.cptpxCodes, claim.getCptpxCodes());
        claimavro.setCptpxCodes(listToAvroList(claim.getCptpxCodes()));
        //claimavro.setCptpxCodes(list);
        claim.getHcpcsModCodes().removeAll(Collections.singleton(null));
        //Collections.copy(list, claim.getHcpcsModCodes());
        claimavro.setHcpcsModCodes(listToAvroList(claim.getHcpcsModCodes()));
        //claimavro.setHcpcsModCodes(list);
        claim.getHcpcspxCodes().removeAll(Collections.singleton(null));
        //listToAvroList(claim.getHcpcspxCodes(), claimavro);
        //Collections.copy(list, claim.getHcpcspxCodes());
        claimavro.setHcpcspxCodes(listToAvroList(claim.getHcpcsModCodes()));
        claim.getProviderSpecialty().removeAll(Collections.singleton(null));
        //Collections.copy(list, claim.getProviderSpecialty());
        claimavro.setProviderSpecialty(list);
        claim.getTob().removeAll(Collections.singleton(null));
        //Collections.copy(list, claim.getTob());
        //claimavro.setTob(list);
        claim.getHpx().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getHpx());
        claimavro.setHpx(list);
        claim.getHcpcspxCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getHcpcspxCodes());
        claimavro.setHcpcspxCodes(list);
        claim.getHcpcsModCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getHcpcsModCodes());
        claimavro.setHcpcsModCodes(list);
        claim.getHcfaposCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getHcfaposCodes());
        claimavro.setHcfaposCodes(list);
        claim.getApdrgCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getApdrgCodes());
        claimavro.setApdrgCodes(list);
        claim.getAprdrgCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getAprdrgCodes());
        claimavro.setAprdrgCodes(list);
        claim.getMsdrgCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getMsdrgCodes());
        claimavro.setMsdrgCodes(list);
        claim.getDrgCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getDrgCodes());
        claimavro.setDrgCodes(list);
        claim.getClaimAltIds().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getClaimAltIds());
        claimavro.setClaimAltIds(list);
        claim.getCptModCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getCptModCodes());
        claimavro.setCptModCodes(list);
        claim.getCptpxCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getCptpxCodes());
        claimavro.setCptpxCodes(list);
        claim.getProviderTypeCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getProviderTypeCodes());
        claimavro.setProviderTypeCodes(list);
        claim.getProviderSpecialty().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getProviderSpecialty());
        claimavro.setProviderSpecialty(list);
        claim.getUbRevenueCodes().removeAll(Collections.singleton(null));
        Collections.copy(list, claim.getUbRevenueCodes());
        claimavro.setProviderSpecialty(list);*/


        return claimavro;
    }

    private List<CharSequence> listToAvroList( List<String> list ) {
        List<CharSequence> codeAvro = new ArrayList<>();
        if (list != null && list.size() != 0) {
            list.forEach(l -> {
                codeAvro.add(l);
            });
        }
        return codeAvro;
    }

    private List<List<CharSequence>> listListToAvroListList( List<List<String>> list ) {
        List<List<CharSequence>> codeAvro = new ArrayList<>();
        if (list != null && list.size() != 0) {
            for (List<String> code : list) {
                List<CharSequence> codeAvroSub = new ArrayList<>();
                code.removeAll(Collections.singleton(null));
                if (code != null && code.size() != 0) {
                    code.forEach(c -> {
                        codeAvroSub.add(c);
                    });
                }
                codeAvro.add(codeAvroSub);
            }
        }
        return codeAvro;
    }

    public void getProviderProfile( StagingMessageAvro stagingMessageAvro, List<ProviderProfile> providerProfiles ) {
        List<ProviderProfileAvro> providerProfileAvros = new ArrayList<>();
        for (ProviderProfile providerProfile : providerProfiles) {
            ProviderProfileAvro providerProfileAvro = new ProviderProfileAvro();
            providerProfileAvro.setFeedInstanceId(providerProfile.getFeedInstanceId());
            providerProfileAvro.setNpi(providerProfile.getNpi());
            providerProfileAvro.setProviderId(providerProfile.getProviderId());
            providerProfileAvro.setClientProviderId(providerProfile.getClientProviderId());
            providerProfileAvro.setUdfActiveInd(providerProfile.getUdfActiveInd());
            providerProfileAvro.setAddress(StagingUtil.modelToAvro(providerProfile.getAddress()));
            providerProfileAvro.setName(StagingUtil.modelToAvroNameList(providerProfile.getName()));
            providerProfileAvro.setAltIds(StagingUtil.modelToAvroAltIds(providerProfile.getAltIds()));
            providerProfileAvros.add(providerProfileAvro);
            stagingMessageAvro.setProviderProfiles(providerProfileAvros);

        }
    }


}

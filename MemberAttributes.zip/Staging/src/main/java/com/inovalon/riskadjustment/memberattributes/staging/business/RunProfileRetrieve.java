package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;


@Service
public class RunProfileRetrieve {
    @Autowired
    private Gateway gateway;
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the runProfile based on runProfileId
     *
     * @param runProfileId
     * @return It returns runProfile
     */
    @LogBeforeEvents
    public RunProfile getRunProfileByRunProfileId( long runProfileId ) {
        logWriter.info("Beginning of getRunProfileByRunProfileId method");
        RunProfile runProfile = new RunProfile();

        try {
            String url = stagingConfiguration.getConfigurationDatabaseServiceBaseUrl() + MemberAttributesConstants.GET_RUN_PROFILE + "?runProfileId=" + runProfileId;
            runProfile = gateway.getData(url, RunProfile.class);
        } catch (RestClientException e) {

        }
        logWriter.info("Ending of getRunProfileByRunProfileId method");
        return runProfile;
    }
}

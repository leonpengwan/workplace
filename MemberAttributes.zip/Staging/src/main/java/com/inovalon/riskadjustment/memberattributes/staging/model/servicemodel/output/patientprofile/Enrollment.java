package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile;

import java.util.List;

public class Enrollment {

    private int memberEnrollmentId;
    private String clientMemberId;
    private String payerCode;
    private String productCode;
    private String enrollmentContractId;
    private String coverageBeginDate;
    private String coverageEndDate;
    private String enrollmentBenefitPlanId;
    private String subscriberMemberId;
    private String planEmployeeInd;
    private String hospiceInd;
    private String diseaseManagementProgramInd;
    private String diseaseManagementSeverityFactor;
    private String dentalInd;
    private String prescriptionDrugInd;
    private String visionInd;
    private String mentalHealthInpatientInd;
    private String mentalHealth24HourInd;
    private String mentalHealthAmbulatoryInd;
    private String chemicalDependencyInpatientInd;
    private String chemicalDependency24HourInd;
    private String chemicalDependencyAmbulatoryInd;
    private String clientProviderId;
    private String providerTypeCode;
    private String benefitCode;
    private String clientMemberEnrollmentId;
    private String memberEnrollmentQhpState;
    private int feedInstanceId;
    private int udfActiveInd;
    private String esrdFlag;
    private String ltiFlag;
    private String issuerId;
    private String metalLevel;
    private String costSharingVariant;
    private String mspFlag;
    private String marketCoverage;
    private String enrollmentRoute;
    private String csrEligibilityFlag;
    private String planMarketingName;
    private String memberGroupCode;

    private List<String> customCodes;
    private List<String> altIds;


    public Enrollment() {
    }

    public Enrollment(int memberEnrollmentId, String clientMemberId, String payerCode, String productCode, String enrollmentContractId, String coverageBeginDate, String coverageEndDate, String enrollmentBenefitPlanId, String subscriberMemberId, String planEmployeeInd, String hospiceInd, String diseaseManagementProgramInd, String diseaseManagementSeverityFactor, String dentalInd, String prescriptionDrugInd, String visionInd, String mentalHealthInpatientInd, String mentalHealth24HourInd, String mentalHealthAmbulatoryInd, String chemicalDependencyInpatientInd, String chemicalDependency24HourInd, String chemicalDependencyAmbulatoryInd, String clientProviderId, String providerTypeCode, String benefitCode, String clientMemberEnrollmentId, String memberEnrollmentQhpState, int feedInstanceId, int udfActiveInd, String esrdFlag, String ltiFlag, String issuerId, String metalLevel, String costSharingVariant, String mspFlag, String marketCoverage, String enrollmentRoute, String csrEligibilityFlag, String planMarketingName, String memberGroupCode, List<String> customCodes, List<String> altIds) {
        this.memberEnrollmentId = memberEnrollmentId;
        this.clientMemberId = clientMemberId;
        this.payerCode = payerCode;
        this.productCode = productCode;
        this.enrollmentContractId = enrollmentContractId;
        this.coverageBeginDate = coverageBeginDate;
        this.coverageEndDate = coverageEndDate;
        this.enrollmentBenefitPlanId = enrollmentBenefitPlanId;
        this.subscriberMemberId = subscriberMemberId;
        this.planEmployeeInd = planEmployeeInd;
        this.hospiceInd = hospiceInd;
        this.diseaseManagementProgramInd = diseaseManagementProgramInd;
        this.diseaseManagementSeverityFactor = diseaseManagementSeverityFactor;
        this.dentalInd = dentalInd;
        this.prescriptionDrugInd = prescriptionDrugInd;
        this.visionInd = visionInd;
        this.mentalHealthInpatientInd = mentalHealthInpatientInd;
        this.mentalHealth24HourInd = mentalHealth24HourInd;
        this.mentalHealthAmbulatoryInd = mentalHealthAmbulatoryInd;
        this.chemicalDependencyInpatientInd = chemicalDependencyInpatientInd;
        this.chemicalDependency24HourInd = chemicalDependency24HourInd;
        this.chemicalDependencyAmbulatoryInd = chemicalDependencyAmbulatoryInd;
        this.clientProviderId = clientProviderId;
        this.providerTypeCode = providerTypeCode;
        this.benefitCode = benefitCode;
        this.clientMemberEnrollmentId = clientMemberEnrollmentId;
        this.memberEnrollmentQhpState = memberEnrollmentQhpState;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.esrdFlag = esrdFlag;
        this.ltiFlag = ltiFlag;
        this.issuerId = issuerId;
        this.metalLevel = metalLevel;
        this.costSharingVariant = costSharingVariant;
        this.mspFlag = mspFlag;
        this.marketCoverage = marketCoverage;
        this.enrollmentRoute = enrollmentRoute;
        this.csrEligibilityFlag = csrEligibilityFlag;
        this.planMarketingName = planMarketingName;
        this.memberGroupCode = memberGroupCode;
        this.customCodes = customCodes;
        this.altIds = altIds;
    }

    public int getMemberEnrollmentId() {
        return memberEnrollmentId;
    }

    public void setMemberEnrollmentId(int memberEnrollmentId) {
        this.memberEnrollmentId = memberEnrollmentId;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getPayerCode() {
        return payerCode;
    }

    public void setPayerCode(String payerCode) {
        this.payerCode = payerCode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getEnrollmentContractId() {
        return enrollmentContractId;
    }

    public void setEnrollmentContractId(String enrollmentContractId) {
        this.enrollmentContractId = enrollmentContractId;
    }

    public String getCoverageBeginDate() {
        return coverageBeginDate;
    }

    public void setCoverageBeginDate(String coverageBeginDate) {
        this.coverageBeginDate = coverageBeginDate;
    }

    public String getCoverageEndDate() {
        return coverageEndDate;
    }

    public void setCoverageEndDate(String coverageEndDate) {
        this.coverageEndDate = coverageEndDate;
    }

    public String getEnrollmentBenefitPlanId() {
        return enrollmentBenefitPlanId;
    }

    public void setEnrollmentBenefitPlanId(String enrollmentBenefitPlanId) {
        this.enrollmentBenefitPlanId = enrollmentBenefitPlanId;
    }

    public String getSubscriberMemberId() {
        return subscriberMemberId;
    }

    public void setSubscriberMemberId(String subscriberMemberId) {
        this.subscriberMemberId = subscriberMemberId;
    }

    public String getPlanEmployeeInd() {
        return planEmployeeInd;
    }

    public void setPlanEmployeeInd(String planEmployeeInd) {
        this.planEmployeeInd = planEmployeeInd;
    }

    public String getHospiceInd() {
        return hospiceInd;
    }

    public void setHospiceInd(String hospiceInd) {
        this.hospiceInd = hospiceInd;
    }

    public String getDiseaseManagementProgramInd() {
        return diseaseManagementProgramInd;
    }

    public void setDiseaseManagementProgramInd(String diseaseManagementProgramInd) {
        this.diseaseManagementProgramInd = diseaseManagementProgramInd;
    }

    public String getDiseaseManagementSeverityFactor() {
        return diseaseManagementSeverityFactor;
    }

    public void setDiseaseManagementSeverityFactor(String diseaseManagementSeverityFactor) {
        this.diseaseManagementSeverityFactor = diseaseManagementSeverityFactor;
    }

    public String getDentalInd() {
        return dentalInd;
    }

    public void setDentalInd(String dentalInd) {
        this.dentalInd = dentalInd;
    }

    public String getPrescriptionDrugInd() {
        return prescriptionDrugInd;
    }

    public void setPrescriptionDrugInd(String prescriptionDrugInd) {
        this.prescriptionDrugInd = prescriptionDrugInd;
    }

    public String getVisionInd() {
        return visionInd;
    }

    public void setVisionInd(String visionInd) {
        this.visionInd = visionInd;
    }

    public String getMentalHealthInpatientInd() {
        return mentalHealthInpatientInd;
    }

    public void setMentalHealthInpatientInd(String mentalHealthInpatientInd) {
        this.mentalHealthInpatientInd = mentalHealthInpatientInd;
    }

    public String getMentalHealth24HourInd() {
        return mentalHealth24HourInd;
    }

    public void setMentalHealth24HourInd(String mentalHealth24HourInd) {
        this.mentalHealth24HourInd = mentalHealth24HourInd;
    }

    public String getMentalHealthAmbulatoryInd() {
        return mentalHealthAmbulatoryInd;
    }

    public void setMentalHealthAmbulatoryInd(String mentalHealthAmbulatoryInd) {
        this.mentalHealthAmbulatoryInd = mentalHealthAmbulatoryInd;
    }

    public String getChemicalDependencyInpatientInd() {
        return chemicalDependencyInpatientInd;
    }

    public void setChemicalDependencyInpatientInd(String chemicalDependencyInpatientInd) {
        this.chemicalDependencyInpatientInd = chemicalDependencyInpatientInd;
    }

    public String getChemicalDependency24HourInd() {
        return chemicalDependency24HourInd;
    }

    public void setChemicalDependency24HourInd(String chemicalDependency24HourInd) {
        this.chemicalDependency24HourInd = chemicalDependency24HourInd;
    }

    public String getChemicalDependencyAmbulatoryInd() {
        return chemicalDependencyAmbulatoryInd;
    }

    public void setChemicalDependencyAmbulatoryInd(String chemicalDependencyAmbulatoryInd) {
        this.chemicalDependencyAmbulatoryInd = chemicalDependencyAmbulatoryInd;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }

    public String getProviderTypeCode() {
        return providerTypeCode;
    }

    public void setProviderTypeCode(String providerTypeCode) {
        this.providerTypeCode = providerTypeCode;
    }

    public String getBenefitCode() {
        return benefitCode;
    }

    public void setBenefitCode(String benefitCode) {
        this.benefitCode = benefitCode;
    }

    public String getClientMemberEnrollmentId() {
        return clientMemberEnrollmentId;
    }

    public void setClientMemberEnrollmentId(String clientMemberEnrollmentId) {
        this.clientMemberEnrollmentId = clientMemberEnrollmentId;
    }

    public String getMemberEnrollmentQhpState() {
        return memberEnrollmentQhpState;
    }

    public void setMemberEnrollmentQhpState(String memberEnrollmentQhpState) {
        this.memberEnrollmentQhpState = memberEnrollmentQhpState;
    }

    public int getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(int feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public int getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(int udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    public List<String> getCustomCodes() {
        return customCodes;
    }

    public void setCustomCodes(List<String> customCodes) {
        this.customCodes = customCodes;
    }

    public String getEsrdFlag() {
        return esrdFlag;
    }

    public void setEsrdFlag(String esrdFlag) {
        this.esrdFlag = esrdFlag;
    }

    public String getLtiFlag() {
        return ltiFlag;
    }

    public void setLtiFlag(String ltiFlag) {
        this.ltiFlag = ltiFlag;
    }

    public String getIssuerId() {
        return issuerId;
    }

    public void setIssuerId(String issuerId) {
        this.issuerId = issuerId;
    }

    public String getMetalLevel() {
        return metalLevel;
    }

    public void setMetalLevel(String metalLevel) {
        this.metalLevel = metalLevel;
    }

    public String getCostSharingVariant() {
        return costSharingVariant;
    }

    public void setCostSharingVariant(String costSharingVariant) {
        this.costSharingVariant = costSharingVariant;
    }

    public String getMspFlag() {
        return mspFlag;
    }

    public void setMspFlag(String mspFlag) {
        this.mspFlag = mspFlag;
    }

    public String getMarketCoverage() {
        return marketCoverage;
    }

    public void setMarketCoverage(String marketCoverage) {
        this.marketCoverage = marketCoverage;
    }

    public String getEnrollmentRoute() {
        return enrollmentRoute;
    }

    public void setEnrollmentRoute(String enrollmentRoute) {
        this.enrollmentRoute = enrollmentRoute;
    }

    public String getCsrEligibilityFlag() {
        return csrEligibilityFlag;
    }

    public void setCsrEligibilityFlag(String csrEligibilityFlag) {
        this.csrEligibilityFlag = csrEligibilityFlag;
    }

    public String getPlanMarketingName() {
        return planMarketingName;
    }

    public void setPlanMarketingName(String planMarketingName) {
        this.planMarketingName = planMarketingName;
    }

    public String getMemberGroupCode() {
        return memberGroupCode;
    }

    public void setMemberGroupCode(String memberGroupCode) {
        this.memberGroupCode = memberGroupCode;
    }

    public List<String> getAltIds() {
        return altIds;
    }

    public void setAltIds(List<String> altIds) {
        this.altIds = altIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Enrollment that = (Enrollment) o;

        if (memberEnrollmentId != that.memberEnrollmentId) return false;
        if (feedInstanceId != that.feedInstanceId) return false;
        if (udfActiveInd != that.udfActiveInd) return false;
        if (clientMemberId != null ? !clientMemberId.equals(that.clientMemberId) : that.clientMemberId != null)
            return false;
        if (payerCode != null ? !payerCode.equals(that.payerCode) : that.payerCode != null) return false;
        if (productCode != null ? !productCode.equals(that.productCode) : that.productCode != null) return false;
        if (enrollmentContractId != null ? !enrollmentContractId.equals(that.enrollmentContractId) : that.enrollmentContractId != null)
            return false;
        if (coverageBeginDate != null ? !coverageBeginDate.equals(that.coverageBeginDate) : that.coverageBeginDate != null)
            return false;
        if (coverageEndDate != null ? !coverageEndDate.equals(that.coverageEndDate) : that.coverageEndDate != null)
            return false;
        if (enrollmentBenefitPlanId != null ? !enrollmentBenefitPlanId.equals(that.enrollmentBenefitPlanId) : that.enrollmentBenefitPlanId != null)
            return false;
        if (subscriberMemberId != null ? !subscriberMemberId.equals(that.subscriberMemberId) : that.subscriberMemberId != null)
            return false;
        if (planEmployeeInd != null ? !planEmployeeInd.equals(that.planEmployeeInd) : that.planEmployeeInd != null)
            return false;
        if (hospiceInd != null ? !hospiceInd.equals(that.hospiceInd) : that.hospiceInd != null) return false;
        if (diseaseManagementProgramInd != null ? !diseaseManagementProgramInd.equals(that.diseaseManagementProgramInd) : that.diseaseManagementProgramInd != null)
            return false;
        if (diseaseManagementSeverityFactor != null ? !diseaseManagementSeverityFactor.equals(that.diseaseManagementSeverityFactor) : that.diseaseManagementSeverityFactor != null)
            return false;
        if (dentalInd != null ? !dentalInd.equals(that.dentalInd) : that.dentalInd != null) return false;
        if (prescriptionDrugInd != null ? !prescriptionDrugInd.equals(that.prescriptionDrugInd) : that.prescriptionDrugInd != null)
            return false;
        if (visionInd != null ? !visionInd.equals(that.visionInd) : that.visionInd != null) return false;
        if (mentalHealthInpatientInd != null ? !mentalHealthInpatientInd.equals(that.mentalHealthInpatientInd) : that.mentalHealthInpatientInd != null)
            return false;
        if (mentalHealth24HourInd != null ? !mentalHealth24HourInd.equals(that.mentalHealth24HourInd) : that.mentalHealth24HourInd != null)
            return false;
        if (mentalHealthAmbulatoryInd != null ? !mentalHealthAmbulatoryInd.equals(that.mentalHealthAmbulatoryInd) : that.mentalHealthAmbulatoryInd != null)
            return false;
        if (chemicalDependencyInpatientInd != null ? !chemicalDependencyInpatientInd.equals(that.chemicalDependencyInpatientInd) : that.chemicalDependencyInpatientInd != null)
            return false;
        if (chemicalDependency24HourInd != null ? !chemicalDependency24HourInd.equals(that.chemicalDependency24HourInd) : that.chemicalDependency24HourInd != null)
            return false;
        if (chemicalDependencyAmbulatoryInd != null ? !chemicalDependencyAmbulatoryInd.equals(that.chemicalDependencyAmbulatoryInd) : that.chemicalDependencyAmbulatoryInd != null)
            return false;
        if (clientProviderId != null ? !clientProviderId.equals(that.clientProviderId) : that.clientProviderId != null)
            return false;
        if (providerTypeCode != null ? !providerTypeCode.equals(that.providerTypeCode) : that.providerTypeCode != null)
            return false;
        if (benefitCode != null ? !benefitCode.equals(that.benefitCode) : that.benefitCode != null) return false;
        if (clientMemberEnrollmentId != null ? !clientMemberEnrollmentId.equals(that.clientMemberEnrollmentId) : that.clientMemberEnrollmentId != null)
            return false;
        if (memberEnrollmentQhpState != null ? !memberEnrollmentQhpState.equals(that.memberEnrollmentQhpState) : that.memberEnrollmentQhpState != null)
            return false;
        if (esrdFlag != null ? !esrdFlag.equals(that.esrdFlag) : that.esrdFlag != null) return false;
        if (ltiFlag != null ? !ltiFlag.equals(that.ltiFlag) : that.ltiFlag != null) return false;
        if (issuerId != null ? !issuerId.equals(that.issuerId) : that.issuerId != null) return false;
        if (metalLevel != null ? !metalLevel.equals(that.metalLevel) : that.metalLevel != null) return false;
        if (costSharingVariant != null ? !costSharingVariant.equals(that.costSharingVariant) : that.costSharingVariant != null)
            return false;
        if (mspFlag != null ? !mspFlag.equals(that.mspFlag) : that.mspFlag != null) return false;
        if (marketCoverage != null ? !marketCoverage.equals(that.marketCoverage) : that.marketCoverage != null)
            return false;
        if (enrollmentRoute != null ? !enrollmentRoute.equals(that.enrollmentRoute) : that.enrollmentRoute != null)
            return false;
        if (csrEligibilityFlag != null ? !csrEligibilityFlag.equals(that.csrEligibilityFlag) : that.csrEligibilityFlag != null)
            return false;
        if (planMarketingName != null ? !planMarketingName.equals(that.planMarketingName) : that.planMarketingName != null)
            return false;
        if (memberGroupCode != null ? !memberGroupCode.equals(that.memberGroupCode) : that.memberGroupCode != null)
            return false;
        if (customCodes != null ? !customCodes.equals(that.customCodes) : that.customCodes != null) return false;
        return altIds != null ? altIds.equals(that.altIds) : that.altIds == null;
    }

    @Override
    public int hashCode() {
        int result = memberEnrollmentId;
        result = 31 * result + (clientMemberId != null ? clientMemberId.hashCode() : 0);
        result = 31 * result + (payerCode != null ? payerCode.hashCode() : 0);
        result = 31 * result + (productCode != null ? productCode.hashCode() : 0);
        result = 31 * result + (enrollmentContractId != null ? enrollmentContractId.hashCode() : 0);
        result = 31 * result + (coverageBeginDate != null ? coverageBeginDate.hashCode() : 0);
        result = 31 * result + (coverageEndDate != null ? coverageEndDate.hashCode() : 0);
        result = 31 * result + (enrollmentBenefitPlanId != null ? enrollmentBenefitPlanId.hashCode() : 0);
        result = 31 * result + (subscriberMemberId != null ? subscriberMemberId.hashCode() : 0);
        result = 31 * result + (planEmployeeInd != null ? planEmployeeInd.hashCode() : 0);
        result = 31 * result + (hospiceInd != null ? hospiceInd.hashCode() : 0);
        result = 31 * result + (diseaseManagementProgramInd != null ? diseaseManagementProgramInd.hashCode() : 0);
        result = 31 * result + (diseaseManagementSeverityFactor != null ? diseaseManagementSeverityFactor.hashCode() : 0);
        result = 31 * result + (dentalInd != null ? dentalInd.hashCode() : 0);
        result = 31 * result + (prescriptionDrugInd != null ? prescriptionDrugInd.hashCode() : 0);
        result = 31 * result + (visionInd != null ? visionInd.hashCode() : 0);
        result = 31 * result + (mentalHealthInpatientInd != null ? mentalHealthInpatientInd.hashCode() : 0);
        result = 31 * result + (mentalHealth24HourInd != null ? mentalHealth24HourInd.hashCode() : 0);
        result = 31 * result + (mentalHealthAmbulatoryInd != null ? mentalHealthAmbulatoryInd.hashCode() : 0);
        result = 31 * result + (chemicalDependencyInpatientInd != null ? chemicalDependencyInpatientInd.hashCode() : 0);
        result = 31 * result + (chemicalDependency24HourInd != null ? chemicalDependency24HourInd.hashCode() : 0);
        result = 31 * result + (chemicalDependencyAmbulatoryInd != null ? chemicalDependencyAmbulatoryInd.hashCode() : 0);
        result = 31 * result + (clientProviderId != null ? clientProviderId.hashCode() : 0);
        result = 31 * result + (providerTypeCode != null ? providerTypeCode.hashCode() : 0);
        result = 31 * result + (benefitCode != null ? benefitCode.hashCode() : 0);
        result = 31 * result + (clientMemberEnrollmentId != null ? clientMemberEnrollmentId.hashCode() : 0);
        result = 31 * result + (memberEnrollmentQhpState != null ? memberEnrollmentQhpState.hashCode() : 0);
        result = 31 * result + feedInstanceId;
        result = 31 * result + udfActiveInd;
        result = 31 * result + (esrdFlag != null ? esrdFlag.hashCode() : 0);
        result = 31 * result + (ltiFlag != null ? ltiFlag.hashCode() : 0);
        result = 31 * result + (issuerId != null ? issuerId.hashCode() : 0);
        result = 31 * result + (metalLevel != null ? metalLevel.hashCode() : 0);
        result = 31 * result + (costSharingVariant != null ? costSharingVariant.hashCode() : 0);
        result = 31 * result + (mspFlag != null ? mspFlag.hashCode() : 0);
        result = 31 * result + (marketCoverage != null ? marketCoverage.hashCode() : 0);
        result = 31 * result + (enrollmentRoute != null ? enrollmentRoute.hashCode() : 0);
        result = 31 * result + (csrEligibilityFlag != null ? csrEligibilityFlag.hashCode() : 0);
        result = 31 * result + (planMarketingName != null ? planMarketingName.hashCode() : 0);
        result = 31 * result + (memberGroupCode != null ? memberGroupCode.hashCode() : 0);
        result = 31 * result + (customCodes != null ? customCodes.hashCode() : 0);
        result = 31 * result + (altIds != null ? altIds.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Enrollment{" +
                "memberEnrollmentId=" + memberEnrollmentId +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", payerCode='" + payerCode + '\'' +
                ", productCode='" + productCode + '\'' +
                ", enrollmentContractId='" + enrollmentContractId + '\'' +
                ", coverageBeginDate='" + coverageBeginDate + '\'' +
                ", coverageEndDate='" + coverageEndDate + '\'' +
                ", enrollmentBenefitPlanId='" + enrollmentBenefitPlanId + '\'' +
                ", subscriberMemberId='" + subscriberMemberId + '\'' +
                ", planEmployeeInd='" + planEmployeeInd + '\'' +
                ", hospiceInd='" + hospiceInd + '\'' +
                ", diseaseManagementProgramInd='" + diseaseManagementProgramInd + '\'' +
                ", diseaseManagementSeverityFactor='" + diseaseManagementSeverityFactor + '\'' +
                ", dentalInd='" + dentalInd + '\'' +
                ", prescriptionDrugInd='" + prescriptionDrugInd + '\'' +
                ", visionInd='" + visionInd + '\'' +
                ", mentalHealthInpatientInd='" + mentalHealthInpatientInd + '\'' +
                ", mentalHealth24HourInd='" + mentalHealth24HourInd + '\'' +
                ", mentalHealthAmbulatoryInd='" + mentalHealthAmbulatoryInd + '\'' +
                ", chemicalDependencyInpatientInd='" + chemicalDependencyInpatientInd + '\'' +
                ", chemicalDependency24HourInd='" + chemicalDependency24HourInd + '\'' +
                ", chemicalDependencyAmbulatoryInd='" + chemicalDependencyAmbulatoryInd + '\'' +
                ", clientProviderId='" + clientProviderId + '\'' +
                ", providerTypeCode='" + providerTypeCode + '\'' +
                ", benefitCode='" + benefitCode + '\'' +
                ", clientMemberEnrollmentId='" + clientMemberEnrollmentId + '\'' +
                ", memberEnrollmentQhpState='" + memberEnrollmentQhpState + '\'' +
                ", feedInstanceId=" + feedInstanceId +
                ", udfActiveInd=" + udfActiveInd +
                ", esrdFlag='" + esrdFlag + '\'' +
                ", ltiFlag='" + ltiFlag + '\'' +
                ", issuerId='" + issuerId + '\'' +
                ", metalLevel='" + metalLevel + '\'' +
                ", costSharingVariant='" + costSharingVariant + '\'' +
                ", mspFlag='" + mspFlag + '\'' +
                ", marketCoverage='" + marketCoverage + '\'' +
                ", enrollmentRoute='" + enrollmentRoute + '\'' +
                ", csrEligibilityFlag='" + csrEligibilityFlag + '\'' +
                ", planMarketingName='" + planMarketingName + '\'' +
                ", memberGroupCode='" + memberGroupCode + '\'' +
                ", customCodes=" + customCodes +
                ", altIds=" + altIds +
                '}';
    }
}

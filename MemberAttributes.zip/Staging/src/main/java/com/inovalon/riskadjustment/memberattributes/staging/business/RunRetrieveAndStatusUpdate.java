package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.model.enums.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RunRetrieveAndStatusUpdate {
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private Gateway gateway;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the runId based on runProfileId
     *
     * @param runProfileId
     * @return It returns runId
     * @throws Exception
     */
    @LogBeforeEvents
    @LogAfterEvents
    public Integer retrieveRunId( long runProfileId ) throws Exception {
        logWriter.info("Beginning of retrieveRunId method");
        int memberAttributesRunId = 0;
        try {
            String url = stagingConfiguration.getConfigurationDatabaseServiceBaseUrl()
                    + MemberAttributesConstants.GET_MEMBER_ATTRIBUTES_RUN_ID_BY_RUN_PROFILE_ID
                    + "?runProfileId=" + runProfileId;
            memberAttributesRunId = gateway.getData(url, new TypeReference<Integer>() {
            });
            logWriter.info("Ending of retrieveRunId method");
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
            throw ex;
        }
        return memberAttributesRunId;
    }

    /**
     * This method will update the status  based on runProfileId and status
     *
     * @param runProfileId
     * @param status
     * @return boolean
     */
    @LogBeforeEvents
    public boolean updateStatus( long runProfileId, Status status ) {
        logWriter.info("Beginning of updateStatus method");
        try {
            String url = stagingConfiguration.getConfigurationDatabaseServiceBaseUrl()
                    + MemberAttributesConstants.GET_STATUS_UPDATED
                    + "?runProfileId=" + runProfileId + "&status=" + Status.INPROGRESS;
            gateway.putData(url, null);
        } catch (Exception exp) {
            logWriter.error(exp.getMessage(), exp);
            return false;
        }
        logWriter.info("Ending of updateStatus method");
        return true;
    }
}

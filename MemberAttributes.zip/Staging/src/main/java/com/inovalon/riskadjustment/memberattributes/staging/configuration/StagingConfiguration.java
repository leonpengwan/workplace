package com.inovalon.riskadjustment.memberattributes.staging.configuration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.memberattributes.staging.business.Gateway;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.StagingMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.util.LocalCacheObject;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import com.inovalon.riskadjustment.shared.messagebus.producer.KafkaMessageBusPublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.IOException;

@Configuration
@RefreshScope
@EnableSwagger2
public class StagingConfiguration {

    @Value("${inovalon.risk-adjustment.data-services.results-url}")
    private String resultsDatabaseServiceBaseUrl;
    @Value("${inovalon.risk-adjustment.data-services.configuration-url}")
    private String configurationDatabaseServiceBaseUrl;

    @Value("${spring.kafka.producer.topic}")
    private String kafkaProducerTopic;

    @Value("${inovalon.risk-adjustment.input-batch-size}")
    private int inBatchSize;

    @Value("${inovalon.platform-services.patient-profile-url}")
    private String patientProviderProfileServiceBaseUrl;

    public String getPatientProviderProfileServiceBaseUrl() {
        return this.patientProviderProfileServiceBaseUrl;
    }

    public void setPatientProviderProfileServiceBaseUrl( String patientProviderProfileServiceBaseUrl ) {
        this.patientProviderProfileServiceBaseUrl = patientProviderProfileServiceBaseUrl;
    }


    public String getResultsDatabaseServiceBaseUrl() {
        return resultsDatabaseServiceBaseUrl;
    }

    public void setResultsDatabaseServiceBaseUrl(String resultsDatabaseServiceBaseUrl) {
        this.resultsDatabaseServiceBaseUrl = resultsDatabaseServiceBaseUrl;
    }

    public String getConfigurationDatabaseServiceBaseUrl() {
        return configurationDatabaseServiceBaseUrl;
    }

    public void setConfigurationDatabaseServiceBaseUrl(String configurationDatabaseServiceBaseUrl) {
        this.configurationDatabaseServiceBaseUrl = configurationDatabaseServiceBaseUrl;
    }

    public String getKafkaProducerTopic() {
        return kafkaProducerTopic;
    }

    public void setKafkaProducerTopic(String kafkaProducerTopic) {
        this.kafkaProducerTopic = kafkaProducerTopic;
    }

    public int getInBatchSize() {
        return inBatchSize;
    }

    public void setInBatchSize(int inBatchSize) {
        this.inBatchSize = inBatchSize;
    }


    @Bean
    public MessageBusPublisher<StagingMessageAvro> messageBusPublisher(){
        return new KafkaMessageBusPublisher<StagingMessageAvro>(StagingMessageAvro.class);
    }

   @Bean
   public LocalCacheObject cacheObject(){
       return new LocalCacheObject();
   }

    @Bean
    public Gateway gateway() {
        return new Gateway() {
            @Override
            public <T> T getData(String url, TypeReference<T> type) throws IOException {
                return super.getData(url, type);
            }
        };
    }
    @Bean
    public ObjectMapper objectMapper() { return new ObjectMapper();}

    @Bean
    public RestTemplate restTemplate()
    {
        return new RestTemplate();
    }

    @Override
    public String toString() {
        return "StagingConfiguration{" +
                "resultsDatabaseServiceBaseUrl='" + resultsDatabaseServiceBaseUrl + '\'' +
                ", configurationDatabaseServiceBaseUrl='" + configurationDatabaseServiceBaseUrl + '\'' +
                ", kafkaProducerTopic='" + kafkaProducerTopic + '\'' +
                ", inBatchSize=" + inBatchSize +
                ", patientProviderProfileServiceBaseUrl='" + patientProviderProfileServiceBaseUrl + '\'' +
                '}';
    }

    @Bean
    public HttpHeaders header() {return new HttpHeaders();}

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.inovalon.riskadjustment"))
                .paths(PathSelectors.any())
                .build();
    }
}

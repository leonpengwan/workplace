package com.inovalon.riskadjustment.memberattributes.staging.business.message;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.avro.output.StagingMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class StagingMessageProducer {

    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private LogWriter logWriter;

    @Autowired
    @Qualifier("messageBusPublisher")
    private MessageBusPublisher<StagingMessageAvro> messageBusPublisher;

    public boolean produceStagingMessage( StagingMessageAvro stagingMessageAvro ) throws Exception {
        try {
            logWriter.info("publishMessage to topic: " + stagingConfiguration.getKafkaProducerTopic());
            messageBusPublisher.publishMessage(stagingConfiguration.getKafkaProducerTopic(), stagingMessageAvro);
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
        }
        return true;
    }
}

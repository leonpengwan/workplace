package com.inovalon.riskadjustment.memberattributes.staging.util;


public class LocalCacheObject {
    private long runProfileId;
    private int gapSetDetailId;
    private int memberId;
    private String gapSetId;

    public String getGapSetId() {
        return this.gapSetId;
    }

    public void setGapSetId( String gapSetId ) {
        this.gapSetId = gapSetId;
    }




    public LocalCacheObject() {
    }

    public LocalCacheObject(long runProfileId, String gapSetId , int memberId) {
        this.runProfileId = runProfileId;
        this.gapSetId = gapSetId;
        this.memberId = memberId;
    }

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getGapSetDetailId() {
        return gapSetDetailId;
    }

    public void setGapSetDetailId(int gapSetDetailId) {
        this.gapSetDetailId = gapSetDetailId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
}

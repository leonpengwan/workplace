package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPeriod;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.InterventionPlanRun;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class RetrieveInterventionPlan {
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;
    @Autowired
    private Gateway gateway;
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the list of interventionPlanRunIds based on lookBackDate and planningDate
     *
     * @param clientId
     * @param lookBackDate
     * @param planningDate
     * @param status
     * @return It returns list of interventionPlanRunIds
     * @throws JsonProcessingException
     */
    @LogBeforeEvents
    @LogAfterEvents
    public List<InterventionPlanRun> retrieveInterventionPlanData( int clientId, Date lookBackDate, Date planningDate, int status ) throws JsonProcessingException {
        logWriter.info("Beginning of RetrieveInterventionPlanData Method");

        List<InterventionPlanRun> interventionPlan = new ArrayList<>();
        //Status is currently hardcoded
        status = 4;
        try {

            InterventionPeriod interventionPeriod = new InterventionPeriod();
            interventionPeriod.setClientId(clientId);
            interventionPeriod.setLookBackDate(lookBackDate);
            interventionPeriod.setPlanYear(planningDate);
            interventionPeriod.setStatus(status);

            String url = stagingConfiguration.getConfigurationDatabaseServiceBaseUrl() + MemberAttributesConstants.GET_INTERVENTION_PLAN_RUN_IDS;
            String json = objectMapper.writeValueAsString(interventionPeriod);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(json, headers);
            ResponseEntity<List<InterventionPlanRun>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<InterventionPlanRun>>() {
            });
            interventionPlan = responseEntity.getBody();
        } catch (RestClientException restException) {
            logWriter.error(restException.getMessage(), restException);
            throw restException;
        }
        return interventionPlan;

    }
}

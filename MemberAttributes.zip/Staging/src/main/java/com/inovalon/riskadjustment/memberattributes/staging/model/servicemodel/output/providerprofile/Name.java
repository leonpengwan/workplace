package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.providerprofile;

public class Name {

    private String providerId;

    private String nameType;

    private String fullName;

    private String firstName;

    private String middleName;

    private String lastName;

    private String nameActivationDate;

    private String nameRetirementDate;

    public Name() {

    }

    public Name(String providerId, String nameType, String fullName, String firstName, String middleName, String lastName, String nameActivationDate, String nameRetirementDate) {
        this.providerId = providerId;
        this.nameType = nameType;
        this.fullName = fullName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.nameActivationDate = nameActivationDate;
        this.nameRetirementDate = nameRetirementDate;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getNameType() {
        return nameType;
    }

    public void setNameType(String nameType) {
        this.nameType = nameType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNameActivationDate() {
        return nameActivationDate;
    }

    public void setNameActivationDate(String nameActivationDate) {
        this.nameActivationDate = nameActivationDate;
    }

    public String getNameRetirementDate() {
        return nameRetirementDate;
    }

    public void setNameRetirementDate(String nameRetirementDate) {
        this.nameRetirementDate = nameRetirementDate;
    }
}

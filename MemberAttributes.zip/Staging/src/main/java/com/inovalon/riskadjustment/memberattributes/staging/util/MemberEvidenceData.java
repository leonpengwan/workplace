package com.inovalon.riskadjustment.memberattributes.staging.util;

import java.util.List;

/**
 * Created by kraju on 2/5/2018.
 */
public class MemberEvidenceData {

    public List<Integer> getMemberIds() {
        return this.memberIds;
    }

    public void setMemberIds( List<Integer> memberIds ) {
        this.memberIds = memberIds;
    }

    List<Integer> memberIds;
}

package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output;

import java.util.List;


public class InterventionPlanData {


  public InterventionPlanData() {
      super();
  }

    public List<Integer> getInterventionPlanRunIds() {
        return this.interventionPlanRunIds;
    }

    public void setInterventionPlanRunIds( List<Integer> interventionPlanRunIds ) {
        this.interventionPlanRunIds = interventionPlanRunIds;
    }

    public   List<Integer>interventionPlanRunIds;

}

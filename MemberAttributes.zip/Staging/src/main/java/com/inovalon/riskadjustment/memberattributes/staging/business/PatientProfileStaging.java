package com.inovalon.riskadjustment.memberattributes.staging.business;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.memberattributes.staging.util.PatientProfilePayload;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class PatientProfileStaging {
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the list of patient profile based on memberIds
     *
     * @param memberIds
     * @param runProfile *
     * @return It returns list of patientProfile
     * @throws Exception
     */
    @LogBeforeEvents
    //@RetryOnException(maxAttempts = 3, retryDelay = 1000)
    public List<PatientProfile> stagePatientProfile( List<Integer> memberIds, RunProfile runProfile ) throws Exception {
        logWriter.info("Beginning of stagePatientProfile");
        List<PatientProfile> patientProfiles = new ArrayList<>();

        try {
            PatientProfilePayload patientProfilePayload = new PatientProfilePayload();
            patientProfilePayload.ids = memberIds;
            patientProfilePayload.clientShortName = runProfile.getClientShortName();
            patientProfilePayload.projectShortName = runProfile.getProjectShortName();

            String url = stagingConfiguration.getPatientProviderProfileServiceBaseUrl() + MemberAttributesConstants.GET_FULL_PATIENT_PROFILE;
            String json = objectMapper.writeValueAsString(patientProfilePayload);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(json, headers);
            ResponseEntity<List<PatientProfile>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<PatientProfile>>() {
            });
            patientProfiles = responseEntity.getBody();
            logWriter.info("Ending of stagePatientProfile");
        } catch (RestClientException restException) {
            logWriter.error(restException.getMessage(), restException);
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
            throw ex;
        }
        return patientProfiles;
    }
}

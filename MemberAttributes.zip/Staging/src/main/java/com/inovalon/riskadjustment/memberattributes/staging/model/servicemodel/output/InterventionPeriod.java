package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output;

import java.util.Date;

/**
 * Created by kraju on 2/5/2018.
 */
public class InterventionPeriod {
   private Date planYear;
   private int  status;
    private int  clientId;

    public Date getLookBackDate() {
        return this.lookBackDate;
    }

    public void setLookBackDate( Date lookBackDate ) {
        this.lookBackDate = lookBackDate;
    }

    private Date lookBackDate;

    public Date getPlanYear() {
        return this.planYear;
    }

    public void setPlanYear( Date planYear ) {
        this.planYear = planYear;
    }

    public int getStatus() {
        return this.status;
    }

    public void setStatus( int status ) {
        this.status = status;
    }

    public int getClientId() {
        return this.clientId;
    }

    public void setClientId( int clientId ) {
        this.clientId = clientId;
    }


}

package com.inovalon.riskadjustment.memberattributes.staging.util;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.business.RunProfileRetrieve;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.LookBackPeriod;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


@Service
public class RetrieveInterventionPlanPeriod {

    @Autowired
    private RunProfileRetrieve runProfileRetrieve;
    @Autowired
    private LogWriter logWriter;

   @LogBeforeEvents
    public Date getInterventionPlanPeriod( long runProfileId ) throws ParseException {
        logWriter.info("Beginning of getInterventionPlanPeriod method");
        SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");

        RunProfile runProfile = runProfileRetrieve.getRunProfileByRunProfileId(runProfileId);

        Date startDate = runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod().getStart();

        int durationMonth = 8;

        Date loopBkDate = getYear(startDate, durationMonth);
        logWriter.info("Ending of getInterventionPlanPeriod method");
        return loopBkDate;
    }

    private Date getYear( Date planMonth, int period ) {
        int monthsPeriod = 0;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(planMonth);
        int planningMonth = calendar.get(Calendar.MONTH);
        int planningYear = calendar.get(Calendar.YEAR);
        int planningDate = 0;
        int year = period / 12;
        year = planningYear - year;
        int month = period % 12;
        if (month == 0) {
            month = planningMonth;
        } else if
                (month > planningMonth) {
            month = 12 - (month - planningMonth);
        } else {
            month = planningMonth - month;
        }
        calendar.set(year, month, planningDate);
        return calendar.getTime();
    }
    @LogBeforeEvents
    public Date getPreviousYearDateByLoopBackPeriod( Date planningDate, RunProfile runProfile ) {
        logWriter.info("Beginning of getPreviousYearDateByLoopBackPeriod method");
        int loopBackMonth = 0;
        try {
            LookBackPeriod loopBackPeriod = new LookBackPeriod();
            //Currently Name is hardcoded
            loopBackPeriod.setName("PreviousIntervention");
            //Currently duration month is hardcoded
            loopBackPeriod.setDurationInMonth(8);
            loopBackMonth = loopBackPeriod.getDurationInMonth();

        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
        }
        return getYear(planningDate, loopBackMonth);
    }
}

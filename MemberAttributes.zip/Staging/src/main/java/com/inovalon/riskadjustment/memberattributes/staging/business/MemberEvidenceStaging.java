package com.inovalon.riskadjustment.memberattributes.staging.business;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.staging.configuration.StagingConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.output.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.memberattributes.staging.util.MemberEvidenceData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class MemberEvidenceStaging {
    @Autowired
    private StagingConfiguration stagingConfiguration;
    @Autowired
    private Gateway gateway;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;
    @Autowired
    private LogWriter logWriter;
    @LogBeforeEvents
    public List<MemberEvidence> stageMemberEvidences( String gapSetId, int memberId, List<Integer> memberIds ) throws Exception {
        logWriter.info("Beginning of stageMemberEvidences method");
        List<MemberEvidence> memberEvidences = new ArrayList<>();
        MemberEvidenceData memberEvidenceData = new MemberEvidenceData();
        memberEvidenceData.setMemberIds(memberIds);
        try {

            if (memberIds != null) {
                if (memberIds.size() != 0) {
                    String json = objectMapper.writeValueAsString(memberEvidenceData);

                    String url = stagingConfiguration.getResultsDatabaseServiceBaseUrl() + MemberAttributesConstants.GET_MEMBER_EVIDENCE_BY_GAP_SET_DETAIL_ID_ON_MEMBER_IDS + "/" + gapSetId;
                    headers.setContentType(MediaType.APPLICATION_JSON);
                    HttpEntity<String> entity = new HttpEntity<>(json, headers);
                    ResponseEntity<List<MemberEvidence>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<MemberEvidence>>() {
                    });

                    memberEvidences = responseEntity.getBody();
                }

            }

        } catch (Exception exp) {
            logWriter.error(exp.getMessage(), exp);
            throw exp;
        }
        logWriter.info("Ending of stageMemberEvidences method");
        return memberEvidences;
    }
    @LogBeforeEvents
    public List<Integer> stageMemberIds( String gapSetId, int memberId ) throws Exception {
        logWriter.info("Beginning of stageMemberIds method");
        List<Integer> memberIds = new ArrayList<>();
        try {
            String url = stagingConfiguration.getResultsDatabaseServiceBaseUrl() + MemberAttributesConstants.GET_MEMBER_IDS_BY_BATCH + "/" + gapSetId + "/" + stagingConfiguration.getInBatchSize() + "/" + memberId;

            memberIds = gateway.getData(url, new TypeReference<List<Integer>>() {
            });

        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
            throw ex;
        }
        logWriter.info("Ending of stageMemberIds method");
        return memberIds;
    }
}

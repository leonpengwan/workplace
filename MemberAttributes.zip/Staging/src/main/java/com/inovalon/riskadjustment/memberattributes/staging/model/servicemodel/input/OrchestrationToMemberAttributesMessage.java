package com.inovalon.riskadjustment.memberattributes.staging.model.servicemodel.input;


public class OrchestrationToMemberAttributesMessage {
}

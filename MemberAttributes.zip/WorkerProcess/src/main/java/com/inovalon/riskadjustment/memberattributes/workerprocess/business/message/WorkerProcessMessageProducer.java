package com.inovalon.riskadjustment.memberattributes.workerprocess.business.message;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.configuration.WorkerProcessConfiguration;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class WorkerProcessMessageProducer {
    @Autowired
    private LogWriter logWriter;

    @Autowired
    private WorkerProcessConfiguration workerProcessConfiguration;

    @Autowired
    @Qualifier("messageBusPublisher")
    private MessageBusPublisher<WorkerProcessMessageAvro> messageBusPublisher;
    @LogBeforeEvents
    public boolean produceWorkerProcessMessage(WorkerProcessMessageAvro workerProcessMessageAvro) throws Exception{
        try{
//            System.out.println("Producer Messages runprofile Id "+workerProcessMessageAvro.runProfileId+" With member id "+workerProcessMessageAvro.getMemberAttributes() !=null?workerProcessMessageAvro.getMemberAttributes().getMemberId():0);
            logWriter.info("publishMessage to topic: " + workerProcessConfiguration.getKafkaProducerTopic());
            messageBusPublisher.publishMessage(workerProcessConfiguration.getKafkaProducerTopic(), workerProcessMessageAvro);
        }catch (Exception ex){
            ex.printStackTrace();
            logWriter.info("MemberAttributesWorkerProcess: produceWorkerProcessMessage Exception--" + ex.getMessage());
        }
        return true;
    }

}

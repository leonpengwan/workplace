package com.inovalon.riskadjustment.memberattributes.workerprocess.business;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.AttributeManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.GapExclusionManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.patient.service.PatientService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.ValidationManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberAttributesAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberEvidenceStatusAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.*;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.workerprocess.util.ModelToAvroConverter;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.GapDataSelection;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by pwan on 1/15/2018.
 */
@Component
public class WorkFlowManager {

    @Autowired
    private AttributeManager attributeManager;

    @Autowired
    private PatientService patientService;

    @Autowired
    private CacheManager cahCacheManager;

    @Autowired
    private GapExclusionManager gapExclusionManager;

    @Autowired
    private ValidationManager validationManager;

    @Autowired private ModelToAvroConverter modelToAvroConverter;
    @Autowired
    private LogWriter logWriter;


    /**
     * @param stagingMessage
     * @return Boolean
     * Description: This method mainly performs all pre-initialization of values from cache and  managing the control for the entire execution of the request.
     * Basically it get the values from the cache and send the request to attribute manager to apply attribute and calls the gap manager to manage the different types of Gap exclusions.
     * @throws Exception
     */
    @LogBeforeEvents
    @LogAfterEvents
    public WorkerProcessMessageAvro workFlowController(CustomizedStagingMessage stagingMessage) throws Exception {
        WorkerProcessMessageAvro workerProcessMessageAvro = new WorkerProcessMessageAvro();
        workerProcessMessageAvro.setRunProfileId(stagingMessage.getRunProfileId());
        workerProcessMessageAvro.setMemberAttributesRunId(stagingMessage.getMemberAttributesRunId());
        CacheUtil cacheUtil = cahCacheManager.loadDataFromCache(stagingMessage.getRunProfileId());
        MemberAttribute memberAttribute = new MemberAttribute();
        logWriter.info("workFlowController execution started");
        logWriter.info("Values are loaded from cache");
        RunProfile runProfile = cacheUtil.getRunProfile();
        logWriter.info("Loaded Runprofile with Id: " + runProfile.getRunProfileId());
        PatientProfile patientProfile = stagingMessage.getPatientProfile();
        //TODO:: Attribute set logic should go in Attribute Manager
        memberAttribute.setMemberAttributesRunId(stagingMessage.getMemberAttributesRunId());
        MemberAttributesAvro memberAttributesAvro = attributeManager.getMemberAttributeAvro(memberAttribute, runProfile, stagingMessage, cacheUtil);
        workerProcessMessageAvro.setMemberAttributes(memberAttributesAvro);
        if (!memberAttribute.isMissingProfile()) {
            List<MemberEvidenceStatusAvro> memberEvidenceStatusAvros = gapExclusionManager.HCCExclusions(runProfile, memberAttribute, patientProfile.getGenderCode(), stagingMessage.getMemberEvidences(), cacheUtil);
            workerProcessMessageAvro.setMemberEvidenceStatuses(memberEvidenceStatusAvros);
            //it will validate MemberValidation and PractitionerValidation
            Validation validation = validationManager.manageValidation(stagingMessage, memberAttribute, cacheUtil);
            workerProcessMessageAvro.setMemberValidation(validation.getMemberValidationAvro());
            workerProcessMessageAvro.setPractitionerValidation(validation.getPractitionerValidationAvro());
            workerProcessMessageAvro.setMessageStatus(true);
            workerProcessMessageAvro.setStatusDetail("Successfully processed all members");
            logWriter.info("Pushing member status to queue for memberid: " + patientProfile.getMemberId());
            //pushMemberStatusToQueue ( memberAttribute , memberEvidenceStatuses );
        }else{
            if(!CollectionUtils.isEmpty(stagingMessage.getMemberEvidences())){
                MemberEvidence memberEvidence = stagingMessage.getMemberEvidences().get(0);
                workerProcessMessageAvro.getMemberAttributes().setMemberId(memberEvidence.getMemberId());
                int gapSetDetailId  = getGapSetDetailIdFromRunProfile(cacheUtil.getRunProfile());
                List<MemberEvidenceStatus> memberEvidenceStatusList = mapMemberEvidenceToMemberEvidenceStatus(stagingMessage.getMemberEvidences(),gapSetDetailId,stagingMessage.getMemberAttributesRunId(), cacheUtil.getExclusionTypeModelMap ( ).get ( GapExclusionConstants.MISSING_PROFILE));
                List<MemberEvidenceStatusAvro> memberEvidenceStatusAvros =  modelToAvroConverter.memberEvidencesToMemberEvidenceAvro(memberEvidenceStatusList);
                workerProcessMessageAvro.setMemberEvidenceStatuses(memberEvidenceStatusAvros);
            }
        }
        return workerProcessMessageAvro;
    }

    private int getGapSetDetailIdFromRunProfile(RunProfile runProfile) {
        //Fetch the gapSetDetailID to fetch memberEvidence data
        for (GapDataSelection gapDataSelection : runProfile.getSections().getGapDataSelection().getGapDataSelections()) {
            if (gapDataSelection.getSelected()) {
                return gapDataSelection.getGapSetDetailId();
            }
        }
        return 0;
    }

    private List<MemberEvidenceStatus> mapMemberEvidenceToMemberEvidenceStatus(List<MemberEvidence> memberEvidences, int gapSetDetailId, int memberStatusRunId, ExclusionTypeModel hccConversionModel) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>(memberEvidences.size());
        for (MemberEvidence memberEvidence : memberEvidences) {
            MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
            memberEvidenceStatus.setMemberEvidenceId(memberEvidence.getMemberEvidenceId());
            memberEvidenceStatus.setGapSetDetailId(gapSetDetailId);
            memberEvidenceStatus.setMemberId(memberEvidence.getMemberId());
            memberEvidenceStatus.setPersonId(memberEvidence.getPersonId());
            memberEvidenceStatus.setPractitionerId(memberEvidence.getPractitionerId() == null ? 0 : memberEvidence.getPractitionerId());
            memberEvidenceStatus.setEncounterId(memberEvidence.getEncounterId() != null ? memberEvidence.getEncounterId() : 0);
            memberEvidenceStatus.setEncounterServiceDate(memberEvidence.getEncounterServiceDate() != null ? memberEvidence.getEncounterServiceDate().toString() : null);
            memberEvidenceStatus.setHccCode(memberEvidence.getHcc());
            memberEvidenceStatus.setGapConfidenceValue(memberEvidence.getGapConfidenceValue());
            memberEvidenceStatus.setGapConfidenceLevel(memberEvidence.getGapConfidenceLevel());
            memberEvidenceStatus.setExclusionId(hccConversionModel.getExclusionId());
            memberEvidenceStatus.setGapType(memberEvidence.getGapType());
            memberEvidenceStatus.setMemberAttributesRunId(memberStatusRunId);
            memberEvidenceStatus.setSaGapValue(memberEvidence.getSaGapValue());
            memberEvidenceStatus.setMeasureKey(memberEvidence.getMeasureKey()!=null?memberEvidence.getMeasureKey():null);
            memberEvidenceStatuses.add(memberEvidenceStatus);
        }
        return memberEvidenceStatuses;
    }


}

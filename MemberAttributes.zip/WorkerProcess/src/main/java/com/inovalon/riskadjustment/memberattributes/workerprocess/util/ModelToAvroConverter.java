package com.inovalon.riskadjustment.memberattributes.workerprocess.util;


import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberAttributesAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberEvidenceStatusAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ModelToAvroConverter {
    ModelToAvroConverter INSTANCE = Mappers.getMapper(ModelToAvroConverter.class);

    MemberAttributesAvro memberAttributeToMemberAttributesAvro(MemberAttribute memberAttribute);

    List<MemberEvidenceStatusAvro> memberEvidencesToMemberEvidenceAvro(List<MemberEvidenceStatus> memberEvidenceStatuses);

}

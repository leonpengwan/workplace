package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;


import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberValidationAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.PractitionerValidationAvro;

public class Validation {
    private MemberValidationAvro memberValidationAvro;
    private PractitionerValidationAvro practitionerValidationAvro;

    public Validation() {
    }

    public Validation(MemberValidationAvro memberValidationAvro, PractitionerValidationAvro practitionerValidationAvro) {
        this.memberValidationAvro = memberValidationAvro;
        this.practitionerValidationAvro = practitionerValidationAvro;
    }

    public MemberValidationAvro getMemberValidationAvro() {
        return memberValidationAvro;
    }

    public void setMemberValidationAvro(MemberValidationAvro memberValidationAvro) {
        this.memberValidationAvro = memberValidationAvro;
    }

    public PractitionerValidationAvro getPractitionerValidationAvro() {
        return practitionerValidationAvro;
    }

    public void setPractitionerValidationAvro(PractitionerValidationAvro practitionerValidationAvro) {
        this.practitionerValidationAvro = practitionerValidationAvro;
    }
}

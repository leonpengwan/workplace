package com.inovalon.riskadjustment.memberattributes.workerprocess.configuration;

/*import com.inovalon.riskadjustment.logger.LogManager;
import com.inovalon.riskadjustment.logger.TraceEventType;*/

import java.util.UUID;

public class Logger {

    /*private static final LogManager logManager = new LogManager();

    public static void error(String appName, Exception e){
        UUID uuid = UUID.randomUUID();
        logManager.WriteLog(uuid,appName,e.toString(),TraceEventType.Error);
    }*/


}

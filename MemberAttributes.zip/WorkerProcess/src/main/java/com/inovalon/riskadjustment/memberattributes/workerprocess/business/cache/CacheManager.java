package com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.cachewrapper.constant.CacheRetrieveConstant;
import com.inovalon.riskadjustment.cachewrapper.controller.CacheLoadService;
import com.inovalon.riskadjustment.cachewrapper.controller.RetrieveCacheService;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.model.servicemodel.cache.*;
import com.inovalon.riskadjustment.model.servicemodel.cache.constant.CacheNameConstant;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.GapConfidenceLevel;
import com.inovalon.riskadjustment.model.servicemodel.modelhhsmetallevel.ModelHhsMetalLevel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.inovalon.riskadjustment.cachewrapper.*;
import com.inovalon.riskadjustment.cachewrapper.constant.CacheLoadConstant;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by djose on 11/15/2017.
 */
@Component
public class CacheManager {

    @Autowired
    private RetrieveCacheService retrieveCacheService;
    @Autowired
    private CacheLoadService cacheLoadService;
    @Autowired
    private LogWriter logWriter;
    @LogBeforeEvents
    @LogAfterEvents
    public CacheUtil loadDataFromCache(long runProfileId) throws Exception {
        CacheUtil cacheUtil = new CacheUtil();

        loadHomeBoundLookUp(runProfileId, cacheUtil);
        loadRunProfile(runProfileId, cacheUtil);
        loadHhsHccCodeHierarchy(runProfileId, cacheUtil);
        loadGapConfidenceLevel(runProfileId, cacheUtil);
        loadExclusionTypeModel(runProfileId, cacheUtil);
        loadHhsHccConversionExclusion(runProfileId, cacheUtil);
        loadHhsMetalLevel(runProfileId, cacheUtil);
        getHccAgeGenderExclusionFromCache(runProfileId,cacheUtil);
        loadAgeGroup(runProfileId, cacheUtil);
        loadValidatedClientProviderIds(runProfileId, cacheUtil);
        getExclusionLstFromCache(runProfileId, cacheUtil);
        getHccCodeHierarchyFromCache(runProfileId, cacheUtil);
        getHhsFactorHccFromCache(runProfileId, cacheUtil);
        getHhsStateLevelPremiumAmountFromCache(runProfileId, cacheUtil);
        getGroupPlanTypeFromCache(runProfileId, cacheUtil);
        return cacheUtil;
    }
    @LogBeforeEvents
    private void loadHhsMetalLevel(long runProfileId, CacheUtil cacheUtil) throws Exception {

        //List<ModelHhsMetalLevel> hhsMetalLevels= gatewayConnectivity.getModelHhsMetalLevel();
      //  List<ModelHhsMetalLevel> hhsMetalLevels = (List<ModelHhsMetalLevel>) rmap.get(CacheNameConstant.METAL_LEVEL.cacheName());
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.METAL_LEVEL.cacheName());
        List<ModelHhsMetalLevel> hhsMetalLevels = (List<ModelHhsMetalLevel>) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        Map<String, ModelHhsMetalLevel> hhsMetalLevelMap = new HashMap<>();
        hhsMetalLevels.forEach(element -> {
            hhsMetalLevelMap.put(element.getMetalLevel(), element);
        });
        cacheUtil.setHhsMetalLevel(hhsMetalLevelMap);
    }
    @LogBeforeEvents
    private void loadAgeGroup(long runProfileId, CacheUtil cacheUtil) throws Exception {

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.AGE_GROUP.cacheName());
        List<AgeGroup> ageGroups = (List<AgeGroup>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        //List<AgeGroup> ageGroups = gatewayConnectivity.getAgeGroup();
        for (AgeGroup ageGroup : ageGroups) {
            if (ageGroup.getAgeTo() == null) ageGroup.setAgeTo(Integer.MAX_VALUE);
        }
        cacheUtil.setAgeGroup(ageGroups);
    }
    @LogBeforeEvents
    private void loadHhsHccConversionExclusion(long runProfileId, CacheUtil cacheUtil) throws Exception {

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.EXCLUSION_LIST.cacheName());
        List<ModelHhsHccConversionExclusionList> modelHhsHccConversionExclusionLists = (List<ModelHhsHccConversionExclusionList>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = new HashMap<>();
        modelHhsHccConversionExclusionLists.forEach(element -> {
            hccConversionExclusionListMap.put(element.getClientId() + "-" + element.getHccCode(), element);
        });
        cacheUtil.setHhsHccConversionExclusion(hccConversionExclusionListMap);
    }

    @LogBeforeEvents
    private void loadExclusionTypeModel(long runProfileId, CacheUtil cacheUtil) throws Exception {

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.GAP_EXCLUSION_TYPE.cacheName());
        List<ExclusionTypeModel> exclusionTypeModels = (List<ExclusionTypeModel>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setExclusionTypeModels(exclusionTypeModels);
        Map<String, ExclusionTypeModel> exclusionMap = new HashMap<>();
        for (ExclusionTypeModel exclusionTypeModel : exclusionTypeModels) {
            exclusionMap.put(exclusionTypeModel.getName(), exclusionTypeModel);
        }
        cacheUtil.setExclusionTypeModelMap(exclusionMap);
    }
    @LogBeforeEvents
    private void loadGapConfidenceLevel(long runProfileId, CacheUtil cacheUtil) throws Exception {

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.GAP_CONFIDENCE_LEVEL.cacheName());
        List<GapConfidenceLevel> gapConfidenceLevels = (List<GapConfidenceLevel>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        //List<GapConfidenceLevel> gapConfidenceLevels = gatewayConnectivity.getGapConfidence();
        if (gapConfidenceLevels != null && gapConfidenceLevels.size() > 0) {
            Map<String, Integer> confidenceMap = new HashMap<String, Integer>();
            for (GapConfidenceLevel gapConfidenceLevel : gapConfidenceLevels) {
                confidenceMap.put(gapConfidenceLevel.getName(), gapConfidenceLevel.getHierarchy());
            }
            cacheUtil.setGapConfidenceLevels(confidenceMap);
        }

    }
    @LogBeforeEvents
    private void loadHhsHccCodeHierarchy(long runProfileId, CacheUtil cacheUtil) throws Exception {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.CODE_HIERARCHY.cacheName());
        //Get the ModelHhsHccCodeHierarchy list
        List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies = (List<ModelHhsHccCodeHierarchy>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        //List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies = gatewayConnectivity.getHccCodeHierarchies(runProfileId);
        cacheUtil.setHhsHccCodeHierarchies(hhsHccCodeHierarchies);


    }

    private void loadRunProfile(long runProfileId, CacheUtil cacheUtil) throws Exception {
        //CacheNameConstant.RUN_PROFILE.cacheName()
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.RUN_PROFILE.cacheName());
        RunProfileModel runProfileModel = (RunProfileModel)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        //RunProfileModel runProfile = gatewayConnectivity.retrieveRunProfile(rmap);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new JSR310Module());
        RunProfile runProfile = objectMapper.readValue(runProfileModel.getProfile(), RunProfile.class);
        cacheUtil.setRunProfile(runProfile);
    }
    @LogBeforeEvents
    public void loadHomeBoundLookUp(long runProfileId, CacheUtil cacheUtil) {

        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        List<ModelHhsHomeBoundCode> modelHhsHomeBoundCode = new ArrayList<>();
        cacheRetrieveConstant.setKey(CacheNameConstant.HOME_BOUND_LOOKUP.cacheName());

        try {
            modelHhsHomeBoundCode = (List<ModelHhsHomeBoundCode>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);

            if (modelHhsHomeBoundCode != null && modelHhsHomeBoundCode.size() == 0) {
                logWriter.info("HomeBound cache size ==0");
            }

            if (modelHhsHomeBoundCode != null && modelHhsHomeBoundCode.size() != 0) {
                for (ModelHhsHomeBoundCode entity : modelHhsHomeBoundCode) {

                    switch (entity.getCodeType()) {

                        case "CPT":
                            cacheUtil.getModelHhsHomeBoundListCpt().add(entity);
                            break;

                        case "HCPCS":
                            cacheUtil.getModelHhsHomeBoundListHcpcs().add(entity);
                            break;

                        case "ICD":
                            cacheUtil.getModelHhsHomeBoundListIcd().add(entity);
                            break;
                    }
                }
            }
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }
    }

    public void getExclusionLstFromCache(long runProfileId, CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.EXCLUSION_LIST.cacheName());
        List<ModelHhsHccConversionExclusionList> modelHhsHccConversionExclusionLists = (List<ModelHhsHccConversionExclusionList>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = new HashMap<>();
        modelHhsHccConversionExclusionLists.forEach(element -> {
            hccConversionExclusionListMap.put(element.getClientId() + "-" + element.getHccCode(), element);
        });
        cacheUtil.setHhsHccConversionExclusion(hccConversionExclusionListMap);

    }
    @LogBeforeEvents
    @LogAfterEvents
    public void getHccCodeHierarchyFromCache(long runProfileId, CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.CODE_HIERARCHY.cacheName());
        List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies  = (List<ModelHhsHccCodeHierarchy>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setHhsHccCodeHierarchies(hhsHccCodeHierarchies);
    }
    @LogBeforeEvents
    @LogAfterEvents
    public void getHhsFactorHccFromCache(long runProfileId, CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.HHS_FACTOR.cacheName());
        List<ViewModelHhsFactorHcc> viewModelHhsFactorHccs = (List<ViewModelHhsFactorHcc>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setViewModelHhsFactorHccs(viewModelHhsFactorHccs);
    }
    @LogBeforeEvents
    @LogAfterEvents
    public void getHhsStateLevelPremiumAmountFromCache(long runProfileId, CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.STATE_LEVEL_PREMIUM_AMOUNT.cacheName());
        List<ModelHhsStateLevelPremiumAmount> modelHhsStateLevelPremiumAmounts = (List<ModelHhsStateLevelPremiumAmount>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setModelHhsStateLevelPremiumAmounts(modelHhsStateLevelPremiumAmounts);

    }
    @LogBeforeEvents
    public void getHccAgeGenderExclusionFromCache(long runProfileId,CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.AGE_GENDER_EXCLUSIONS.cacheName());
        List<ModelHhsHccAgeGenderExclusion>  modelHhsHccAgeGenderExclusions = (List<ModelHhsHccAgeGenderExclusion>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setHhsHccAgeGenderExclusions(modelHhsHccAgeGenderExclusions);
    }
    @LogBeforeEvents
    private void loadValidatedClientProviderIds(long runProfileId, CacheUtil cacheUtil) {
        try {
            CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
            cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
            cacheRetrieveConstant.setKey(CacheNameConstant.VALIDATED_PROVIDERS.cacheName());
            Set<String> validatedProviderIds = (Set<String>)retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
            if(validatedProviderIds == null){
                validatedProviderIds = new HashSet<>();
            }
            cacheUtil.setValidatedProviderIds(validatedProviderIds);

        } catch (Exception ex) {
            logWriter.error("Redisson Provider Exception "+ ex.getMessage(),ex);
        }
    }
    @LogBeforeEvents
    @LogAfterEvents
    public void addValidatedClientProviderIdInCache(long runProfileId, String clientProviderId) {
        try {
            CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
            cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
            cacheRetrieveConstant.setKey(CacheNameConstant.VALIDATED_PROVIDERS.cacheName());

            Set<String> validatedProviderIds = (Set<String>) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
            if (validatedProviderIds == null) {
                validatedProviderIds = new HashSet<String>();
            }
            validatedProviderIds.add(clientProviderId);
            Map<String,Set<String>>  map = new HashMap<String,Set<String>>();
            CacheLoadConstant<Map<String,Set<String>>> cacheLoadConstant = new CacheLoadConstant();
            cacheLoadConstant.setCacheName(String.valueOf(runProfileId));
            map.put(CacheNameConstant.MEMBER_ATTRIBUTES_AGGREGATOR_METADATA.cacheName(),validatedProviderIds);
            cacheLoadConstant.setValue(map);
            cacheLoadService.loadDataToCache(cacheLoadConstant);

        } catch (Exception ex) {
            logWriter.error("Redisson Provider Exception " + ex);
        }
    }
    @LogBeforeEvents
    @LogAfterEvents
    public void getGroupPlanTypeFromCache(long runProfileId, CacheUtil cacheUtil) throws IOException {
        CacheRetrieveConstant<String> cacheRetrieveConstant = new CacheRetrieveConstant();
        cacheRetrieveConstant.setCacheName(String.valueOf(runProfileId));
        cacheRetrieveConstant.setKey(CacheNameConstant.GROUP_PLAN_TYPE.cacheName());
        List<GroupPlanType> groupPlanTypes = (List<GroupPlanType>) retrieveCacheService.RetrieveCacheData(cacheRetrieveConstant);
        cacheUtil.setGroupPlanTypes(groupPlanTypes);
    }



}
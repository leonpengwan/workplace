package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Claim;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHomeBoundCode;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;


@Service("HomeBoundAttribute")
public class HomeBoundAttribute implements MemberProfileRealization {
    @Autowired
    private LogWriter logWriter;

    /**
     *  Set HomeBound status
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @Override
    public void applyRules(RunProfile runProfile, CustomizedStagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        logWriter.info("getHomeBoundStatusByMemberId execution started");

        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();

        List<Claim> claims = patientProfile.getClaims();

        logWriter.info("Number of claims retrieved for member : " + claims.size());
        long totalClaims = 0L;

        //Get current date time
        LocalDate now = LocalDate.now();
        logWriter.info("Current time : " + now);


        try {
            List<ModelHhsHomeBoundCode> homeBoundCpt = cacheUtil.getModelHhsHomeBoundListCpt();
            logWriter.info("Count of CPT codes retrieved from cache : " + homeBoundCpt.size());


            List<ModelHhsHomeBoundCode> homeBoundHcpcs = cacheUtil.getModelHhsHomeBoundListHcpcs();
            logWriter.info("Count of HCPCS codes retrieved from cache : " + homeBoundHcpcs.size());

            List<ModelHhsHomeBoundCode> homeBoundICD = cacheUtil.getModelHhsHomeBoundListIcd();
            logWriter.info("Count of ICD codes retrieved from cache : " + homeBoundICD.size());

            if (claims.size() > 0) {

                // get total claim count within 12 months
                totalClaims = claims.stream().filter( claim -> {
                    LocalDate adminssionDate = (claim.getAdmissionDate() != null) ? claim.getAdmissionDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate() : LocalDate.parse("1970-01-01");
                    return ChronoUnit.DAYS.between(adminssionDate, now) <= 365;
                }).count();

                //Loop through Claims
                for (Claim entity : claims) {
                    try {
                        Date admissionDateString = entity.getAdmissionDate();
                        LocalDate admissionDate = admissionDateString.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                        if (calculateDaysBetweenTwoDates(admissionDate, now) <= 365) { //condition: within 12 months from current day

                            List<String> cptpxCodes = entity.getCptPXCodes();
                            List<String> hcpcspxCodes = entity.getHcpcsPXCodes();
                            List<List<String>> icddxCodes = entity.getIcdDXCodes();
                            List<List<String>> icddx10Codes = entity.getIcdDX10Codes();

                            boolean isHomeBoundCptGroup2 = homeBoundCpt.stream().filter(cpt -> {
                                return cpt.getHomeBoundGroup() == 2 & cptpxCodes.contains(cpt.getCode());
                            }).findAny().isPresent();

                            // if meeting these two conditions, loop end
                            if(totalClaims >= 5 && isHomeBoundCptGroup2){
                                // condition: more than 5 claims and at least one cpt code in the list
                                memberAttribute.setHomebound(true);
                                break;
                            }

                            boolean isHomeBoundHcpcsGroup1 = homeBoundHcpcs.stream().filter(hcpcs ->
                                 hcpcs.getHomeBoundGroup() == 1 && hcpcspxCodes.contains(hcpcs.getCode())
                            ).findAny().isPresent();

                            if(isHomeBoundHcpcsGroup1){
                                // condition: one hcpc code in the list of group1
                                memberAttribute.setHomebound(true);
                                break;
                            }

                            boolean isHomeBoundHcpcsGroup2 = homeBoundHcpcs.stream().filter(hcpcs ->
                                    hcpcs.getHomeBoundGroup() == 2 && hcpcspxCodes.contains(hcpcs.getCode())
                            ).findAny().isPresent();

                            if(totalClaims >= 5 && isHomeBoundHcpcsGroup2)
                            {
                                // condtion: more than 5 claims and at least one hcpcs code in the list
                                memberAttribute.setHomebound(true);
                                break;
                            }

                            boolean isIcd9Group1 = homeBoundICD.stream().filter(icd -> {
                                Predicate<List> predicate = c -> c.get(0).equals(icd.getCode());
                                return icd.getHomeBoundGroup() == 1 && icd.getIcdVersionInd() == 9 && icddxCodes.stream().anyMatch(predicate);
                            }).findAny().isPresent();

                            if (isIcd9Group1) {
                                // condtion: one icd9 code in the list of group1
                                memberAttribute.setHomebound(true);
                                break;
                            }

                            boolean isIcd10Group1 = homeBoundICD.stream().filter(icd->{
                                Predicate<List> predicate = c -> c.get(0).equals(icd.getCode());
                                return icd.getHomeBoundGroup() == 1 && icd.getIcdVersionInd() == 10 && icddx10Codes.stream().anyMatch(predicate);
                            }).findAny().isPresent();

                            if(isIcd10Group1){
                                // condtion: one icd10 code in the list of group1
                                memberAttribute.setHomebound(true);
                                break;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            logWriter.info("getHomeBoundStatusByMemberId execution completed");
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }
    }

    private long calculateDaysBetweenTwoDates(LocalDate Date1, LocalDate Date2) {
        System.out.println(ChronoUnit.DAYS.between(Date1, Date2));
        return ChronoUnit.DAYS.between(Date1, Date2);
    }
}

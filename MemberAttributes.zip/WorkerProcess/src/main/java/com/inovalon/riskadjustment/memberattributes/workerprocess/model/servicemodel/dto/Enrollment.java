/**
 * 
 */
package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

import java.util.Date;

/**
 * @author fmaradirangaiah
 *
 */
public class Enrollment {
	
	private int memberEnrollmentId;
	private Date coverageEndDate;
	private Date coverageBeginDate;
	private String metalLevel;
	private String hospiceInd;
	private String clientProviderId;

	public String getMetalLevel() {
		return metalLevel;
	}
	public void setMetalLevel(String metalLevel) {
		this.metalLevel = metalLevel;
	}
	public int getMemberEnrollmentId() {
		return memberEnrollmentId;
	}
	public void setMemberEnrollmentId(int memberEnrollmentId) {
		this.memberEnrollmentId = memberEnrollmentId;
	}
	public Date getCoverageEndDate() {
		return coverageEndDate;
	}
	public void setCoverageEndDate(Date coverageEndDate) {
		this.coverageEndDate = coverageEndDate;
	}
	public Date getCoverageBeginDate() {
		return coverageBeginDate;
	}
	public void setCoverageBeginDate(Date coverageBeginDate) {
		this.coverageBeginDate = coverageBeginDate;
	}
	public String getHospiceInd() {
		return hospiceInd;
	}
	public void setHospiceInd(String hospiceInd) {
		this.hospiceInd = hospiceInd;
	}
	public String getClientProviderId() {
		return clientProviderId;
	}
	public void setClientProviderId(String clientProviderId) {
		this.clientProviderId = clientProviderId;
	}
}

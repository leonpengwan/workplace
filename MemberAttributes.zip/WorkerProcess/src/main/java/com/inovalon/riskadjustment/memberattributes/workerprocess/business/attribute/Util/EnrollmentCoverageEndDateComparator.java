package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util;

import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;

import java.util.Comparator;
import java.util.Date;

public class EnrollmentCoverageEndDateComparator implements Comparator<Enrollment> {

    public int compare(Enrollment enrollment1, Enrollment enrollment2) {
        Date date1 = enrollment1.getCoverageEndDate();
        Date date2 = enrollment2.getCoverageEndDate();
        //descending order
        return date2.compareTo(date1);
    }
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.configuration.Logger;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.cache.AgeGroup;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("AgeGroupDetermine")
public class AgeGroupDetermine implements MemberAttributeIdentification {
    @Autowired
    private LogWriter logWriter;

    /**
     *  This class mainly check the age group based on the patient age.
     * @param runProfile
     * @param patientProfile
     * @param memberAttribute
     * @param cacheUtil
     * @throws RangException
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void setAttributeValue(RunProfile runProfile, PatientProfile patientProfile, MemberAttribute memberAttribute, CacheUtil cacheUtil) throws RangException {
        try{
            logWriter.info("Beginning of AgeGroupDetermine");
            for (AgeGroup ageGroup : cacheUtil.getAgeGroup()) {
                if (memberAttribute.getAge() >= ageGroup.getAgeFrom() && memberAttribute.getAge() <= ageGroup.getAgeTo()) {
                    memberAttribute.setAgeGroupId(ageGroup.getAgeGroupId());
                    memberAttribute.setAgeGroup(ageGroup.getDescription());
                    break;
                }
            }
            logWriter.info("Ending of AgeGroupDetermine");
        }catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            throw new RangException(ex);
        }
    }
}

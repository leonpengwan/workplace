package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author fmaradirangaiah
 *
 */
public class Claim {

	public int getClaimId() {
		return claimId;
	}

	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}

	private int claimId;
	private String clientProviderId;
	private String clientMemberId;
	private Date admissionDate;
	private List<String> cptPXCodes = new ArrayList<>();
	private List<String> hcpcsPXCodes = new ArrayList<>();
	private List<List<String>> icdDXCodes = new ArrayList<>();
	private List<List<String>> icdDX10Codes = new ArrayList<>();
	public Date getAdmissionDate() {
		return admissionDate;
	}
	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}
	public List getCptPXCodes() {
		return cptPXCodes;
	}
	public void setCptPXCodes(List<String> cptPXCodes) {
		this.cptPXCodes = cptPXCodes;
	}
	public List getHcpcsPXCodes() {
		return hcpcsPXCodes;
	}
	public void setHcpcsPXCodes(List<String> hcpcsPXCodes) {
		this.hcpcsPXCodes = hcpcsPXCodes;
	}

	public List<List<String>> getIcdDXCodes() {
		return icdDXCodes;
	}

	public void setIcdDXCodes(List<List<String>> icdDXCodes) {
		this.icdDXCodes = icdDXCodes;
	}

	public List<List<String>> getIcdDX10Codes() {
		return icdDX10Codes;
	}

	public void setIcdDX10Codes(List<List<String>> icdDX10Codes) {
		this.icdDX10Codes = icdDX10Codes;
	}

	public String getClientProviderId() {
		return clientProviderId;
	}
	public void setClientProviderId(String clientProviderId) {
		this.clientProviderId = clientProviderId;
	}
	public String getClientMemberId() {
		return clientMemberId;
	}
	public void setClientMemberId(String clientMemberId) {
		this.clientMemberId = clientMemberId;
	}

}

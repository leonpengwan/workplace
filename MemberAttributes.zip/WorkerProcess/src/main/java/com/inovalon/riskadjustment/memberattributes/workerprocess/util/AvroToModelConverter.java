package com.inovalon.riskadjustment.memberattributes.workerprocess.util;

import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.InterventionPlanAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.MemberEvidenceAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.StagingMessageAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.patientprofile.ClaimAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.patientprofile.EnrollmentAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.patientprofile.PatientProfileAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.providerprofile.AddressAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.providerprofile.NameAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.providerprofile.ProviderProfileAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Address;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Claim;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Name;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.InterventionPlan;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class AvroToModelConverter {

    private static final DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static CustomizedStagingMessage avroToModel(StagingMessageAvro stagingMessageAvro) {
        CustomizedStagingMessage customizedStagingMessage = new CustomizedStagingMessage();
        customizedStagingMessage.setRunProfileId(stagingMessageAvro.getRunProfileId());
        customizedStagingMessage.setInterventionPlans(interventionPlanAvrosToModelList(stagingMessageAvro.getInterventionPlans()));
        customizedStagingMessage.setMemberAttributesRunId(stagingMessageAvro.MemberAttributesRunId);
        customizedStagingMessage.setPatientProfile(avroToModel(stagingMessageAvro.patientProfile));
        customizedStagingMessage.setProviderProfiles(provierProfilesAvrosToModelList(stagingMessageAvro.providerProfiles));
        customizedStagingMessage.setMemberEvidences(memberEvidenceAvrosToModel(stagingMessageAvro.memberEvidences));
        customizedStagingMessage.setRunProfileId(stagingMessageAvro.runProfileId);
        return customizedStagingMessage;
    }

    private static List<MemberEvidence> memberEvidenceAvrosToModel(List<MemberEvidenceAvro> memberEvidenceAvros) {
        List<MemberEvidence> memberEvidences = new ArrayList<>();
        if(memberEvidenceAvros !=null && memberEvidenceAvros.size() > 0)
        for (MemberEvidenceAvro memberEvidenceAvro : memberEvidenceAvros) {
            MemberEvidence memberEvidence = new MemberEvidence();
            memberEvidence.setEncounterId(memberEvidenceAvro.getEncounterId());
            memberEvidence.setEncounterServiceDate(getDate(memberEvidenceAvro.getEncounterServiceDate()));
            memberEvidence.setGapConfidenceLevel(convertCharSequenceToString(memberEvidenceAvro.getGapConfidenceLevel()));
            memberEvidence.setGapSetId(convertCharSequenceToString(memberEvidenceAvro.getGapSetId()));
            memberEvidence.setGapConfidenceValue(memberEvidenceAvro.getGapConfidenceValue());
            memberEvidence.setGapType(convertCharSequenceToString(memberEvidenceAvro.getGapType()));
            memberEvidence.setHcc(convertCharSequenceToString(memberEvidenceAvro.getHcc()));
            memberEvidence.setPersonId(convertCharSequenceToString(memberEvidenceAvro.getPersonId()));
            memberEvidence.setMemberEvidenceId(memberEvidenceAvro.getMemberEvidenceId());
            memberEvidence.setMemberId(memberEvidenceAvro.getMemberId());
            memberEvidence.setPractitionerId(memberEvidenceAvro.getPractitionerId());
            memberEvidence.setMeasureKey(convertCharSequenceToString(memberEvidenceAvro.getMeasureKey()));
            memberEvidence.setSaGapValue(memberEvidenceAvro.getSaGapValue());
            memberEvidences.add(memberEvidence);
        }
        return memberEvidences;
    }

    private static PatientProfile avroToModel(PatientProfileAvro patientProfileAvro) {
        PatientProfile patientProfile = null;
        if(patientProfileAvro!=null ) {
            patientProfile = new PatientProfile();
            patientProfile.setMemberId(patientProfileAvro.getMemberId());
            patientProfile.setBirthDate(getDate(patientProfileAvro.birthDate));
            patientProfile.setGenderCode(convertCharSequenceToString(patientProfileAvro.getGenderCode()));
            patientProfile.setDeceasedDate(getDate(patientProfileAvro.deceasedDate));
            patientProfile.setFirstName(convertCharSequenceToString(patientProfileAvro.firstName));
            patientProfile.setLastName(convertCharSequenceToString(patientProfileAvro.lastName));
            patientProfile.setMemberId(patientProfileAvro.memberId);
            patientProfile.setClaims(claimsAvroToModelList(patientProfileAvro.claims));
            patientProfile.setEnrollments(enrollmentsAvroToModelList(patientProfileAvro.enrollments));
            patientProfile.setAddressLine1(convertCharSequenceToString(patientProfileAvro.addressLine1));
            patientProfile.setAddressLine2(convertCharSequenceToString(patientProfileAvro.addressLine2));
            patientProfile.setCity(convertCharSequenceToString(patientProfileAvro.city));
            patientProfile.setStateCode(convertCharSequenceToString(patientProfileAvro.stateCode));
            patientProfile.setZip(convertCharSequenceToString(patientProfileAvro.zip));
            patientProfile.setPhoneNumber(convertCharSequenceToString(patientProfileAvro.phoneNumber));
        }

        return patientProfile;
    }

    private static List<Enrollment> enrollmentsAvroToModelList(List<EnrollmentAvro> enrollmentAvros) {
        List<Enrollment> enrollments = new ArrayList<>();
        if(!CollectionUtils.isEmpty(enrollmentAvros))
        for (EnrollmentAvro enrollmentAvro : enrollmentAvros) {
            Enrollment enrollment = new Enrollment();
            enrollment.setMetalLevel(convertCharSequenceToString(enrollmentAvro.getMetalLevel()));
            //enrollment.setState(convertCharSequenceToString(enrollmentAvro.get));
            enrollment.setCoverageBeginDate(getDate(enrollmentAvro.getCoverageBeginDate()));
            enrollment.setCoverageEndDate(getDate(enrollmentAvro.getCoverageEndDate()));
            enrollment.setMemberEnrollmentId(enrollmentAvro.getMemberEnrollmentId());
            enrollment.setHospiceInd(convertCharSequenceToString(enrollmentAvro.hospiceInd));
            enrollment.setClientProviderId(convertCharSequenceToString(enrollmentAvro.clientProviderId));
            enrollments.add(enrollment);
        }
        return enrollments;
    }

    private static List<String> avroListToList(List<CharSequence> list) {
        List<String> codeAvro = new ArrayList<>();
        if(list != null && list.size() != 0 ){
            list.forEach(l ->{codeAvro.add(l.toString());});
        }
        return codeAvro;
    }

    private static List<List<String>> avroListListToListList(List<List<CharSequence>> list) {
        List<List<String>> codeAvro = new ArrayList<>();
        if(list != null && list.size() != 0 ){
            for(List<CharSequence> code : list){
                List<String> codeAvroSub = new ArrayList<>();
                code.removeAll(Collections.singleton(null));
                if(code != null && code.size() != 0) {
                    code.forEach(c -> {codeAvroSub.add(c.toString());});
                }
                codeAvro.add(codeAvroSub);
            }
        }
        return codeAvro;
    }

    private static List<Claim> claimsAvroToModelList(List<ClaimAvro> claimAvros){
        List<Claim> claims = new ArrayList<>();
        if(claimAvros!=null && claimAvros.size() > 0)
        for (ClaimAvro claimAvro : claimAvros) {
            Claim claim = new Claim();
            claim.setAdmissionDate(getDate(claimAvro.admissionDate));
            if(claimAvro.getCptpxCodes() != null && claimAvro.getCptpxCodes().size() != 0){
                claim.setCptPXCodes(avroListToList(claimAvro.getCptpxCodes()));
                //Collections.copy(claim.getCptPXCodes(), claimAvro.cptModCodes);
            }
            if(claimAvro.getHcpcspxCodes() != null && claimAvro.getHcpcspxCodes().size() != 0) {
                claim.setHcpcsPXCodes(avroListToList(claimAvro.getHcpcspxCodes()));
                //Collections.copy(claim.getHcpcsPXCodes(), claimAvro.hcpcspxCodes);
            }
            if(claimAvro.getIcddx10Codes() != null && claimAvro.getIcddx10Codes().size() != 0) {
                claim.setIcdDX10Codes(avroListListToListList(claimAvro.getIcddx10Codes()));
               // Collections.copy(claim.getIcdDX10Codes(), claimAvro.icddx10Codes);
            }
            if(claimAvro.getIcddxCodes() != null && claimAvro.getIcddxCodes().size() != 0) {
                claim.setIcdDXCodes(avroListListToListList(claimAvro.getIcddxCodes()));
               // Collections.copy(claim.getIcdDXCodes(), claimAvro.icddxCodes);
            }
            claims.add(claim);
        }
        return claims;
    }


    private static List<com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.InterventionPlan> interventionPlanAvrosToModelList(List<InterventionPlanAvro> interventionPlanAvros){
        List<InterventionPlan> interventionPlans = new ArrayList<>();
        if(interventionPlanAvros!=null && interventionPlanAvros.size() > 0)
            for (InterventionPlanAvro interventionPlanAvro : interventionPlanAvros) {
                InterventionPlan interventionPlan = new InterventionPlan();
//                interventionPlan.setInterventionPlanDetail(convertCharSequenceToString(interventionPlanAvro.getInterventionPlanDetail()));//!=null?interventionPlanAvro.getInterventionPlanDetail().toString():null);
                interventionPlan.setInterventionPlanId(interventionPlanAvro.getInterventionPlanId());
                interventionPlan.setInterventionYear(interventionPlanAvro.getInterventionYear());
                interventionPlan.setMemberId(interventionPlanAvro.getMemberId());
                interventionPlan.setPersonId(convertCharSequenceToString(interventionPlanAvro.getPersonId()));
                interventionPlan.setInterventionPlanRunId(interventionPlanAvro.getInterventionPlanRunId());
                interventionPlans.add(interventionPlan);
            }
        return interventionPlans;
    }

    private static String convertCharSequenceToString(CharSequence propertyValue) {
        if(propertyValue!=null){
            return propertyValue.toString();
        }
        return null;
    }


    static Date getDate(CharSequence date){
        try {
            if(date!=null && !StringUtils.isEmpty(date.toString()))
            return formatter.parse(date.toString());
        } catch (ParseException e) {
            System.out.println("Date parsing exception"+e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    private  static List<ProviderProfile> provierProfilesAvrosToModelList(List<ProviderProfileAvro> providerProfileAvros){
        List<ProviderProfile> provierProfiles = new ArrayList<>();
        if(providerProfileAvros!=null && providerProfileAvros.size()>0 )
        for (ProviderProfileAvro providerProfileAvro: providerProfileAvros) {
            ProviderProfile provierProfile = new ProviderProfile();
            provierProfile.setClientProviderId(convertCharSequenceToString(providerProfileAvro.getClientProviderId()));
            if(convertCharSequenceToString(providerProfileAvro.providerId).indexOf(".") != -1) {
                provierProfile.setProviderId(convertCharSequenceToString(providerProfileAvro.providerId).substring(0, convertCharSequenceToString(providerProfileAvro.providerId).indexOf(".")));
            }else{
                provierProfile.setProviderId(convertCharSequenceToString(providerProfileAvro.providerId));
            }
            provierProfile.setName(namesAvroToModelList(providerProfileAvro.name));
            provierProfile.setAddress(addresssAvroToModelList(providerProfileAvro.address));
            provierProfiles.add(provierProfile);
        }
        return provierProfiles;
    }

    private static List<Name> namesAvroToModelList(List<NameAvro> nameAvros) {
        List<Name> names = new ArrayList<>();
        for(NameAvro nameAvro : nameAvros){
            Name name = new Name();
            name.setFirstName(convertCharSequenceToString(nameAvro.firstName));
            name.setLastName(convertCharSequenceToString(nameAvro.lastName));
            name.setFullName(convertCharSequenceToString(nameAvro.fullName));
            name.setMiddleName(convertCharSequenceToString(nameAvro.middleName));
            name.setNameActivationDate(getDate(nameAvro.getNameActivationDate()));
            name.setNameRetirementDate(getDate(nameAvro.getNameRetirementDate()));
            name.setNameType(convertCharSequenceToString(nameAvro.getNameType()));
            names.add(name);
        }
        return names;
    }

    private static List<Address> addresssAvroToModelList(List<AddressAvro> addressAvros) {
        List<Address> addresses = new ArrayList<>();
        for(AddressAvro addressAvro : addressAvros){
            Address address = new Address();
            address.setAddressLine1(convertCharSequenceToString(addressAvro.addressLine1));
            address.setAddressLine2(convertCharSequenceToString(addressAvro.addressLine2));
            address.setCity(convertCharSequenceToString(addressAvro.city));
            address.setState(convertCharSequenceToString(addressAvro.state));
            address.setZip(convertCharSequenceToString(addressAvro.zip));
            address.setPhone(convertCharSequenceToString(addressAvro.phone));
            address.setFaxNumber1(convertCharSequenceToString(addressAvro.faxNumber1));
            address.setLocationKey(convertCharSequenceToString(addressAvro.locationKey));
            address.setAddressType(convertCharSequenceToString(addressAvro.addressType));
            address.setAddressRetirementDate(getDate(addressAvro.addressRetirementDate));
            address.setAddressActivationDate(getDate(addressAvro.addressActivationDate));
            addresses.add(address);
        }
        return addresses;
    }
}

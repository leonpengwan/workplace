package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

import java.util.List;

/***
 *
 * @author fmaradirangaiah
 *
 */

public class CustomizedStagingMessage {

    private int parentRunId;
    private long runProfileId;
    private int MemberAttributesRunId;
    private PatientProfile patientProfile;
    private List<ProviderProfile> providerProfiles;
    private List<MemberEvidence> memberEvidences;
    private List<InterventionPlan> interventionPlans;


    public List<MemberEvidence> getMemberEvidences() {
        return memberEvidences;
    }

    public void setMemberEvidences(List<MemberEvidence> memberEvidences) {
        this.memberEvidences = memberEvidences;
    }

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getMemberAttributesRunId() {
        return MemberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        MemberAttributesRunId = memberAttributesRunId;
    }

    public PatientProfile getPatientProfile() {
        return patientProfile;
    }

    public void setPatientProfile(PatientProfile patientProfile) {
        this.patientProfile = patientProfile;
    }

    public List<ProviderProfile> getProviderProfiles() {
        return providerProfiles;
    }

    public void setProviderProfiles(List<ProviderProfile> providerProfiles) {
        this.providerProfiles = providerProfiles;
    }


    public List<InterventionPlan> getInterventionPlans() {
        return interventionPlans;
    }

    public void setInterventionPlans(List<InterventionPlan> interventionPlans) {
        this.interventionPlans = interventionPlans;
    }

    public int getParentRunId() {
        return parentRunId;
    }

    public void setParentRunId(int parentRunId) {
        this.parentRunId = parentRunId;
    }
}

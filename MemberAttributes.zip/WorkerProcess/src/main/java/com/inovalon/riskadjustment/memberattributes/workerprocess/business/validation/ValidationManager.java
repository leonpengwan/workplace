package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service.MemberValidationService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service.PractitionerValidationService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.mapper.ValidationMapper;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PractitionerValidation;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Validation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by pwan on 1/15/2018.
 */
@Component
public class ValidationManager {

    @Autowired
    private MemberValidationService memberValidationService;

    @Autowired
    private PractitionerValidationService practitionerValidationService;

    @Autowired
    private ValidationMapper validationMapper;
    @LogBeforeEvents
    public Validation manageValidation(CustomizedStagingMessage stagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil){

        Validation validation = new Validation();

        MemberValidation memberValidation = memberValidationService.validateMember(stagingMessage.getPatientProfile(), memberAttribute.getMemberAttributesRunId());

        PractitionerValidation practitionerValidation = practitionerValidationService.validatePractitioner(stagingMessage, memberAttribute, cacheUtil);

        validation.setMemberValidationAvro(validationMapper.memberValidationToMemberValidationAvro(memberValidation));
        validation.setPractitionerValidationAvro(validationMapper.practitionerValidationToPractitionerValidationAvro(practitionerValidation));

        return  validation;
    }
}

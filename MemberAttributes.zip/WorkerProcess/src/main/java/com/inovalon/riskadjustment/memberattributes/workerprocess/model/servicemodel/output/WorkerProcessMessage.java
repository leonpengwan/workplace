package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output;


import com.inovalon.riskadjustment.shared.messagebus.model.MessageEnvelope;

import java.util.List;

public class WorkerProcessMessage extends MessageEnvelope {
    private long runProfileId;
    private int memberAttributesRunId;
    private MemberAttributes memberAttributes;
    private List<MemberEvidenceStatus> memberEvidenceStatuses;
    private MemberValidation memberValidation;
    private PractitionerValidation practitionerValidation;

    public WorkerProcessMessage() {
    }

    public WorkerProcessMessage(long runProfileId, int memberAttributesRunId, MemberAttributes memberAttributes, List<MemberEvidenceStatus> memberEvidenceStatuses, MemberValidation memberValidation, PractitionerValidation practitionerValidation) {
        this.runProfileId = runProfileId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.memberAttributes = memberAttributes;
        this.memberEvidenceStatuses = memberEvidenceStatuses;
        this.memberValidation = memberValidation;
        this.practitionerValidation = practitionerValidation;
    }

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public MemberAttributes getMemberAttributes() {
        return memberAttributes;
    }

    public void setMemberAttributes(MemberAttributes memberAttributes) {
        this.memberAttributes = memberAttributes;
    }

    public List<MemberEvidenceStatus> getMemberEvidenceStatuses() {
        return memberEvidenceStatuses;
    }

    public void setMemberEvidenceStatuses(List<MemberEvidenceStatus> memberEvidenceStatuses) {
        this.memberEvidenceStatuses = memberEvidenceStatuses;
    }

    public MemberValidation getMemberValidation() {
        return memberValidation;
    }

    public void setMemberValidation(MemberValidation memberValidation) {
        this.memberValidation = memberValidation;
    }

    public PractitionerValidation getPractitionerValidation() {
        return practitionerValidation;
    }

    public void setPractitionerValidation(PractitionerValidation practitionerValidation) {
        this.practitionerValidation = practitionerValidation;
    }
}

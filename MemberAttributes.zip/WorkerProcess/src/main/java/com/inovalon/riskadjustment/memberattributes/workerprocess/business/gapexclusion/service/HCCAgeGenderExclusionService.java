package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccAgeGenderExclusion;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service("HCCAgeGenderExclusion")
public class HCCAgeGenderExclusionService implements GapExclusionService {
    @Autowired
    private LogWriter logWriter;

    /**
     *
     * @param runProfile
     * @param memberEvidenceStatuses
     * @param cacheUtil
     * @param memberAttribute
     */
    @LogBeforeEvents
    @Override
    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatuses, CacheUtil cacheUtil, MemberAttribute memberAttribute) {

        ExclusionTypeModel exclusionType = cacheUtil.getExclusionTypeModelMap().get(GapExclusionConstants.HCC_AGE_OR_GENDER_EXCLUSION);

        logWriter.info("Begin processing ExcludeHccsByAgeOrGender...");
        Set<MemberEvidenceStatus> includedMemberEvidenceStatuses = new HashSet<>();

        try {
            List<ModelHhsHccAgeGenderExclusion> hhsHccAgeGenderExclusions = cacheUtil.getHhsHccAgeGenderExclusions();

            for (MemberEvidenceStatus memberEvidenceStatus : memberEvidenceStatuses) {
                if (memberEvidenceStatus.getExclusionId() != 0) continue;
                ModelHhsHccAgeGenderExclusion hhsHccAgeGenderExclusion = hhsHccAgeGenderExclusions.stream().filter(o -> o.getHccCode().equals(memberEvidenceStatus.getHccCode())).findFirst().orElse(null);
                if (hhsHccAgeGenderExclusion != null) {
                    int ageFrom = hhsHccAgeGenderExclusion.getAgeFrom() != null ? hhsHccAgeGenderExclusion.getAgeFrom() : 0;
                    int ageTo = hhsHccAgeGenderExclusion.getAgeTo() != null ? hhsHccAgeGenderExclusion.getAgeTo() : 200;
                    String hhsHccAgeGenderExclusionGender = hhsHccAgeGenderExclusion.getGender() != null ? hhsHccAgeGenderExclusion.getGender() : "";

                    if ((memberAttribute.getAge() >= ageFrom && memberAttribute.getAge() <= ageTo) || hhsHccAgeGenderExclusionGender.equals(memberAttribute.getGender())) {
                        memberEvidenceStatus.setExclusionId(exclusionType.getExclusionId());
                    }
                }
            }
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);


        }
        logWriter.info("End processing ExcludeHccsByAgeOrGender...");
    }
}
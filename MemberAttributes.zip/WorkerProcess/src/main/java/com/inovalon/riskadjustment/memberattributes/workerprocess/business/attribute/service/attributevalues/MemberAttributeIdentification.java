package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;

public interface MemberAttributeIdentification {

    public void setAttributeValue(RunProfile runProfile, PatientProfile patientProfile, MemberAttribute memberAttribute, CacheUtil cacheUtil) throws RangException;

}

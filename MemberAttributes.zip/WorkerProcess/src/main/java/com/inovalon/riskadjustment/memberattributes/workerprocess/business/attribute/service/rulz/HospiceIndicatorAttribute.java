package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service("HospiceIndicatorAttribute")
public class HospiceIndicatorAttribute implements MemberProfileRealization {

    /**
     * Set the Hospice MemberStatus
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @LogAfterEvents
   @Override
   public void applyRules(RunProfile runProfile, CustomizedStagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
       PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();
        if (!Objects.isNull(patientProfile.getEnrollments())) {
            Enrollment enrollment = patientProfile.getEnrollments().get(0);
            if (enrollment.getMemberEnrollmentId() == memberAttribute.getWinningEnrollmentId()) {
                if ("Y".equalsIgnoreCase(enrollment.getHospiceInd())) {
                    memberAttribute.setHospice(Boolean.TRUE);
                }
            }
        }
   }
}

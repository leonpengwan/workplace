package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.input;


import static java.lang.Math.toIntExact;

public class MemberEvidence implements Comparable<MemberEvidence> {
    private long memberEvidenceId;
    private int memberId;
    private String personId;
    private int practitionerId;
    private int encounterId;
    private String encounterServiceDate;
    private String hcc;
    private double gapConfidenceValue;
    private String gapConfidenceLevel;
    private String gapType;
    private String gapSetId;


    public MemberEvidence() {
        super();
    }

    public MemberEvidence(long memberEvidenceId, int memberId, String personId, int practitionerId, int encounterId, String encounterServiceDate, String hcc, double gapConfidenceValue, String gapConfidenceLevel, String gapType, String gapSetId) {
        this.memberEvidenceId = memberEvidenceId;
        this.memberId = memberId;
        this.personId = personId;
        this.practitionerId = practitionerId;
        this.encounterId = encounterId;
        this.encounterServiceDate = encounterServiceDate;
        this.hcc = hcc;
        this.gapConfidenceValue = gapConfidenceValue;
        this.gapConfidenceLevel = gapConfidenceLevel;
        this.gapType = gapType;
        this.gapSetId = gapSetId;
    }

    public long getMemberEvidenceId() {
        return memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public int getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(int practitionerId) {
        this.practitionerId = practitionerId;
    }

    public int getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(int encounterId) {
        this.encounterId = encounterId;
    }

    public String getEncounterServiceDate() {
        return encounterServiceDate;
    }

    public void setEncounterServiceDate(String encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    public String getHcc() {
        return hcc;
    }

    public void setHcc(String hcc) {
        this.hcc = hcc;
    }

    public double getGapConfidenceValue() {
        return gapConfidenceValue;
    }

    public void setGapConfidenceValue(double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    public String getGapConfidenceLevel() {
        return gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    public String getGapType() {
        return gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    @Override
    public int compareTo(MemberEvidence memberEvidence){
        long compareMemberEvidenceId = ((MemberEvidence) memberEvidence).getMemberEvidenceId();

        return toIntExact(this.memberEvidenceId - compareMemberEvidenceId);
    }

    public String getGapSetId() {
        return gapSetId;
    }

    public void setGapSetId(String gapSetId) {
        this.gapSetId = gapSetId;
    }
}

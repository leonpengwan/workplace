package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util;

import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class EnrollmentComparator implements Comparator<Enrollment> {

    private List<Comparator<Enrollment>> listComparators;


    public EnrollmentComparator(Comparator<Enrollment>... comparators){
        this.listComparators = Arrays.asList(comparators);
    }


    @Override
    public int compare(Enrollment enrollment1, Enrollment enrollment2) {
        for (Comparator<Enrollment> comparator : listComparators) {
            int result = comparator.compare(enrollment1, enrollment2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
}

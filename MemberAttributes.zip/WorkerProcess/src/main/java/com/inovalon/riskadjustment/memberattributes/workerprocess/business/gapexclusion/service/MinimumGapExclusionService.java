package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Hcc;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("MinimumGapConfidenceLevel")
public class MinimumGapExclusionService implements GapExclusionService {
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will exclude the gaps based on the minimumConfidenceLevel of
     * user selections in gapDetails UI page.
     *
     * @param cacheUtil
     * @param memberEvidenceStatuses
     * @param runProfile
     */
    @LogBeforeEvents
    @Override
    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatuses, CacheUtil cacheUtil, MemberAttribute memberAttribute) {

        //public void updateMinimumConfidenceLevelExclusion(CacheUtil cacheUtil ,List <MemberEvidenceStatus> memberEvidenceStatuses , RunProfile runProfile) {

        try {
            Map<String, Integer> confidenceMap = cacheUtil.getGapConfidenceLevels();
            logWriter.info("gapConfidenceLevels.size" + confidenceMap.size());
            ExclusionTypeModel exclusionTypeModel = cacheUtil.getExclusionTypeModelMap()
                    .get(GapExclusionConstants.HCC_MINIMUM_GAP_CONFIDENCE_LEVEL);

            logWriter.info("runProfile.getSections().getMinimumGapConfidenceValue().getHccs()");
            System.out.println(runProfile.getSections().getMinimumGapConfidenceValue().getHccs().size());

            for (Hcc hcc : runProfile.getSections().getMinimumGapConfidenceValue().getHccs()) {

                int userSelectedConfidenceLevel = confidenceMap.get(hcc.getConfidenceLevel());
                for (MemberEvidenceStatus memberEvidenceStatus : memberEvidenceStatuses) {
                    if (memberEvidenceStatus.getExclusionId() != 0) continue;
                    if (confidenceMap.get(memberEvidenceStatus.getGapConfidenceLevel()) != null) {
                        int memberConfidenceLevel = confidenceMap.get(memberEvidenceStatus.getGapConfidenceLevel());
                        if (hcc.getCode() != null
                                && (hcc.getCode().equalsIgnoreCase(memberEvidenceStatus.getHccCode()))) {
                            if (userSelectedConfidenceLevel == 0
                                    || memberConfidenceLevel < userSelectedConfidenceLevel) {
                                memberEvidenceStatus.setExclusionId(exclusionTypeModel.getExclusionId());
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            logWriter.error("Exception while processing HCC Minimum Gap Confidence Level!"+e.getMessage());

        }
    }

}
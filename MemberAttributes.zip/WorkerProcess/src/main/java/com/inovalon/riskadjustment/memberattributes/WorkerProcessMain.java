package com.inovalon.riskadjustment.memberattributes;


import com.inovalon.riskadjustment.memberattributes.workerprocess.configuration.WorkerProcessConfiguration;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.WorkerProcessMessage;
import com.inovalon.riskadjustment.shared.messagebus.common.Utilities;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.redisson.codec.SerializationCodec;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan("com.inovalon.riskadjustment")
public class WorkerProcessMain {

    @Autowired
    private WorkerProcessConfiguration workerProcessConfiguration;
     public static void main(String[] args) {
        SpringApplication.run ( WorkerProcessMain.class , args );

        //System.out.println(Utilities.getAvroSchema(new WorkerProcessMessage()));
    }

    @PostConstruct
    private void initialize() {

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++++++ SERVICE STARTED  ++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("workerProcessConfiguration: " + workerProcessConfiguration.toString() );
    }
}

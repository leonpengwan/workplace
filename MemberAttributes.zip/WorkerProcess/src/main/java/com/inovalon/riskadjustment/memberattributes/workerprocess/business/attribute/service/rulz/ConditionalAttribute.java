package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("ConditionalAttribute")
public class ConditionalAttribute implements MemberProfileRealization {
    /**
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @Override
    public void applyRules(RunProfile runProfile, CustomizedStagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {

        memberAttribute.setConditional(false);


    }
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util;

import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;

import java.util.Comparator;

public class EnrollmentIdComparator implements Comparator<Enrollment> {
    @Override
    public int compare(Enrollment enrollment1, Enrollment enrollment2) {

        long memberEnrollmentID1 = Long.valueOf(enrollment1.getMemberEnrollmentId());
        long memberEnrollmentID2 = Long.valueOf(enrollment2.getMemberEnrollmentId());
        //descending order
        return Math.toIntExact(memberEnrollmentID2 - memberEnrollmentID1);
    }
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

import java.util.List;

public class ProviderProfile {


    private String clientProviderId;
    private String providerId;
    private List<Name> name;
    private List<Address> address;

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public List<Name> getName() {
        return name;
    }

    public void setName(List<Name> name) {
        this.name = name;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }
}

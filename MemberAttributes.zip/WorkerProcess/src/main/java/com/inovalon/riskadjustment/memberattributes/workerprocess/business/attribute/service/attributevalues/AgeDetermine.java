package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

@Service("AgeDetermine")
public class AgeDetermine implements MemberAttributeIdentification {
    @Autowired
    private LogWriter logWriter;

    /**
     * It is used to determine the Age and gender of patient
     * @param runProfile
     * @param patientProfile
     * @param memberAttribute
     * @param cacheUtil
     * @throws RangException
     */
    @LogBeforeEvents
    @Override
    public void setAttributeValue(RunProfile runProfile, PatientProfile patientProfile, MemberAttribute memberAttribute, CacheUtil cacheUtil) throws RangException {
        logWriter.info("Beginning of AgeDetermine");
        try {
            if (patientProfile.getBirthDate()!=null) {
                Date dob = patientProfile.getBirthDate();
                if (null != memberAttribute.getPlanningMonthStartDate()) {
                    LocalDate planningDate = runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod().getStart().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    LocalDate birthdate = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                    int years = Period.between(birthdate, planningDate).getYears();
                    memberAttribute.setAge(years);
                }
                memberAttribute.setGender(patientProfile.getGenderCode());
            }
            logWriter.info("Ending of AgeDetermine");
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
            throw new RangException(ex);
        }
    }
}

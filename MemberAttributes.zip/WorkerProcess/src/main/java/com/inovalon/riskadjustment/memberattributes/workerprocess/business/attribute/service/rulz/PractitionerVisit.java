package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Claim;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.LookBackPeriod;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service("PractitionerVisit")
public class PractitionerVisit implements MemberProfileRealization {


    private static final String PCP_VISIT="pcpVisit";
    /**
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @Override
    public void applyRules(RunProfile runProfile, CustomizedStagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();
        if (!CollectionUtils.isEmpty(patientProfile.getClaims())) {
            List<LookBackPeriod> lookBackPeriods = runProfile.getSections().getSectionLookBackPeriod().getCommonCriteriaLookBackPeriods();
            LookBackPeriod lookBkPeriod = lookBackPeriods.stream().filter( lookBackPeriod -> lookBackPeriod.getName().equalsIgnoreCase(PCP_VISIT)).findAny().orElse(null);
            Date pastDate = getYear(memberAttribute,lookBkPeriod.getDurationInMonth());
            List<Claim> claims = patientProfile.getClaims();
            Claim resultedClaim = claims.stream().filter(claim -> (claim.getClientProviderId() != null && (claim.getAdmissionDate().before(memberAttribute.getPlanningMonthStartDate()) && claim.getAdmissionDate().after(pastDate)))).findAny().orElse(null);
            if (!Objects.isNull(resultedClaim))
                memberAttribute.setPcpVisit(true);
        }
    }

    private Date getYear(MemberAttribute memberAttribute, int period) {
        int monthsPeriod = 0;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(memberAttribute.getPlanningMonthStartDate());

        int planningMonth = calendar.get(Calendar.MONTH);
        int planningYear = calendar.get(Calendar.YEAR);
        int planningDate = 0;
        int year = period / 12;
        year = planningYear - year;
        int month = period % 12;
        if (month == 0) {
            month = planningMonth;
        } else if (month > planningMonth) {
            month = 12 - (month - planningMonth);
        } else {
            month = planningMonth - month;
        }


        calendar.set(year, month, planningDate);
        return calendar.getTime();
    }

}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.util.ValidationUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@Component
public class MemberValidationService {

    /**
     * It validates PatientProfile and returns MemberValidation
     * @param patientProfile
     * @param memberAttributesRunId
     * @return It returns validation result of PatientProfile as MemberValidation
     */
    @LogBeforeEvents
    @LogAfterEvents
    public MemberValidation validateMember(PatientProfile patientProfile, int memberAttributesRunId){

        MemberValidation memberValidation = new MemberValidation();

        memberValidation.setMemberId(patientProfile.getMemberId());
        boolean isValidAddress = ValidationUtil.validateAddress(patientProfile.getAddressLine1(),
                patientProfile.getAddressLine2(), patientProfile.getCity(),
                patientProfile.getStateCode(), patientProfile.getZip());
        boolean isValidPhoneNumber = ValidationUtil.validatePhoneOrFaxNumber(patientProfile.getPhoneNumber());
        memberValidation.setInValidAddress(!isValidAddress);
        memberValidation.setInValidPhone(!isValidPhoneNumber);
        memberValidation.setMemberId(patientProfile.getMemberId());
        memberValidation.setPersonId(String.valueOf(patientProfile.getMemberId()));
        //memberValidation.setMemberValidationId();
        memberValidation.setMemberAttributesRunId(memberAttributesRunId);
        return memberValidation;
    }


}

package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

public class InterventionPlan {

    private long interventionPlanId;
    private int interventionPlanRunId;
    private int memberId;
    private String personId;
    private Integer interventionYear;
    private String interventionPlanDetail;

    public long getInterventionPlanId() {
        return interventionPlanId;
    }

    public void setInterventionPlanId(long interventionPlanId) {
        this.interventionPlanId = interventionPlanId;
    }

    public int getInterventionPlanRunId() {
        return interventionPlanRunId;
    }

    public void setInterventionPlanRunId(int interventionPlanRunId) {
        this.interventionPlanRunId = interventionPlanRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public Integer getInterventionYear() {
        return interventionYear;
    }

    public void setInterventionYear(Integer interventionYear) {
        this.interventionYear = interventionYear;
    }

    public String getInterventionPlanDetail() {
        return interventionPlanDetail;
    }

    public void setInterventionPlanDetail(String interventionPlanDetail) {
        this.interventionPlanDetail = interventionPlanDetail;
    }
}

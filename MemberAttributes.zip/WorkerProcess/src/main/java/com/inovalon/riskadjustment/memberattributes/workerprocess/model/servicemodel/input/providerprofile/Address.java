package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.input.providerprofile;

public class Address {

    private String providerId;

    private String addressType;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String state;

    private String zip;

    private String phone;

    private String addressActivationDate;

    private String addressRetirementDate;

    private String locationKey;

    private String phoneNumber2;

    private String faxNumber1;

    public Address() {

    }

    public Address(String providerId, String addressType, String addressLine1, String addressLine2, String city, String state, String zip, String phone, String addressActivationDate, String addressRetirementDate, String locationKey, String phoneNumber2, String faxNumber1) {
        this.providerId = providerId;
        this.addressType = addressType;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.phone = phone;
        this.addressActivationDate = addressActivationDate;
        this.addressRetirementDate = addressRetirementDate;
        this.locationKey = locationKey;
        this.phoneNumber2 = phoneNumber2;
        this.faxNumber1 = faxNumber1;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddressActivationDate() {
        return addressActivationDate;
    }

    public void setAddressActivationDate(String addressActivationDate) {
        this.addressActivationDate = addressActivationDate;
    }

    public String getAddressRetirementDate() {
        return addressRetirementDate;
    }

    public void setAddressRetirementDate(String addressRetirementDate) {
        this.addressRetirementDate = addressRetirementDate;
    }

    public String getLocationKey() {
        return locationKey;
    }

    public void setLocationKey(String locationKey) {
        this.locationKey = locationKey;
    }

    public String getPhoneNumber2() {
        return phoneNumber2;
    }

    public void setPhoneNumber2(String phoneNumber2) {
        this.phoneNumber2 = phoneNumber2;
    }

    public String getFaxNumber1() {
        return faxNumber1;
    }

    public void setFaxNumber1(String faxNumber1) {
        this.faxNumber1 = faxNumber1;
    }
}






package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.util;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class ValidationUtil {

    /**
     * It validates address
     * @param address1
     * @param address2
     * @param city
     * @param state
     * @param zip
     * @return It returns true is address is valid
     */
    @LogAfterEvents
    public static boolean validateAddress(String address1, String address2, String city, String state, String zip) {
        List<String> inValidAdresses = new ArrayList<String>();
        inValidAdresses.add("homeless");
        inValidAdresses.add("unknown");
        if (StringUtils.isEmpty(city) || StringUtils.isEmpty(state) || StringUtils.isEmpty(zip)||
                (StringUtils.isEmpty(address1) && StringUtils.isEmpty(address2))) {
            return false;
        } else if (inValidAdresses.contains(address1) || inValidAdresses.contains(address2)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * It validates PhoneOrFaxNumber is valid or not.
     * @param number
     * @return It returns true is PhoneOrFaxNumber is valid
     */
    @LogAfterEvents
    public static boolean validatePhoneOrFaxNumber(String number) {
        if (StringUtils.isEmpty(number)) {
            return false;
        }
        //if phone number is 888-955-2101 or 888 203 9218A,9551245628 or 0551245628 is in the format
        String finalNumber = number.replaceAll("[^\\d]", "");
        if (finalNumber.length() < 10 || (finalNumber.length() == 10 && finalNumber.startsWith("0"))) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * It validates First and last name
     * @param firstName
     * @param lastName
     * @return It returns true is First and Last names are valid
     */
    @LogAfterEvents
    public static boolean validatePcpName(String firstName, String lastName) {
        if (StringUtils.isEmpty(firstName) && StringUtils.isEmpty(lastName)) {
            return false;
        } else {
            return true;
        }

    }


}

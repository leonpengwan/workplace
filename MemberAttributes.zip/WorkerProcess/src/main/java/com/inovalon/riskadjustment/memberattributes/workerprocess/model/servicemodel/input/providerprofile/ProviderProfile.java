package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.input.providerprofile;

import java.util.List;

public class ProviderProfile {

    private List<Address> address;

    private List<AlternateIds> altIds;

    private String clientProviderId;

    private int feedInstanceId;

    private List<Name> name;

    private String npi;

    private String providerId;

    private String udfActiveInd;

    public ProviderProfile() {

    }

    public ProviderProfile(List<Address> address, List<AlternateIds> altIds, String clientProviderId, int feedInstanceId, List<Name> name, String npi, String providerId, String udfActiveInd) {
        this.address = address;
        this.altIds = altIds;
        this.clientProviderId = clientProviderId;
        this.feedInstanceId = feedInstanceId;
        this.name = name;
        this.npi = npi;
        this.providerId = providerId;
        this.udfActiveInd = udfActiveInd;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public List<AlternateIds> getAltIds() {
        return altIds;
    }

    public void setAltIds(List<AlternateIds> altIds) {
        this.altIds = altIds;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }

    public int getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(int feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public List<Name> getName() {
        return name;
    }

    public void setName(List<Name> name) {
        this.name = name;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(String udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }
}

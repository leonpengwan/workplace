package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public interface MemberProfileRealizationFactory {

    public MemberProfileRealization getMemberProfileRealization(String memberProfileRealization);

}

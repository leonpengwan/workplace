package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccCodeHierarchy;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service("HCCHierarchyExclusion")
public class HCCHierarchyExclusionService implements GapExclusionService {
    @Autowired
    private LogWriter logWriter;

    /*
     * This method exludes the gaps by their hierarchy and adds the excluded
     * gaps to the existing exclusion list HCCHierarchy Exclusion logic 1.
     * Compare Hcc list from MemberEvidence and existing
     * gapExclusion/memberEvidenceStatus list and retain only Hccs that are not
     * excluded for this logic 2. Compare this Hcc list with Hierarchy list by
     * Hcc Code and AgeGroupId 3. If the Hcc is present in the Hierarchy, add
     * the corresponding Drop hcc to the exclusion list by updating the
     * exclusionId 4. Do this for all the Hccs in the memberEvidence data set
     * for a given GapSetDetailId
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatuses, CacheUtil cacheUtil, MemberAttribute memberAttribute) {

        logWriter.info("Begin processing the Hcc Hierarchy exclusions...");
        Set<String> HCCCodes = new HashSet<>();

        try {
            // Create a list of Hccs from MemberEvidence and exclude the Hccs
            // that are already excluded
            for (MemberEvidenceStatus memberEvidenceStatus : memberEvidenceStatuses) {
                {
                    HCCCodes.add(memberEvidenceStatus.getHccCode());
                    System.out.println("Distinct MemberEvidence Hccs: " + HCCCodes);
                }
            }
            // Get the exclusion id
            ExclusionTypeModel exclusionType = cacheUtil.getExclusionTypeModelMap()
                    .get(GapExclusionConstants.HCC_HIERARCHY);
            List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies = cacheUtil.getHhsHccCodeHierarchies();
            // exclusionTypeModel.stream().filter((o) ->
            // o.getName().equals(GapExclusionConstants.HCC_HIERARCHY)).findFirst().orElseGet(()
            // -> new ExclusionTypeModel());

            logWriter.info("Processing Hcc Hierarchy exclusion logic...");
            logWriter.info("hhsHccCodeHierarchies size: " + hhsHccCodeHierarchies.size());
            // If the lookup data is not null and has records
            for (String memberEvidenceHcc : HCCCodes) {

                if (hhsHccCodeHierarchies != null && hhsHccCodeHierarchies.size() > 0) {
                    for (MemberEvidenceStatus memberevidenceStatus : memberEvidenceStatuses) {

                        if (memberevidenceStatus.getExclusionId() == 0) {
                            // Filter the Hcc Hierarchy list by HccCode and
                            // AgeGroupId based on member's age
                            List<ModelHhsHccCodeHierarchy> modelHhsHccCodeHierarchiesByHccCode = hhsHccCodeHierarchies
                                    .stream().filter(o -> o.getHccCode().equals(memberEvidenceHcc.toString())
                                            && o.getAgeGroupId() == memberAttribute.getAgeGroupId())
                                    .collect(Collectors.toList());

                            for (ModelHhsHccCodeHierarchy modelHhsHccCodeHierarchyByHccCode : modelHhsHccCodeHierarchiesByHccCode) {
                                if (modelHhsHccCodeHierarchyByHccCode.getHccCodeToDrop()
                                        .equals(memberevidenceStatus.getHccCode())) {
                                    memberevidenceStatus.setExclusionId(exclusionType.getExclusionId());
                                }
                            }
                        }
                    }
                }
            }
            logWriter.info("memberEvidenceStatuses size: " + memberEvidenceStatuses.size());

            logWriter.info("Completed Hcc Hierarchy Exclusion logic...");

        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }
    }

}
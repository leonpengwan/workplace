package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.LookBackPeriod;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service("PreviousIntervention")
public class PreviousIntervention implements MemberProfileRealization {

    /**
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @Override
    public void applyRules(RunProfile runProfile, CustomizedStagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        List<InterventionPlan> interventionPlanList = customizedStagingMessage.getInterventionPlans();
        if (CollectionUtils.isEmpty(interventionPlanList)) {
            memberAttribute.setNoPreviousIntervention(true);
        }


    }
}

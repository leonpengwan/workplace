package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.input.patientprofile;


import avro.shaded.com.google.common.base.Objects;

import java.util.List;

public class LabClaim {

    private String source;
    private String procedureCodeQualifier;
    private int labClaimId;
    private String clientMemberId;
    private String orderingOrderNumber;
    private String orderingRequestDate;
    private String observationResultStatusCode;
    private String supplementalSourceCode;
    private String clientProviderId;
    private String observationResultValue;
    private String observationCode;
    private String result;
    private String posNegResult;
    private String loinc;
    private String snomed;
    private int feedInstanceId;
    private int udfActiveInd;
    private List<String> cptCodes;
    private List<String> hcpcsCodes;
    private List<String> hcpcsModCodes;
    private List<String> labClaimAltIds;

    public LabClaim() {
    }

    public LabClaim(String source, String procedureCodeQualifier, int labClaimId, String clientMemberId, String orderingOrderNumber, String orderingRequestDate, String observationResultStatusCode, String supplementalSourceCode, String clientProviderId, String observationResultValue, String observationCode, String result, String posNegResult, String loinc, String snomed, int feedInstanceId, int udfActiveInd, List<String> cptCodes, List<String> hcpcsCodes, List<String> hcpcsModCodes, List<String> labClaimAltIds) {
        this.source = source;
        this.procedureCodeQualifier = procedureCodeQualifier;
        this.labClaimId = labClaimId;
        this.clientMemberId = clientMemberId;
        this.orderingOrderNumber = orderingOrderNumber;
        this.orderingRequestDate = orderingRequestDate;
        this.observationResultStatusCode = observationResultStatusCode;
        this.supplementalSourceCode = supplementalSourceCode;
        this.clientProviderId = clientProviderId;
        this.observationResultValue = observationResultValue;
        this.observationCode = observationCode;
        this.result = result;
        this.posNegResult = posNegResult;
        this.loinc = loinc;
        this.snomed = snomed;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.cptCodes = cptCodes;
        this.hcpcsCodes = hcpcsCodes;
        this.hcpcsModCodes = hcpcsModCodes;
        this.labClaimAltIds = labClaimAltIds;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getProcedureCodeQualifier() {
        return procedureCodeQualifier;
    }

    public void setProcedureCodeQualifier(String procedureCodeQualifier) {
        this.procedureCodeQualifier = procedureCodeQualifier;
    }

//    public LabClaimIdObject getLabClaimId() {
//        return labClaimId;
//    }
//
//    public void setLabClaimId(LabClaimIdObject labClaimId) {
//        this.labClaimId = labClaimId;
//    }

    public int getLabClaimId() {
        return labClaimId;
    }

    public void setLabClaimId(int labClaimId) {
        this.labClaimId = labClaimId;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getOrderingOrderNumber() {
        return orderingOrderNumber;
    }

    public void setOrderingOrderNumber(String orderingOrderNumber) {
        this.orderingOrderNumber = orderingOrderNumber;
    }

    public String getOrderingRequestDate() {
        return orderingRequestDate;
    }

    public void setOrderingRequestDate(String orderingRequestDate) {
        this.orderingRequestDate = orderingRequestDate;
    }

    public String getObservationResultStatusCode() {
        return observationResultStatusCode;
    }

    public void setObservationResultStatusCode(String observationResultStatusCode) {
        this.observationResultStatusCode = observationResultStatusCode;
    }

    public String getSupplementalSourceCode() {
        return supplementalSourceCode;
    }

    public void setSupplementalSourceCode(String supplementalSourceCode) {
        this.supplementalSourceCode = supplementalSourceCode;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }

    public String getObservationResultValue() {
        return observationResultValue;
    }

    public void setObservationResultValue(String observationResultValue) {
        this.observationResultValue = observationResultValue;
    }

    public String getObservationCode() {
        return observationCode;
    }

    public void setObservationCode(String observationCode) {
        this.observationCode = observationCode;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getPosNegResult() {
        return posNegResult;
    }

    public void setPosNegResult(String posNegResult) {
        this.posNegResult = posNegResult;
    }

    public String getLoinc() {
        return loinc;
    }

    public void setLoinc(String loinc) {
        this.loinc = loinc;
    }

    public String getSnomed() {
        return snomed;
    }

    public void setSnomed(String snomed) {
        this.snomed = snomed;
    }

    public int getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(int feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public int getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(int udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    public List<String> getCptCodes() {
        return cptCodes;
    }

    public void setCptCodes(List<String> cptCodes) {
        this.cptCodes = cptCodes;
    }

    public List<String> getHcpcsCodes() {
        return hcpcsCodes;
    }

    public void setHcpcsCodes(List<String> hcpcsCodes) {
        this.hcpcsCodes = hcpcsCodes;
    }

    public List<String> getHcpcsModCodes() {
        return hcpcsModCodes;
    }

    public void setHcpcsModCodes(List<String> hcpcsModCodes) {
        this.hcpcsModCodes = hcpcsModCodes;
    }

    public List<String> getLabClaimAltIds() {
        return labClaimAltIds;
    }

    public void setLabClaimAltIds(List<String> labClaimAltIds) {
        this.labClaimAltIds = labClaimAltIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LabClaim labClaim = (LabClaim) o;
        return procedureCodeQualifier == labClaim.procedureCodeQualifier &&
                labClaimId == labClaim.labClaimId &&
                Objects.equal(source, labClaim.source) &&
                Objects.equal(clientMemberId, labClaim.clientMemberId) &&
                Objects.equal(orderingOrderNumber, labClaim.orderingOrderNumber) &&
                Objects.equal(orderingRequestDate, labClaim.orderingRequestDate) &&
                Objects.equal(observationResultStatusCode, labClaim.observationResultStatusCode) &&
                Objects.equal(supplementalSourceCode, labClaim.supplementalSourceCode) &&
                Objects.equal(clientProviderId, labClaim.clientProviderId) &&
                Objects.equal(observationResultValue, labClaim.observationResultValue) &&
                Objects.equal(observationCode, labClaim.observationCode) &&
                Objects.equal(result, labClaim.result) &&
                Objects.equal(posNegResult, labClaim.posNegResult) &&
                Objects.equal(loinc, labClaim.loinc) &&
                Objects.equal(snomed, labClaim.snomed) &&
                Objects.equal(feedInstanceId, labClaim.feedInstanceId) &&
                Objects.equal(udfActiveInd, labClaim.udfActiveInd) &&
                Objects.equal(cptCodes, labClaim.cptCodes) &&
                Objects.equal(hcpcsCodes, labClaim.hcpcsCodes) &&
                Objects.equal(hcpcsModCodes, labClaim.hcpcsModCodes) &&
                Objects.equal(labClaimAltIds, labClaim.labClaimAltIds);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(source, procedureCodeQualifier, labClaimId, clientMemberId, orderingOrderNumber, orderingRequestDate, observationResultStatusCode, supplementalSourceCode, clientProviderId, observationResultValue, observationCode, result, posNegResult, loinc, snomed, feedInstanceId, udfActiveInd, cptCodes, hcpcsCodes, hcpcsModCodes, labClaimAltIds);
    }

    @Override
    public String toString() {
        return "LabClaimDTO{" +
                "source='" + source + '\'' +
                ", procedureCodeQualifier=" + procedureCodeQualifier +
                ", labClaimId=" + labClaimId +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", orderingOrderNumber='" + orderingOrderNumber + '\'' +
                ", orderingRequestDate='" + orderingRequestDate + '\'' +
                ", observationResultStatusCode='" + observationResultStatusCode + '\'' +
                ", supplementalSourceCode='" + supplementalSourceCode + '\'' +
                ", clientProviderId='" + clientProviderId + '\'' +
                ", observationResultValue='" + observationResultValue + '\'' +
                ", observationCode='" + observationCode + '\'' +
                ", result='" + result + '\'' +
                ", posNegResult='" + posNegResult + '\'' +
                ", loinc='" + loinc + '\'' +
                ", snomed='" + snomed + '\'' +
                ", feedInstanceId='" + feedInstanceId + '\'' +
                ", udfActiveInd='" + udfActiveInd + '\'' +
                ", cptCodes=" + cptCodes +
                ", hcpcsCodes=" + hcpcsCodes +
                ", hcpcsModCodes=" + hcpcsModCodes +
                ", labClaimAltIds=" + labClaimAltIds +
                '}';
    }
}

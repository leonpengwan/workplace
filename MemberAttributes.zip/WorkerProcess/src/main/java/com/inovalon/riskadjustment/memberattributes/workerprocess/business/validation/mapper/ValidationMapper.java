package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.mapper;

import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.MemberValidationAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.PractitionerValidationAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PractitionerValidation;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface ValidationMapper {

    ValidationMapper INSTANCE = Mappers.getMapper(ValidationMapper.class);

    MemberValidationAvro memberValidationToMemberValidationAvro(MemberValidation memberValidation);
    PractitionerValidationAvro practitionerValidationToPractitionerValidationAvro(PractitionerValidation practitionerValidation);
}

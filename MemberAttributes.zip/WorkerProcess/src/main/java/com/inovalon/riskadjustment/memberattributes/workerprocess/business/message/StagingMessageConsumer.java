package com.inovalon.riskadjustment.memberattributes.workerprocess.business.message;


import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.WorkFlowManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.input.StagingMessageAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.util.AvroToModelConverter;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import com.inovalon.riskadjustment.shared.messagebus.consumer.KafkaMessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.enums.MessageAcknowledgment;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.model.MessageMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class StagingMessageConsumer implements MessageBusListener<StagingMessageAvro> {

    @Autowired
    private KafkaMessageBusListener<StagingMessageAvro> kafkaMessageBusListener;

    @Autowired
    private WorkFlowManager workFlowManager;

    @Autowired
    private WorkerProcessMessageProducer workerProcessMessageProducer;
    @Autowired
    private LogWriter logWriter;

    @PostConstruct
    public void Initialize() {
        kafkaMessageBusListener.subscribe(this, StagingMessageAvro.class);
    }
    @LogBeforeEvents
    @Override
    public MessageAcknowledgment OnQueueMessageReceived(StagingMessageAvro stagingMessageAvro, MessageMetadata messageMetadata) {
        logWriter.info("Received message : " + stagingMessageAvro);

        if (stagingMessageAvro != null) {
            try {
                CustomizedStagingMessage stagingMessage = AvroToModelConverter.avroToModel(stagingMessageAvro);
                WorkerProcessMessageAvro workerProcessMessageAvro = workFlowManager.workFlowController(stagingMessage);
                workerProcessMessageProducer.produceWorkerProcessMessage(workerProcessMessageAvro);
                return MessageAcknowledgment.Commit;
            } catch (Exception ex) {
                ex.printStackTrace();
                logWriter.info("MemberAttributesWorkerProcess: kafka queue consuemer exception--" + ex.getMessage());
                createFailureMessage(stagingMessageAvro);
                return MessageAcknowledgment.DoNotCommit;
            }
        } else {
            logWriter.info("MemberAttributesWorkerProcess: kafka queue consumed an null avro message");
        }
        return MessageAcknowledgment.Unknown;
    }

    private void createFailureMessage(StagingMessageAvro stagingMessageAvro) {
    }



}

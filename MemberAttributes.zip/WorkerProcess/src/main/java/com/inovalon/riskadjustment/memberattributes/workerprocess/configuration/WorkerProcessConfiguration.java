package com.inovalon.riskadjustment.memberattributes.workerprocess.configuration;


import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.MemberAttributeIdentificationFactory;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.MemberProfileRealizationFactory;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.avro.output.WorkerProcessMessageAvro;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import com.inovalon.riskadjustment.shared.messagebus.producer.KafkaMessageBusPublisher;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.redisson.codec.SerializationCodec;
import org.redisson.config.Config;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ServiceLocatorFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.cloud.context.config.annotation.RefreshScope;

@Configuration
@RefreshScope
public class WorkerProcessConfiguration {

   private Codec codec  = new SerializationCodec();

    @Value("${spring.kafka.producer.topic}")
    private String kafkaProducerTopic;
    @Value("${spring.kafka.consumer.topic}")
    private String kafkaConsumerTopic;

    public String getKafkaProducerTopic() {
        return kafkaProducerTopic;
    }

    @Bean
    public MessageBusPublisher<WorkerProcessMessageAvro> messageBusPublisher(){
        return new KafkaMessageBusPublisher<>(WorkerProcessMessageAvro.class);
    }

    @Bean
    public FactoryBean rulesLocatorFactoryBean() {
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(MemberProfileRealizationFactory.class);
        return factoryBean;
    }

    @Bean
    public FactoryBean attributeLocatorFactoryBean() {
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(MemberAttributeIdentificationFactory.class);
        return factoryBean;
    }

    @Override
    public String toString() {
        return "WorkerProcessConfiguration{" +
                "kafkaProducerTopic='" + kafkaProducerTopic + '\'' +
                ", kafkaConsumerTopic='" + kafkaConsumerTopic + '\'' +
                '}';
    }
}

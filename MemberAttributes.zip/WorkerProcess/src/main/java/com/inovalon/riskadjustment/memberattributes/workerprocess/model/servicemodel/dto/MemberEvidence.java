package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;

import java.util.Date;

public class MemberEvidence {

    private long memberEvidenceId;
    private Integer memberId;
    private String personId;
    private Integer practitionerId;
    private Integer encounterId;
    private Date encounterServiceDate;
    private String hcc;
    private Double gapConfidenceValue;
    private String gapConfidenceLevel;
    private String gapType;
    private String gapSetId;
    private String measureKey;
    private int saGapValue;

    public long getMemberEvidenceId() {
        return memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public Integer getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(Integer practitionerId) {
        this.practitionerId = practitionerId;
    }

    public Integer getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(Integer encounterId) {
        this.encounterId = encounterId;
    }

    public Date getEncounterServiceDate() {
        return encounterServiceDate;
    }

    public void setEncounterServiceDate(Date encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    public String getHcc() {
        return hcc;
    }

    public void setHcc(String hcc) {
        this.hcc = hcc;
    }

    public Double getGapConfidenceValue() {
        return gapConfidenceValue;
    }

    public void setGapConfidenceValue(Double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    public String getGapConfidenceLevel() {
        return gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    public String getGapType() {
        return gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    public String getGapSetId() {
        return gapSetId;
    }

    public void setGapSetId(String gapSetId) {
        this.gapSetId = gapSetId;
    }

    public String getMeasureKey() {
        return measureKey;
    }

    public void setMeasureKey(String measureKey) {
        this.measureKey = measureKey;
    }

    public int getSaGapValue() {
        return saGapValue;
    }

    public void setSaGapValue(int saGapValue) {
        this.saGapValue = saGapValue;
    }
}

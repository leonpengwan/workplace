package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.input.patientprofile;

import java.util.List;

public class Claim {

    private int claimId;
    private String payerClaimControlNumber;
    private String cost;
    private String admissionDate;
    private String dischargeDate;
    private String supplementalSourceCode;
    private String patientStatusCode;
    private String claimStatusCode;
    private String deniedDayOrVisitCount;
    private String roomBoardInd;
    private String majorSurgeryInd;
    private String serviceUnitCount;
    private String excludeFromDischargeInd;
    private String pcpInd;
    private String clientProviderId;
    private String clientMemberId;
    private String presentOnAdmission;
    private int feedInstanceId;
    private int udfActiveInd;
    private String billed;
    private String copay;
    private String providerRxEligInd;
    private List<List<String>> icddxCodes;
    private List<List<String>> icdpxCodes;
    private List<List<String>> icddx10Codes;
    private List<List<String>> icdpx10codes;
    private List<String> cptpxCodes;
    private List<String> hcpcspxCodes;
    private List<String> providerSpecialty;
    private List<String> tob;
    private List<List<String>> hpx;
    private List<String> drgCodes;
    private List<String> msdrgCodes;
    private List<String> apdrgCodes;
    private List<String> aprdrgCodes;
    private List<String> claimAltIds;
    private List<String> cptModCodes;
    private List<String> hcfaposCodes;
    private List<String> hcpcsModCodes;
    private List<String> providerTypeCodes;
    private List<String> ubRevenueCodes;
    private List<String> cvx;

    public Claim(){}

    public Claim(int claimId, String payerClaimControlNumber, String cost, String admissionDate, String dischargeDate, String supplementalSourceCode, String patientStatusCode, String claimStatusCode, String deniedDayOrVisitCount, String roomBoardInd, String majorSurgeryInd, String serviceUnitCount, String excludeFromDischargeInd, String pcpInd, String clientProviderId, String clientMemberId, String presentOnAdmission, int feedInstanceId, int udfActiveInd, String billed, String copay, String providerRxEligInd, List<List<String>> icddxCodes, List<List<String>> icdpxCodes, List<List<String>> icddx10Codes, List<List<String>> icdpx10codes, List<String> cptpxCodes, List<String> hcpcspxCodes, List<String> providerSpecialty, List<String> tob, List<List<String>> hpx, List<String> drgCodes, List<String> msdrgCodes, List<String> apdrgCodes, List<String> aprdrgCodes, List<String> claimAltIds, List<String> cptModCodes, List<String> hcfaposCodes, List<String> hcpcsModCodes, List<String> providerTypeCodes, List<String> ubRevenueCodes, List<String> cvx) {
        this.claimId = claimId;
        this.payerClaimControlNumber = payerClaimControlNumber;
        this.cost = cost;
        this.admissionDate = admissionDate;
        this.dischargeDate = dischargeDate;
        this.supplementalSourceCode = supplementalSourceCode;
        this.patientStatusCode = patientStatusCode;
        this.claimStatusCode = claimStatusCode;
        this.deniedDayOrVisitCount = deniedDayOrVisitCount;
        this.roomBoardInd = roomBoardInd;
        this.majorSurgeryInd = majorSurgeryInd;
        this.serviceUnitCount = serviceUnitCount;
        this.excludeFromDischargeInd = excludeFromDischargeInd;
        this.pcpInd = pcpInd;
        this.clientProviderId = clientProviderId;
        this.clientMemberId = clientMemberId;
        this.presentOnAdmission = presentOnAdmission;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.billed = billed;
        this.copay = copay;
        this.providerRxEligInd = providerRxEligInd;
        this.icddxCodes = icddxCodes;
        this.icdpxCodes = icdpxCodes;
        this.icddx10Codes = icddx10Codes;
        this.icdpx10codes = icdpx10codes;
        this.cptpxCodes = cptpxCodes;
        this.hcpcspxCodes = hcpcspxCodes;
        this.providerSpecialty = providerSpecialty;
        this.tob = tob;
        this.hpx = hpx;
        this.drgCodes = drgCodes;
        this.msdrgCodes = msdrgCodes;
        this.apdrgCodes = apdrgCodes;
        this.aprdrgCodes = aprdrgCodes;
        this.claimAltIds = claimAltIds;
        this.cptModCodes = cptModCodes;
        this.hcfaposCodes = hcfaposCodes;
        this.hcpcsModCodes = hcpcsModCodes;
        this.providerTypeCodes = providerTypeCodes;
        this.ubRevenueCodes = ubRevenueCodes;
        this.cvx = cvx;
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public String getPayerClaimControlNumber() {
        return payerClaimControlNumber;
    }

    public void setPayerClaimControlNumber(String payerClaimControlNumber) {
        this.payerClaimControlNumber = payerClaimControlNumber;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        this.admissionDate = admissionDate;
    }

    public String getDischargeDate() {
        return dischargeDate;
    }

    public void setDischargeDate(String dischargeDate) {
        this.dischargeDate = dischargeDate;
    }

    public String getSupplementalSourceCode() {
        return supplementalSourceCode;
    }

    public void setSupplementalSourceCode(String supplementalSourceCode) {
        this.supplementalSourceCode = supplementalSourceCode;
    }

    public String getPatientStatusCode() {
        return patientStatusCode;
    }

    public void setPatientStatusCode(String patientStatusCode) {
        this.patientStatusCode = patientStatusCode;
    }

    public String getClaimStatusCode() {
        return claimStatusCode;
    }

    public void setClaimStatusCode(String claimStatusCode) {
        this.claimStatusCode = claimStatusCode;
    }

    public String getDeniedDayOrVisitCount() {
        return deniedDayOrVisitCount;
    }

    public void setDeniedDayOrVisitCount(String deniedDayOrVisitCount) {
        this.deniedDayOrVisitCount = deniedDayOrVisitCount;
    }

    public String getRoomBoardInd() {
        return roomBoardInd;
    }

    public void setRoomBoardInd(String roomBoardInd) {
        this.roomBoardInd = roomBoardInd;
    }

    public String getMajorSurgeryInd() {
        return majorSurgeryInd;
    }

    public void setMajorSurgeryInd(String majorSurgeryInd) {
        this.majorSurgeryInd = majorSurgeryInd;
    }

    public String getServiceUnitCount() {
        return serviceUnitCount;
    }

    public void setServiceUnitCount(String serviceUnitCount) {
        this.serviceUnitCount = serviceUnitCount;
    }

    public String getExcludeFromDischargeInd() {
        return excludeFromDischargeInd;
    }

    public void setExcludeFromDischargeInd(String excludeFromDischargeInd) {
        this.excludeFromDischargeInd = excludeFromDischargeInd;
    }

    public String getPcpInd() {
        return pcpInd;
    }

    public void setPcpInd(String pcpInd) {
        this.pcpInd = pcpInd;
    }

    public String getClientProviderId() {
        return clientProviderId;
    }

    public void setClientProviderId(String clientProviderId) {
        this.clientProviderId = clientProviderId;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getPresentOnAdmission() {
        return presentOnAdmission;
    }

    public void setPresentOnAdmission(String presentOnAdmission) {
        this.presentOnAdmission = presentOnAdmission;
    }

    public int getFeedInstanceId() {
        return feedInstanceId;
    }

    public void setFeedInstanceId(int feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    public int getUdfActiveInd() {
        return udfActiveInd;
    }

    public void setUdfActiveInd(int udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    public List<List<String>> getIcddxCodes() {
        return icddxCodes;
    }

    public void setIcddxCodes(List<List<String>> icddxCodes) {
        this.icddxCodes = icddxCodes;
    }

    public List<List<String>> getIcdpxCodes() {
        return icdpxCodes;
    }

    public void setIcdpxCodes(List<List<String>> icdpxCodes) {
        this.icdpxCodes = icdpxCodes;
    }

    public List<List<String>> getIcddx10Codes() {
        return icddx10Codes;
    }

    public void setIcddx10Codes(List<List<String>> icddx10Codes) {
        this.icddx10Codes = icddx10Codes;
    }

    public List<List<String>> getIcdpx10codes() {
        return icdpx10codes;
    }

    public void setIcdpx10codes(List<List<String>> icdpx10codes) {
        this.icdpx10codes = icdpx10codes;
    }

    public List<String> getCptpxCodes() {
        return cptpxCodes;
    }

    public void setCptpxCodes(List<String> cptpxCodes) {
        this.cptpxCodes = cptpxCodes;
    }

    public List<String> getHcpcspxCodes() {
        return hcpcspxCodes;
    }

    public void setHcpcspxCodes(List<String> hcpcspxCodes) {
        this.hcpcspxCodes = hcpcspxCodes;
    }

    public List<String> getProviderSpecialty() {
        return providerSpecialty;
    }

    public void setProviderSpecialty(List<String> providerSpecialty) {
        this.providerSpecialty = providerSpecialty;
    }

    public List<String> getTob() {
        return tob;
    }

    public void setTob(List<String> tob) {
        this.tob = tob;
    }

    public List<List<String>> getHpx() {
        return hpx;
    }

    public void setHpx(List<List<String>> hpx) {
        this.hpx = hpx;
    }

    public List<String> getDrgCodes() {
        return drgCodes;
    }

    public void setDrgCodes(List<String> drgCodes) {
        this.drgCodes = drgCodes;
    }

    public List<String> getMsdrgCodes() {
        return msdrgCodes;
    }

    public void setMsdrgCodes(List<String> msdrgCodes) {
        this.msdrgCodes = msdrgCodes;
    }

    public List<String> getApdrgCodes() {
        return apdrgCodes;
    }

    public void setApdrgCodes(List<String> apdrgCodes) {
        this.apdrgCodes = apdrgCodes;
    }

    public List<String> getAprdrgCodes() {
        return aprdrgCodes;
    }

    public void setAprdrgCodes(List<String> aprdrgCodes) {
        this.aprdrgCodes = aprdrgCodes;
    }

    public List<String> getClaimAltIds() {
        return claimAltIds;
    }

    public void setClaimAltIds(List<String> claimAltIds) {
        this.claimAltIds = claimAltIds;
    }

    public List<String> getCptModCodes() {
        return cptModCodes;
    }

    public void setCptModCodes(List<String> cptModCodes) {
        this.cptModCodes = cptModCodes;
    }

    public List<String> getHcfaposCodes() {
        return hcfaposCodes;
    }

    public void setHcfaposCodes(List<String> hcfaposCodes) {
        this.hcfaposCodes = hcfaposCodes;
    }

    public List<String> getHcpcsModCodes() {
        return hcpcsModCodes;
    }

    public void setHcpcsModCodes(List<String> hcpcsModCodes) {
        this.hcpcsModCodes = hcpcsModCodes;
    }

    public List<String> getProviderTypeCodes() {
        return providerTypeCodes;
    }

    public void setProviderTypeCodes(List<String> providerTypeCodes) {
        this.providerTypeCodes = providerTypeCodes;
    }

    public List<String> getUbRevenueCodes() {
        return ubRevenueCodes;
    }

    public void setUbRevenueCodes(List<String> ubRevenueCodes) {
        this.ubRevenueCodes = ubRevenueCodes;
    }

    public String getBilled() {
        return billed;
    }

    public void setBilled(String billed) {
        this.billed = billed;
    }

    public String getCopay() {
        return copay;
    }

    public void setCopay(String copay) {
        this.copay = copay;
    }

    public String getProviderRxEligInd() {
        return providerRxEligInd;
    }

    public void setProviderRxEligInd(String providerRxEligInd) {
        this.providerRxEligInd = providerRxEligInd;
    }

    public List<String> getCvx() {
        return cvx;
    }

    public void setCvx(List<String> cvx) {
        this.cvx = cvx;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Claim claim = (Claim) o;

        if (claimId != claim.claimId) return false;
        if (feedInstanceId != claim.feedInstanceId) return false;
        if (udfActiveInd != claim.udfActiveInd) return false;
        if (payerClaimControlNumber != null ? !payerClaimControlNumber.equals(claim.payerClaimControlNumber) : claim.payerClaimControlNumber != null)
            return false;
        if (cost != null ? !cost.equals(claim.cost) : claim.cost != null) return false;
        if (admissionDate != null ? !admissionDate.equals(claim.admissionDate) : claim.admissionDate != null)
            return false;
        if (dischargeDate != null ? !dischargeDate.equals(claim.dischargeDate) : claim.dischargeDate != null)
            return false;
        if (supplementalSourceCode != null ? !supplementalSourceCode.equals(claim.supplementalSourceCode) : claim.supplementalSourceCode != null)
            return false;
        if (patientStatusCode != null ? !patientStatusCode.equals(claim.patientStatusCode) : claim.patientStatusCode != null)
            return false;
        if (claimStatusCode != null ? !claimStatusCode.equals(claim.claimStatusCode) : claim.claimStatusCode != null)
            return false;
        if (deniedDayOrVisitCount != null ? !deniedDayOrVisitCount.equals(claim.deniedDayOrVisitCount) : claim.deniedDayOrVisitCount != null)
            return false;
        if (roomBoardInd != null ? !roomBoardInd.equals(claim.roomBoardInd) : claim.roomBoardInd != null) return false;
        if (majorSurgeryInd != null ? !majorSurgeryInd.equals(claim.majorSurgeryInd) : claim.majorSurgeryInd != null)
            return false;
        if (serviceUnitCount != null ? !serviceUnitCount.equals(claim.serviceUnitCount) : claim.serviceUnitCount != null)
            return false;
        if (excludeFromDischargeInd != null ? !excludeFromDischargeInd.equals(claim.excludeFromDischargeInd) : claim.excludeFromDischargeInd != null)
            return false;
        if (pcpInd != null ? !pcpInd.equals(claim.pcpInd) : claim.pcpInd != null) return false;
        if (clientProviderId != null ? !clientProviderId.equals(claim.clientProviderId) : claim.clientProviderId != null)
            return false;
        if (clientMemberId != null ? !clientMemberId.equals(claim.clientMemberId) : claim.clientMemberId != null)
            return false;
        if (presentOnAdmission != null ? !presentOnAdmission.equals(claim.presentOnAdmission) : claim.presentOnAdmission != null)
            return false;
        if (billed != null ? !billed.equals(claim.billed) : claim.billed != null) return false;
        if (copay != null ? !copay.equals(claim.copay) : claim.copay != null) return false;
        if (providerRxEligInd != null ? !providerRxEligInd.equals(claim.providerRxEligInd) : claim.providerRxEligInd != null)
            return false;
        if (icddxCodes != null ? !icddxCodes.equals(claim.icddxCodes) : claim.icddxCodes != null) return false;
        if (icdpxCodes != null ? !icdpxCodes.equals(claim.icdpxCodes) : claim.icdpxCodes != null) return false;
        if (icddx10Codes != null ? !icddx10Codes.equals(claim.icddx10Codes) : claim.icddx10Codes != null) return false;
        if (icdpx10codes != null ? !icdpx10codes.equals(claim.icdpx10codes) : claim.icdpx10codes != null) return false;
        if (cptpxCodes != null ? !cptpxCodes.equals(claim.cptpxCodes) : claim.cptpxCodes != null) return false;
        if (hcpcspxCodes != null ? !hcpcspxCodes.equals(claim.hcpcspxCodes) : claim.hcpcspxCodes != null) return false;
        if (providerSpecialty != null ? !providerSpecialty.equals(claim.providerSpecialty) : claim.providerSpecialty != null)
            return false;
        if (tob != null ? !tob.equals(claim.tob) : claim.tob != null) return false;
        if (hpx != null ? !hpx.equals(claim.hpx) : claim.hpx != null) return false;
        if (drgCodes != null ? !drgCodes.equals(claim.drgCodes) : claim.drgCodes != null) return false;
        if (msdrgCodes != null ? !msdrgCodes.equals(claim.msdrgCodes) : claim.msdrgCodes != null) return false;
        if (apdrgCodes != null ? !apdrgCodes.equals(claim.apdrgCodes) : claim.apdrgCodes != null) return false;
        if (aprdrgCodes != null ? !aprdrgCodes.equals(claim.aprdrgCodes) : claim.aprdrgCodes != null) return false;
        if (claimAltIds != null ? !claimAltIds.equals(claim.claimAltIds) : claim.claimAltIds != null) return false;
        if (cptModCodes != null ? !cptModCodes.equals(claim.cptModCodes) : claim.cptModCodes != null) return false;
        if (hcfaposCodes != null ? !hcfaposCodes.equals(claim.hcfaposCodes) : claim.hcfaposCodes != null) return false;
        if (hcpcsModCodes != null ? !hcpcsModCodes.equals(claim.hcpcsModCodes) : claim.hcpcsModCodes != null)
            return false;
        if (providerTypeCodes != null ? !providerTypeCodes.equals(claim.providerTypeCodes) : claim.providerTypeCodes != null)
            return false;
        if (ubRevenueCodes != null ? !ubRevenueCodes.equals(claim.ubRevenueCodes) : claim.ubRevenueCodes != null)
            return false;
        return cvx != null ? cvx.equals(claim.cvx) : claim.cvx == null;
    }

    @Override
    public int hashCode() {
        int result = claimId;
        result = 31 * result + (payerClaimControlNumber != null ? payerClaimControlNumber.hashCode() : 0);
        result = 31 * result + (cost != null ? cost.hashCode() : 0);
        result = 31 * result + (admissionDate != null ? admissionDate.hashCode() : 0);
        result = 31 * result + (dischargeDate != null ? dischargeDate.hashCode() : 0);
        result = 31 * result + (supplementalSourceCode != null ? supplementalSourceCode.hashCode() : 0);
        result = 31 * result + (patientStatusCode != null ? patientStatusCode.hashCode() : 0);
        result = 31 * result + (claimStatusCode != null ? claimStatusCode.hashCode() : 0);
        result = 31 * result + (deniedDayOrVisitCount != null ? deniedDayOrVisitCount.hashCode() : 0);
        result = 31 * result + (roomBoardInd != null ? roomBoardInd.hashCode() : 0);
        result = 31 * result + (majorSurgeryInd != null ? majorSurgeryInd.hashCode() : 0);
        result = 31 * result + (serviceUnitCount != null ? serviceUnitCount.hashCode() : 0);
        result = 31 * result + (excludeFromDischargeInd != null ? excludeFromDischargeInd.hashCode() : 0);
        result = 31 * result + (pcpInd != null ? pcpInd.hashCode() : 0);
        result = 31 * result + (clientProviderId != null ? clientProviderId.hashCode() : 0);
        result = 31 * result + (clientMemberId != null ? clientMemberId.hashCode() : 0);
        result = 31 * result + (presentOnAdmission != null ? presentOnAdmission.hashCode() : 0);
        result = 31 * result + feedInstanceId;
        result = 31 * result + udfActiveInd;
        result = 31 * result + (billed != null ? billed.hashCode() : 0);
        result = 31 * result + (copay != null ? copay.hashCode() : 0);
        result = 31 * result + (providerRxEligInd != null ? providerRxEligInd.hashCode() : 0);
        result = 31 * result + (icddxCodes != null ? icddxCodes.hashCode() : 0);
        result = 31 * result + (icdpxCodes != null ? icdpxCodes.hashCode() : 0);
        result = 31 * result + (icddx10Codes != null ? icddx10Codes.hashCode() : 0);
        result = 31 * result + (icdpx10codes != null ? icdpx10codes.hashCode() : 0);
        result = 31 * result + (cptpxCodes != null ? cptpxCodes.hashCode() : 0);
        result = 31 * result + (hcpcspxCodes != null ? hcpcspxCodes.hashCode() : 0);
        result = 31 * result + (providerSpecialty != null ? providerSpecialty.hashCode() : 0);
        result = 31 * result + (tob != null ? tob.hashCode() : 0);
        result = 31 * result + (hpx != null ? hpx.hashCode() : 0);
        result = 31 * result + (drgCodes != null ? drgCodes.hashCode() : 0);
        result = 31 * result + (msdrgCodes != null ? msdrgCodes.hashCode() : 0);
        result = 31 * result + (apdrgCodes != null ? apdrgCodes.hashCode() : 0);
        result = 31 * result + (aprdrgCodes != null ? aprdrgCodes.hashCode() : 0);
        result = 31 * result + (claimAltIds != null ? claimAltIds.hashCode() : 0);
        result = 31 * result + (cptModCodes != null ? cptModCodes.hashCode() : 0);
        result = 31 * result + (hcfaposCodes != null ? hcfaposCodes.hashCode() : 0);
        result = 31 * result + (hcpcsModCodes != null ? hcpcsModCodes.hashCode() : 0);
        result = 31 * result + (providerTypeCodes != null ? providerTypeCodes.hashCode() : 0);
        result = 31 * result + (ubRevenueCodes != null ? ubRevenueCodes.hashCode() : 0);
        result = 31 * result + (cvx != null ? cvx.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Claim{" +
                "claimId=" + claimId +
                ", payerClaimControlNumber='" + payerClaimControlNumber + '\'' +
                ", cost='" + cost + '\'' +
                ", admissionDate='" + admissionDate + '\'' +
                ", dischargeDate='" + dischargeDate + '\'' +
                ", supplementalSourceCode='" + supplementalSourceCode + '\'' +
                ", patientStatusCode='" + patientStatusCode + '\'' +
                ", claimStatusCode='" + claimStatusCode + '\'' +
                ", deniedDayOrVisitCount='" + deniedDayOrVisitCount + '\'' +
                ", roomBoardInd='" + roomBoardInd + '\'' +
                ", majorSurgeryInd='" + majorSurgeryInd + '\'' +
                ", serviceUnitCount='" + serviceUnitCount + '\'' +
                ", excludeFromDischargeInd='" + excludeFromDischargeInd + '\'' +
                ", pcpInd='" + pcpInd + '\'' +
                ", clientProviderId='" + clientProviderId + '\'' +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", presentOnAdmission='" + presentOnAdmission + '\'' +
                ", feedInstanceId='" + feedInstanceId + '\'' +
                ", udfActiveInd='" + udfActiveInd + '\'' +
                ", billed='" + billed + '\'' +
                ", copay='" + copay + '\'' +
                ", providerRxEligInd='" + providerRxEligInd + '\'' +
                ", icddxCodes=" + icddxCodes +
                ", icdpxCodes=" + icdpxCodes +
                ", icddx10Codes=" + icddx10Codes +
                ", icdpx10codes=" + icdpx10codes +
                ", cptpxCodes=" + cptpxCodes +
                ", hcpcspxCodes=" + hcpcspxCodes +
                ", providerSpecialty=" + providerSpecialty +
                ", tob=" + tob +
                ", hpx=" + hpx +
                ", drgCodes=" + drgCodes +
                ", msdrgCodes=" + msdrgCodes +
                ", apdrgCodes=" + apdrgCodes +
                ", aprdrgCodes=" + aprdrgCodes +
                ", claimAltIds=" + claimAltIds +
                ", cptModCodes=" + cptModCodes +
                ", hcfaposCodes=" + hcfaposCodes +
                ", hcpcsModCodes=" + hcpcsModCodes +
                ", providerTypeCodes=" + providerTypeCodes +
                ", ubRevenueCodes=" + ubRevenueCodes +
                ", cvx=" + cvx +
                '}';
    }
}

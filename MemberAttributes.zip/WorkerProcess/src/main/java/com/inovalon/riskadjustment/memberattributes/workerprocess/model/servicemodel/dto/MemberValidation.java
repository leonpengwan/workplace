package com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto;


public class MemberValidation {
    private int memberValidationId;
    private int memberAttributesRunId;
    private int memberId;
    private String personId;
    private boolean inValidAddress;
    private boolean inValidPhone;

    public MemberValidation() {
    }

    public MemberValidation(int memberValidationId, int memberAttributesRunId, int memberId, String personId, boolean inValidAddress, boolean inValidPhone) {
        this.memberValidationId = memberValidationId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.memberId = memberId;
        this.personId = personId;
        this.inValidAddress = inValidAddress;
        this.inValidPhone = inValidPhone;
    }

    public int getMemberValidationId() {
        return memberValidationId;
    }

    public void setMemberValidationId(int memberValidationId) {
        this.memberValidationId = memberValidationId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public boolean isInValidAddress() {
        return inValidAddress;
    }

    public void setInValidAddress(boolean inValidAddress) {
        this.inValidAddress = inValidAddress;
    }

    public boolean isInValidPhone() {
        return inValidPhone;
    }

    public void setInValidPhone(boolean inValidPhone) {
        this.inValidPhone = inValidPhone;
    }
}

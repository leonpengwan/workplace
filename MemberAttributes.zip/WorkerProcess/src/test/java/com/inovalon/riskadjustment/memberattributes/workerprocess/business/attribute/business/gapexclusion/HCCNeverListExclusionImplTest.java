package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.gapexclusion;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service.HCCNeverListExclusionService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccConversionExclusionList;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Hcc;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.SectionMinimumGapConfidenceValue;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Sections;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
@Ignore
public class HCCNeverListExclusionImplTest {

    @InjectMocks
    private HCCNeverListExclusionService mockHccNeverListExclusionService;
    private RunProfile runProfile;
    private CacheUtil cacheUtil;
    private MemberAttribute memberAttribute;
    private List<MemberEvidenceStatus> memberEvidenceStatuses;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        runProfile = new RunProfile();
        createHCCInformation(runProfile);
        cacheUtil = new CacheUtil();
        buildCacheData(cacheUtil);
        memberEvidenceStatuses = new ArrayList<>();
    }

    private void buildCacheData(CacheUtil cacheUtil) {
        List<ModelHhsHccConversionExclusionList> ModelHhsHccConversionExclusionList = new ArrayList<>();
        ModelHhsHccConversionExclusionList modelHhsHccConversionExclusion = new ModelHhsHccConversionExclusionList();
        modelHhsHccConversionExclusion.setHccCode("1");
        modelHhsHccConversionExclusion.setClientId(379);
        modelHhsHccConversionExclusion.setExcludedCEDI(true);
        modelHhsHccConversionExclusion.setExcludedUCCC(true);
        ModelHhsHccConversionExclusionList.add(modelHhsHccConversionExclusion);
        modelHhsHccConversionExclusion = new ModelHhsHccConversionExclusionList();
        modelHhsHccConversionExclusion.setHccCode("2");
        modelHhsHccConversionExclusion.setClientId(379);
        modelHhsHccConversionExclusion.setExcludedCEDI(false);
        ModelHhsHccConversionExclusionList.add(modelHhsHccConversionExclusion);

        Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = new HashMap<>();
        ModelHhsHccConversionExclusionList.forEach(element -> {
            hccConversionExclusionListMap.put(element.getClientId() + "-" + element.getHccCode(), element);
        });
        cacheUtil.setHhsHccConversionExclusion(hccConversionExclusionListMap);

        Map<String, ExclusionTypeModel> exclusionTypeModelMap = new HashMap<>();
        ExclusionTypeModel exclusionTypeModel = new ExclusionTypeModel();
        exclusionTypeModel.setExclusionId(1010);
        exclusionTypeModel.setName("HccNeverlist");
        exclusionTypeModelMap.put("HccNeverlist", exclusionTypeModel);
        exclusionTypeModel = new ExclusionTypeModel();
        exclusionTypeModel.setExclusionId(1040);
        exclusionTypeModel.setName("HccNeverlistWithNullGapeType");
        exclusionTypeModelMap.put("HccNeverlistWithNullGapeType", exclusionTypeModel);
        cacheUtil.setExclusionTypeModelMap(exclusionTypeModelMap);
    }


    private void createHCCInformation(RunProfile runProfile) {
        runProfile.setClientId(379);
        List<Hcc> hccs = new ArrayList<>();
        Sections sections = new Sections();
        runProfile.setSections(sections);
        SectionMinimumGapConfidenceValue minimumGapConfidenceValue = new SectionMinimumGapConfidenceValue();
        sections.setMinimumGapConfidenceValue(minimumGapConfidenceValue);
        minimumGapConfidenceValue.setHccs(hccs);
        Hcc Hcc1 = new Hcc("1", "Medium");
        hccs.add(Hcc1);
        Hcc Hcc2 = new Hcc("2", "Low");
        hccs.add(Hcc2);
        Hcc Hcc3 = new Hcc("3", "High");
        hccs.add(Hcc3);
    }

    @Test
    @Ignore
    public void testPostiveCase() {
        buildMemberEvidencesPositive(memberEvidenceStatuses);
        mockHccNeverListExclusionService.excludeGaps(runProfile, memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true, memberEvidenceStatuses.get(0).getExclusionId() != 0);
    }

    private void buildMemberEvidencesPositive(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("1");
        memberEvidenceStatus.setGapConfidenceLevel("Low");
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatusList.add(memberEvidenceStatus);
    }

    @Test
    public void testNegativeCase() {
        buildMemberEvidencesNegative(memberEvidenceStatuses);
        mockHccNeverListExclusionService.excludeGaps(runProfile, memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true, memberEvidenceStatuses.get(0).getExclusionId() == 0);
    }

    private void buildMemberEvidencesNegative(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("2");
        memberEvidenceStatus.setGapConfidenceLevel("Low");
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatusList.add(memberEvidenceStatus);
    }

}

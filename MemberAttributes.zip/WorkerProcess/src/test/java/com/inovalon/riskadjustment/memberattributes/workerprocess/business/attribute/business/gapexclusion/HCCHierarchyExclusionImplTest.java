package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.gapexclusion;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service.HCCHierarchyExclusionService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccCodeHierarchy;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccConversionExclusionList;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Hcc;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.SectionMinimumGapConfidenceValue;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Sections;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
@Ignore
public class HCCHierarchyExclusionImplTest {
    
    @InjectMocks
    private HCCHierarchyExclusionService hccHierarchyExclusionService;
    private RunProfile runProfile;
    private CacheUtil cacheUtil;
    private MemberAttribute memberAttribute;
    private List<MemberEvidenceStatus> memberEvidenceStatuses;
    
    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        runProfile = new RunProfile();
        memberAttribute = new MemberAttribute();
        createHCCInformation(runProfile);
        cacheUtil = new CacheUtil();
        buildCacheData(cacheUtil);
        memberEvidenceStatuses = new ArrayList<>();
    }

    private void buildCacheData(CacheUtil cacheUtil) {
        List<ModelHhsHccCodeHierarchy> modelHhsHccCodeHierarchies = new ArrayList<>();
        ModelHhsHccCodeHierarchy modelHhsHccConversionExclusion = new ModelHhsHccCodeHierarchy();
        modelHhsHccConversionExclusion.setHccCode("1");
        modelHhsHccConversionExclusion.setHccCodeToDrop("1");
        modelHhsHccConversionExclusion.setAgeGroupId(1);
        modelHhsHccCodeHierarchies.add(modelHhsHccConversionExclusion);
        modelHhsHccConversionExclusion = new ModelHhsHccCodeHierarchy();
        modelHhsHccConversionExclusion.setHccCode("2");
        modelHhsHccConversionExclusion.setHccCodeToDrop("1");
        modelHhsHccConversionExclusion.setAgeGroupId(2);
        modelHhsHccCodeHierarchies.add(modelHhsHccConversionExclusion);
        cacheUtil.setHhsHccCodeHierarchies(modelHhsHccCodeHierarchies);

        Map<String, ExclusionTypeModel> exclusionTypeModelMap = new HashMap<>();
        ExclusionTypeModel exclusionTypeModel = new ExclusionTypeModel();
        exclusionTypeModel = new ExclusionTypeModel();
        exclusionTypeModel.setExclusionId(1001);
        exclusionTypeModel.setName("HccHierarchy");
        exclusionTypeModelMap.put("HccHierarchy", exclusionTypeModel);
        cacheUtil.setExclusionTypeModelMap(exclusionTypeModelMap);
    }


    private void createHCCInformation(RunProfile runProfile) {
        runProfile.setClientId(379);
        List<Hcc> hccs = new ArrayList<>();
        Sections sections = new Sections();
        runProfile.setSections(sections);
        SectionMinimumGapConfidenceValue minimumGapConfidenceValue = new SectionMinimumGapConfidenceValue();
        sections.setMinimumGapConfidenceValue(minimumGapConfidenceValue);
        minimumGapConfidenceValue.setHccs(hccs);
        Hcc Hcc1 = new Hcc("1", "Medium");
        hccs.add(Hcc1);
        Hcc Hcc2 = new Hcc("2", "Low");
        hccs.add(Hcc2);
        Hcc Hcc3 = new Hcc("3", "High");
        hccs.add(Hcc3);
    }


    @Test
    public void testPostiveCase(){
        buildMemberEvidencesPositive(memberEvidenceStatuses);
        hccHierarchyExclusionService.excludeGaps(runProfile,  memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true,memberEvidenceStatuses.get(0).getExclusionId()==0);
    }

    @Test
    public void testNegativeCase(){
        buildMemberEvidencesPositive(memberEvidenceStatuses);
        hccHierarchyExclusionService.excludeGaps(runProfile,  memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true,memberEvidenceStatuses.get(0).getExclusionId()!=0);
    }

    private void buildMemberEvidencesPositive(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("3");
        memberEvidenceStatus.setGapConfidenceLevel("Low");
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatusList.add(memberEvidenceStatus);
        memberAttribute.setAgeGroupId(1);
    }

    private void buildMemberEvidencesNegative(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("2");
        memberEvidenceStatus.setGapConfidenceLevel("Low");
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatusList.add(memberEvidenceStatus);
        memberAttribute.setAgeGroupId(2);
    }
}

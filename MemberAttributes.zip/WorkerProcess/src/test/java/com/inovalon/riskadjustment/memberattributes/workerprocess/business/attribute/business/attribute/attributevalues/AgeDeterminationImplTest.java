package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.attributevalues;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.AgeDetermine;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.DateRange;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.SectionInterventionPlanTimeframe;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Sections;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Calendar;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AgeDeterminationImplTest.class)
public class AgeDeterminationImplTest {

    @InjectMocks
    private AgeDetermine mockAgeDetermine;
    private RunProfile runProfile;
    private PatientProfile patientProfile;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    @Mock
    private LogWriter logWriter;


    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        cacheUtil = new CacheUtil();
        runProfile = new RunProfile();
        memberAttribute = new MemberAttribute();
        patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -10);
        patientProfile.setBirthDate(calendar.getTime());
        memberAttribute.setPlanningMonthStartDate(Calendar.getInstance().getTime());
        memberAttribute.setMissingDateOfBirth(false);
        Sections sections = new Sections();
        runProfile.setSections(sections);
        SectionInterventionPlanTimeframe interventionPlanTimeframe = new SectionInterventionPlanTimeframe();
        DateRange interventionPlanPeriod = new DateRange();
        interventionPlanPeriod.setStart(Calendar.getInstance().getTime());
        interventionPlanTimeframe.setInterventionPlanPeriod(interventionPlanPeriod);
        runProfile.getSections().setInterventionPlanTimeframe(interventionPlanTimeframe);



    }

    @Before
    public void destroy(){

    }

    @Test
    public void AgeDetermineTestPositiveCase() throws RangException {
        mockAgeDetermine.setAttributeValue(runProfile, patientProfile, memberAttribute, cacheUtil);
        assertEquals("Paitent Should be Child", true, memberAttribute.getAge()==10);
    }

    @Test
    public void AgeDetermineTestNegativeCase() throws RangException {
        mockAgeDetermine.setAttributeValue(runProfile, patientProfile,  memberAttribute, cacheUtil);
        assertEquals("Paitent Should be Child", true, memberAttribute.getAgeGroupId()==0);
    }



}


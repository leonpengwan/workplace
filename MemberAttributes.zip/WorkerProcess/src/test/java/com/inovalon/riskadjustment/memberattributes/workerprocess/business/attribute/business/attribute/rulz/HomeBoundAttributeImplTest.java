package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.rulz;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.HomeBoundAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Claim;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHomeBoundCode;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@Ignore
public class HomeBoundAttributeImplTest {


    @InjectMocks
    private HomeBoundAttribute mockHomeBoundAttribute;
    private MemberAttribute memberAttribute;
    private CustomizedStagingMessage message;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;
    private Date planStartDate;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        message = new CustomizedStagingMessage();
        memberAttribute = new MemberAttribute();
        memberAttribute.setPlanningMonthStartDate(Calendar.getInstance().getTime());
        cacheUtil = new CacheUtil();
        List<ModelHhsHomeBoundCode> homeBoundCpt = new ArrayList<>();
        cacheUtil.setModelHhsHomeBoundListCpt(homeBoundCpt);

        System.out.println("Count of CPT codes retrieved from cache : " + homeBoundCpt.size());

        List<ModelHhsHomeBoundCode> homeBoundHcpcs = new ArrayList<>();
        cacheUtil.setModelHhsHomeBoundListHcpcs(homeBoundHcpcs);

        System.out.println("Count of HCPCS codes retrieved from cache : " + homeBoundHcpcs.size());

        List<ModelHhsHomeBoundCode> homeBoundICD = new ArrayList<>();
        cacheUtil.setModelHhsHomeBoundListIcd(homeBoundICD);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void checkingNewEnrolleeWithNoEnrollments() throws ParseException {
        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("By default ishomebound is false when patientProfile has no claims", false, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithNoclaimsWithinLast12months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        Claim claim = new Claim();
        calendar.set(2015, 01, 25);
        claim.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claimList.add(claim);
        patientProfile.setClaims(claimList);

        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);

        assertEquals("Not a Homebound since there are no previous claims within last 12 months", false, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithValidClaimsWithinLast12Months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        Claim claim = new Claim();
        calendar.set(2017, 01, 25);
        claim.setAdmissionDate(calendar.getTime());
        //claim.setAdmissionDate("2017-01-25 00:00:00");//yyyy-MM-dd HH:mm:ss 01/25/2015
        claimList.add(claim);
        patientProfile.setClaims(claimList);
        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Not Homebound since there are no homeboundcodes within last 12 months", false, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithValidClaimsAndHomeboundCptCodeWithinLast12Months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        calendar.set(2016, 02, 25);
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        List<String> cptList = new ArrayList<String>();
        cptList.add("99509");
        Claim claim = new Claim();
        calendar.set(2017, 01, 25);
        claim.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim.setCptPXCodes(cptList);
        claimList.add(claim);
        patientProfile.setClaims(claimList);

        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Not Homebound since there is homebound cpt code but not atleast 5 claims within last 12 months", false, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithValidClaimsAndHomeboundHcpsWithinLast12Months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        List<String> hcpcsList = new ArrayList<String>();
        hcpcsList.add("E0250");
        Claim claim = new Claim();
        calendar.set(2017,01,25);
        claim.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim.setHcpcsPXCodes(hcpcsList);
        claimList.add(claim);
        patientProfile.setClaims(claimList);

        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Homebound since there is homebound hcpcs code within last 12 months", true, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithValidClaimsAndHomeboundIcdWithinLast12Months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        List<String> icd9 = new ArrayList<String>();
        List<String> icd10 = new ArrayList<String>();
        icd9.add("3430");
        icd10.add("G801");

        Claim claim = new Claim();
        calendar.set(2017,01,25);
        claim.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim.getIcdDXCodes().add(0, icd9);
        claim.getIcdDXCodes().add(0, icd10);
        claimList.add(claim);
        patientProfile.setClaims(claimList);

        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Homebound since there is homebound icd code within last 12 months", true, memberAttribute.isHomebound());
    }

    @Test
    public void checkingHomeboundWithValidClaimsAndHomeboundhcpcsWithinLast12Months() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        Calendar calendar = Calendar.getInstance();
        String planStartDateString = "02/25/2016";
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

        Date planStartDate = formatter.parse(planStartDateString);
        List<Claim> claimList = new ArrayList<Claim>();
        List<String> hcpcsList1 = new ArrayList<String>();
        List<String> hcpcsList2 = new ArrayList<String>();
        List<String> hcpcsList3 = new ArrayList<String>();
        List<String> hcpcsList4 = new ArrayList<String>();
        List<String> hcpcsList5 = new ArrayList<String>();

        hcpcsList1.add("G0151");
        Claim claim1 = new Claim();
        claim1.setClaimId(1);
        calendar.set(2017,01,25);
        claim1.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim1.setHcpcsPXCodes(hcpcsList1);
        claimList.add(claim1);

        hcpcsList2.add("G0152");
        Claim claim2 = new Claim();
        claim2.setClaimId(2);
        calendar.set(2017,01,25);
        claim2.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim2.setHcpcsPXCodes(hcpcsList2);
        claimList.add(claim2);

        hcpcsList2.add("G0153");
        Claim claim3 = new Claim();
        claim3.setClaimId(3);
        calendar.set(2017,01,25);
        claim3.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim3.setHcpcsPXCodes(hcpcsList3);
        claimList.add(claim3);

        hcpcsList2.add("G0154");
        Claim claim4 = new Claim();
        claim4.setClaimId(4);
        calendar.set(2017,01,25);
        claim4.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim4.setHcpcsPXCodes(hcpcsList4);
        claimList.add(claim4);

        hcpcsList2.add("G0155");
        Claim claim5 = new Claim();
        claim5.setClaimId(5);
        calendar.set(2017,01,25);
        claim5.setAdmissionDate(calendar.getTime());//yyyy-MM-dd HH:mm:ss 01/25/2015
        claim5.setHcpcsPXCodes(hcpcsList5);
        claimList.add(claim5);

        patientProfile.setClaims(claimList);

        mockHomeBoundAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Homebound since there is and atleast 5 claims and homebound hcpcs code within last 12 months ", true, memberAttribute.isHomebound());
    }
}

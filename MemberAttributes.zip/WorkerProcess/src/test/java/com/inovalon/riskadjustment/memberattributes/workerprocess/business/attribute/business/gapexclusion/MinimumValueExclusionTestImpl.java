package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.gapexclusion;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service.MinimumGapExclusionService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.output.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.GapConfidenceLevel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Hcc;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.SectionMinimumGapConfidenceValue;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.Sections;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
@Ignore
public class MinimumValueExclusionTestImpl {

    @InjectMocks
    private MinimumGapExclusionService mockMinimumGapExclusionService;
    private RunProfile runProfile;
    private CacheUtil cacheUtil;
    private MemberAttribute memberAttribute;
    private List<MemberEvidenceStatus> memberEvidenceStatuses;


    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        runProfile = new RunProfile();
        createHCCInformation(runProfile);
        cacheUtil = new CacheUtil();
        buildCacheData(cacheUtil);
        memberEvidenceStatuses = new ArrayList<>();

        memberAttribute = new MemberAttribute();
    }

    private void buildMemberEvidences(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("3");
      /*  memberEvidenceStatus.setEncounterId();
        memberEvidenceStatus.setEncounterServiceDate();*/
        memberEvidenceStatus.setGapConfidenceLevel("Low");
        memberEvidenceStatus.setGapConfidenceValue(6598D);
        memberEvidenceStatus.setGapSetDetailId(1);
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatus.setMemberAttributesRunId(1);
        memberEvidenceStatus.setOriginalHccCode(null);
        memberEvidenceStatus.setMemberId(217110);
        memberEvidenceStatus.setMemberEvidenceId(1);
        memberEvidenceStatus.setPractitionerId(11567);
        memberEvidenceStatus.setMemberEvidenceStatusId(1);
        memberEvidenceStatusList.add(memberEvidenceStatus);
    }

    private void buildCacheData(CacheUtil cacheUtil) {
        List<GapConfidenceLevel> gapConfidenceLevels = new ArrayList<>();
        GapConfidenceLevel gapConfidenceLevel0 = new GapConfidenceLevel();
        gapConfidenceLevel0.setDescription("Low");
        gapConfidenceLevel0.setName("Low");
        gapConfidenceLevel0.setGapConfidenceLevelId(1);
        gapConfidenceLevel0.setHierarchy(1);
        gapConfidenceLevel0.setWeightPercentage(0.25);
        gapConfidenceLevels.add(gapConfidenceLevel0);
        GapConfidenceLevel gapConfidenceLevel1 = new GapConfidenceLevel();
        gapConfidenceLevel1.setDescription("Medium");
        gapConfidenceLevel1.setName("Medium");
        gapConfidenceLevel1.setGapConfidenceLevelId(2);
        gapConfidenceLevel1.setHierarchy(2);
        gapConfidenceLevel1.setWeightPercentage(0.5);
        gapConfidenceLevels.add(gapConfidenceLevel1);
        GapConfidenceLevel gapConfidenceLevel2 = new GapConfidenceLevel();
        gapConfidenceLevel2.setDescription("High");
        gapConfidenceLevel2.setName("High");
        gapConfidenceLevel2.setGapConfidenceLevelId(3);
        gapConfidenceLevel2.setHierarchy(3);
        gapConfidenceLevel2.setWeightPercentage(0.75);
        gapConfidenceLevels.add(gapConfidenceLevel2);
        GapConfidenceLevel gapConfidenceLevel3 = new GapConfidenceLevel();
        gapConfidenceLevel3.setDescription("Very High");
        gapConfidenceLevel3.setName("Very High");
        gapConfidenceLevel3.setGapConfidenceLevelId(4);
        gapConfidenceLevel3.setHierarchy(4);
        gapConfidenceLevel3.setWeightPercentage(0.9);
        gapConfidenceLevels.add(gapConfidenceLevel3);
        if (gapConfidenceLevels != null && gapConfidenceLevels.size() > 0) {
            Map<String, Integer> confidenceMap = new HashMap<String, Integer>();
            for (GapConfidenceLevel gapConfidenceLevel : gapConfidenceLevels) {
                confidenceMap.put(gapConfidenceLevel.getName(), gapConfidenceLevel.getHierarchy());
            }
            cacheUtil.setGapConfidenceLevels(confidenceMap);
        }

        Map<String,ExclusionTypeModel> exclusionTypeModelMap = new HashMap<>();
        ExclusionTypeModel exclusionTypeModel = new ExclusionTypeModel();
        exclusionTypeModel.setExclusionId(1000);
        exclusionTypeModel.setName("MinimumGapConfidenceLevel");
        exclusionTypeModelMap.put("MinimumGapConfidenceLevel",exclusionTypeModel);
        cacheUtil.setExclusionTypeModelMap(exclusionTypeModelMap);

    }

    private void createHCCInformation(RunProfile runProfile) {
        List<Hcc> hccs = new ArrayList<>();
        Sections sections = new Sections();
        runProfile.setSections(sections);
        SectionMinimumGapConfidenceValue minimumGapConfidenceValue = new SectionMinimumGapConfidenceValue();
        sections.setMinimumGapConfidenceValue(minimumGapConfidenceValue);
        minimumGapConfidenceValue.setHccs(hccs);
        Hcc Hcc1 = new Hcc("1","Medium");
        hccs.add(Hcc1);
        Hcc Hcc2 = new Hcc("2","Low");
        hccs.add(Hcc2);
        Hcc Hcc3 = new Hcc("3","High");
        hccs.add(Hcc3);
    }

    @Test
    public void excludeGapWithPositiveScenario(){
        buildMemberEvidences(memberEvidenceStatuses);
        mockMinimumGapExclusionService.excludeGaps(runProfile,  memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true,memberEvidenceStatuses.get(0).getExclusionId()!=0);

    }


    @Test
    public void excludeGapWithNegativeScenario(){
        buildNegativeMemberEvidences(memberEvidenceStatuses);
        mockMinimumGapExclusionService.excludeGaps(runProfile,  memberEvidenceStatuses, cacheUtil, memberAttribute);
        Assert.assertEquals("Gap is exluded", true,memberEvidenceStatuses.get(0).getExclusionId()==0);
    }

    private void buildNegativeMemberEvidences(List<MemberEvidenceStatus> memberEvidenceStatusList) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>();
        MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
        memberEvidenceStatus.setExclusionId(0);
        memberEvidenceStatus.setHccCode("4");
        memberEvidenceStatus.setGapConfidenceLevel("Low");
      /*  memberEvidenceStatus.setEncounterId();
        memberEvidenceStatus.setEncounterServiceDate();*/
        /*memberEvidenceStatus.setGapConfidenceValue(6598D);
        memberEvidenceStatus.setGapSetDetailId(1);
        memberEvidenceStatus.setGapType("cedi");
        memberEvidenceStatus.setMemberAttributesRunId(1);
        memberEvidenceStatus.setOriginalHccCode(null);
        memberEvidenceStatus.setMemberId(217110);
        memberEvidenceStatus.setMemberEvidenceId(1);
        memberEvidenceStatus.setPractitionerId(11567);
        memberEvidenceStatus.setMemberEvidenceStatusId(1);*/
        memberEvidenceStatusList.add(memberEvidenceStatus);
    }
}

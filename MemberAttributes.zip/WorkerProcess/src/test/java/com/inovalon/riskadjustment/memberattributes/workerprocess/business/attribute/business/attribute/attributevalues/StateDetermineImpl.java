package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.attributevalues;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@Ignore
public class StateDetermineImpl {

    @MockBean
    private StateDetermineImpl stateDetermine;
    private RunProfile runprofile;
    private MemberAttribute memberAttribute;
    private PatientProfile patientProfile;
    private CacheUtil cacheUtil;

    @Before
    public void init(){
        runprofile = new RunProfile();
        memberAttribute = new MemberAttribute();
        //memberAttribute.setPlanningMonthStartDate();

    }
}

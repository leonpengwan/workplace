package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.attributevalues;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.AgeGroupDetermine;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.cache.AgeGroup;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AgeGroupDetermineImpl {

    @InjectMocks
    private AgeGroupDetermine mockAgeGroupDetermine;
    private RunProfile runProfile;
    private PatientProfile patientProfile;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    List<AgeGroup> ageGroupList;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        cacheUtil = new CacheUtil();
        runProfile = new RunProfile();
        memberAttribute = new MemberAttribute();
        patientProfile = new PatientProfile();
        ageGroupList = new ArrayList<>();
        cacheUtil.setAgeGroup(ageGroupList);
        AgeGroup ageGroup = new AgeGroup();
        ageGroup.setAgeTo(1);
        ageGroup.setAgeGroupId(1);
        ageGroup.setAgeFrom(0);
        ageGroup.setDescription("Infant");
        cacheUtil.getAgeGroup().add(ageGroup);
        ageGroup = new AgeGroup();
        ageGroup.setAgeTo(20);
        ageGroup.setAgeGroupId(2);
        ageGroup.setAgeFrom(2);
        ageGroup.setDescription("Child");
        cacheUtil.getAgeGroup().add(ageGroup);
    }

    @Before
    public void destroy(){

    }

    @Test
    public void AgeDetermineTestPositiveCase() throws RangException {
        memberAttribute.setAge(18);
        mockAgeGroupDetermine.setAttributeValue(runProfile, patientProfile, memberAttribute, cacheUtil);
        assertEquals("Paitent Should be Child", true, memberAttribute.getAgeGroupId()==2);
    }

    @Test
    public void AgeDetermineTestNegativeCase() throws RangException {
        memberAttribute.setAge(-1);
        mockAgeGroupDetermine.setAttributeValue(runProfile, patientProfile,  memberAttribute, cacheUtil);
        assertEquals("Paitent Should be Child", true, memberAttribute.getAgeGroupId()==0);
    }
}

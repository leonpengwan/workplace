package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.rulz;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.NewEnrolleeAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;


// * Created by djose on 11/9/2017.


@RunWith(SpringRunner.class)
@SpringBootTest
@Ignore
public class NewEnrolleeStatusServiceImplTest {

    @InjectMocks
    private NewEnrolleeAttribute mockNewEnrolleeAttribute;
    private RunProfile runProfile;
    private CustomizedStagingMessage message;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    private Date planStartDate;
    List<Enrollment> enrollments;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        message = new CustomizedStagingMessage();
        memberAttribute = new MemberAttribute();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        runProfile = new RunProfile();
        cacheUtil = new CacheUtil();
        Calendar calendar = Calendar.getInstance();
        planStartDate = calendar.getTime();
        planStartDate.setMonth(1);
        planStartDate.setDate(1);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void checkingNewEnrolleeWithNoEnrollments() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        patientProfile.setEnrollments(enrollments);
        message.setPatientProfile(patientProfile);
        mockNewEnrolleeAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("By default isNewEnrollee is false when patientProfile has no Enrollments", false, memberAttribute.isNewEnrollee());
    }

    @Test
    public void checkingNewEnrolleeWithInvalidEnrollments() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        patientProfile.setEnrollments(enrollments);
        List<Enrollment> enrollmentList = new ArrayList<>();
        Enrollment enrollment = new Enrollment();
        Date coverageDate = new Date(planStartDate.getYear() - 1, 0, 25);
        Date coverageEndDate = new Date(planStartDate.getYear() - 1, 11, 25);
        enrollment.setCoverageBeginDate(coverageDate);//yyyy-MM-dd HH:mm:ss 01/25/2015
        enrollment.setCoverageEndDate(coverageEndDate);//yyyy-MM-dd HH:mm:ss 12/25/2015
        enrollmentList.add(enrollment);
        patientProfile.setEnrollments(enrollmentList);
        message.setPatientProfile(patientProfile);
        mockNewEnrolleeAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Not a New Enrollee since there are previous year Enrollments", false, memberAttribute.isNewEnrollee());
    }

    @Test
    public void checkingNewEnrolleeWithValidEnrollments() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();

        List<Enrollment> enrollmentList1 = new ArrayList<>();
        Enrollment enrollment = new Enrollment();
        Date coverageDate = new Date(planStartDate.getYear(), 6, 25);
        Date coverageEndDate = new Date(planStartDate.getYear(), 8, 25);
        enrollment.setCoverageBeginDate(coverageDate);//yyyy-MM-dd HH:mm:ss 01/25/2014
        enrollment.setCoverageEndDate(coverageEndDate);//yyyy-MM-dd HH:mm:ss 12/25/2014
        enrollmentList1.add(enrollment);

        Enrollment enrollment2 = new Enrollment();
        coverageDate = new Date(planStartDate.getYear(), 02, 25);
        coverageEndDate = new Date(planStartDate.getYear(), 03, 25);
        enrollment2.setCoverageBeginDate(coverageDate);//yyyy-MM-dd HH:mm:ss 01/25/2016
        enrollment2.setCoverageEndDate(coverageEndDate);//yyyy-MM-dd HH:mm:ss 12/25/2016
        enrollmentList1.add(enrollment2);

        patientProfile.setEnrollments(enrollmentList1);
        message.setPatientProfile(patientProfile);
        mockNewEnrolleeAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Should be a New Enrollee since there are no previous year Enrollments", true, memberAttribute.isNewEnrollee());
    }
}


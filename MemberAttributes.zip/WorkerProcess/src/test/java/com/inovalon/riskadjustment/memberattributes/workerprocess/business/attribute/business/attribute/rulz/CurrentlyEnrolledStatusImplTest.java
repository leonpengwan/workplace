package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.business.attribute.rulz;


import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.CurrentlyEnrolledAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.CustomizedStagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.Enrollment;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.model.servicemodel.dto.PatientProfile;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CurrentlyEnrolledStatusImplTest.class)
@Ignore
public class CurrentlyEnrolledStatusImplTest {

    @InjectMocks
    private CurrentlyEnrolledAttribute currentlyEnrolledAttribute;
    private CustomizedStagingMessage message;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;
    private Date date;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Calendar calendar = Calendar.getInstance();
        message = new CustomizedStagingMessage();
        memberAttribute = new MemberAttribute();
        runProfile = new RunProfile();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        memberAttribute.setPlanningMonthEndDate(new Date(memberAttribute.getPlanningMonthStartDate().getYear(),11,31));
        date = calendar.getTime();

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void isCurrentlyEnrolledStatusTrue() {
        PatientProfile patientProfile = new PatientProfile();
        List<Enrollment> enrollments = new ArrayList<>();
        patientProfile.setEnrollments(enrollments);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageBeginDate = new Date(date.getYear(), 0, 1);
        Date coverageEndDate = new Date(date.getYear(), 11, 31);
        enrollment.setCoverageBeginDate(coverageBeginDate);
        enrollment.setCoverageEndDate(coverageEndDate);
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        currentlyEnrolledAttribute.applyRules(runProfile,message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isCurrentlyEnrolled should be true", true, memberAttribute.isCurrentlyEnrolled());
    }

    @Test
    public void isCurrentlyEnrolledStatusFalse() {
        PatientProfile patientProfile = new PatientProfile();
        List<Enrollment> enrollments = new ArrayList<>();
        patientProfile.setEnrollments(enrollments);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageBeginDate = new Date(date.getYear()-1, 10, 2);
        Date coverageEndDate = new Date(date.getYear()-1, 11, 1);
        enrollment.setCoverageBeginDate(coverageBeginDate);
        enrollment.setCoverageEndDate(coverageEndDate);
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        currentlyEnrolledAttribute.applyRules(runProfile,message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isCurrentlyEnrolled should be false", false, memberAttribute.isCurrentlyEnrolled());
    }
}

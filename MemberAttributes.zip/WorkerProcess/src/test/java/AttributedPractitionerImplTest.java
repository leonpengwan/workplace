//package com.inovalon.riskadjustment.business.impl;
//
//
//import com.inovalon.riskadjustment.business.impl.attributedpractitioner.AttributedPractitionerImpl;
//import com.inovalon.riskadjustment.model.input.patientProfile.Enrollment;
//import com.inovalon.riskadjustment.model.input.patientProfile.PatientProfile;
//import com.inovalon.riskadjustment.model.input.patientProfile.PatientProfileWithWinningEnrollment;
//import com.inovalon.riskadjustment.model.output.MemberStatus;
//import com.inovalon.riskadjustment.model.servicemodel.mongodbpatientprofile.ProviderDetails;
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.*;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.*;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest(classes = AttributedPractitionerImplTest.class)
//public class AttributedPractitionerImplTest {
//
//    @InjectMocks
//    private AttributedPractitionerImpl mockAttributedPractitionerService;
//
//    @Mock
//    private RestTemplate restTemplate = Mockito.mock(RestTemplate.class);
//
//    private PatientProfileWithWinningEnrollment patientProfileWithWinningEnrollment;
//    private MemberStatus memberStatus;
//    private List<ProviderDetails> providerDetails;
//
//    @Before
//    public void setUp() throws Exception {
//        MockitoAnnotations.initMocks(this);
//        memberStatus = new MemberStatus();
//        createPatientProfileWithWinningEnrollment();
//        createProviderDetails();
//    }
//
//    @After
//    public void tearDown() throws Exception {
//    }
//
//    @Test
//    public void getAttributedPractitionerId() {
//        ResponseEntity responseEntity = new ResponseEntity(providerDetails, HttpStatus.OK);
//
//        Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Matchers.any(Class.class)))
//                .thenReturn(responseEntity);
//        mockAttributedPractitionerService.getAttributedPractitionerId(patientProfileWithWinningEnrollment, memberStatus);
//        System.out.println(providerDetails.get(0).getProviderid());
//        Assert.assertEquals(1, memberStatus.getAttributedPractitionerId().intValue());
//    }
//
//    private void createPatientProfileWithWinningEnrollment() {
//        patientProfileWithWinningEnrollment = new PatientProfileWithWinningEnrollment();
//        PatientProfile patientProfile = new PatientProfile();
//        Set<Enrollment> enrollments = new HashSet<Enrollment>();
//        Enrollment enrollment1 = new Enrollment();
//        enrollment1.setMemberEnrollmentId(1);
//        enrollment1.setClientProviderId("1");
//        enrollments.add(enrollment1);
//        Enrollment enrollment2 = new Enrollment();
//        enrollment2.setMemberEnrollmentId(2);
//        enrollment2.setClientProviderId("2");
//        enrollments.add(enrollment2);
//        patientProfile.setEnrollments(enrollments);
//        patientProfileWithWinningEnrollment.setPatientProfile(patientProfile);
//        patientProfileWithWinningEnrollment.setWinningEnrollmentId(1);
//    }
//
//    private void createProviderDetails() {
//        providerDetails = new ArrayList<ProviderDetails>();
//        ProviderDetails providerDetail = new ProviderDetails();
//        providerDetail.setClientproviderid("1");
//        providerDetail.setProviderid("1");
//        providerDetails.add(providerDetail);
//    }
//}
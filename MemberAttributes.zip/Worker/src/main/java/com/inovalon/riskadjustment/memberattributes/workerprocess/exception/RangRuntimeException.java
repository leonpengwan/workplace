package com.inovalon.riskadjustment.memberattributes.workerprocess.exception;

public class RangRuntimeException extends RuntimeException {
}

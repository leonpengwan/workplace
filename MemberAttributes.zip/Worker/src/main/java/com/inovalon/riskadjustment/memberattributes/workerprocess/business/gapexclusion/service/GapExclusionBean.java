package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

public enum GapExclusionBean {
    MissingProfile("MissingProfile", "Attribute"),
    Deceased("Deceased", "Attribute"),
    Termed("Termed","Attribute"),
    MinimumGap("MinimumGapConfidenceLevel", "GAP"),
    HCCNeverListWithNull("HCCNeverList", "GAP"),
    HCCNeverList("HCCNeverList", "GAP"),
    HCCHierarchy("HCCHierarchyExclusion", "GAP"),
    HCCConversion("HCCConversion", "GAP"),
    HCCAgeGender("HCCAgeGenderExclusion", "GAP");

    public String getValue() {
        return value;
    }

    private String value;

    public String getType() {
        return type;
    }

    private String type;

    GapExclusionBean(String value, String type) {
        this.value = value;
        this.type = type;

    }
}

package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MemberValidationDaoImpl implements MemberValidationDao {

    @Autowired
    @Qualifier("interventionResultJdbcTemplate")
    private JdbcTemplate internvetionPlanResultTemplate;

    private final static String INSERT_QUERY = "insert into dbo.MemberValidation " +
            "(MemberAttributesRunId,MemberId,PersonId,InValidAddress,InValidPhone,ModifiedBy,CreatedBy) values (?,?,?,?,?,?,?)";

    @Override
    public int saveMemberValidation(MemberValidation memberValidation, String userInfo) {
        Object[] params = new Object[]{memberValidation.getMemberAttributesRunId(), memberValidation.getMemberId(), memberValidation.getPersonId(), memberValidation.isInValidAddress(), memberValidation.isInValidPhone(),userInfo,userInfo};
        int id = internvetionPlanResultTemplate.update(INSERT_QUERY, params);
        return id;
    }
}

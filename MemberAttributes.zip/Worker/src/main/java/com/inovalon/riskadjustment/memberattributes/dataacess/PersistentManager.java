package com.inovalon.riskadjustment.memberattributes.dataacess;

import com.inovalon.riskadjustment.memberattributes.dataacess.business.MemberAttributesService;
import com.inovalon.riskadjustment.memberattributes.dataacess.business.MemberEvidenceStatusService;
import com.inovalon.riskadjustment.memberattributes.dataacess.business.MemberValidationService;
import com.inovalon.riskadjustment.memberattributes.dataacess.business.PractitionerValidationService;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.WorkerProcessMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PersistentManager {

    @Autowired private MemberAttributesService memberAttributesService;
    @Autowired private MemberEvidenceStatusService memberEvidenceStatusService;
    @Autowired private MemberValidationService memberValidationService;
    @Autowired private PractitionerValidationService practitionerValidationService;

    public boolean persistWorkerProcess(WorkerProcessMessage workerProcessMessage){
        memberAttributesService.persistMemberAttributes(workerProcessMessage.getMemberAttribute(),workerProcessMessage.getUserInfo());
        memberEvidenceStatusService.persistMemberEvidence(workerProcessMessage.getMemberEvidenceStatuses(),workerProcessMessage.getUserInfo());
        memberValidationService.persistMemberValidation(workerProcessMessage.getMemberValidation(),workerProcessMessage.getUserInfo());
        practitionerValidationService.persistPractitionerValidation(workerProcessMessage.getPractitionerValidation(),workerProcessMessage.getUserInfo());
        return true;
    }

}

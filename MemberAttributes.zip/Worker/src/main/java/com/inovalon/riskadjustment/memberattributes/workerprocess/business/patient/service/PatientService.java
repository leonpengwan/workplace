package com.inovalon.riskadjustment.memberattributes.workerprocess.business.patient.service;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util.EnrollmentComparator;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util.EnrollmentCoverageBeginDateComparator;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util.EnrollmentCoverageEndDateComparator;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util.EnrollmentIdComparator;
import com.inovalon.riskadjustment.model.servicemodel.modelhhsmetallevel.ModelHhsMetalLevel;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;


@Component
public class PatientService {

    /* public static Comparator<Enrollment> EnrollmentCoverageBeginDateComparator = new Comparator<Enrollment>() {

         public int compare(Enrollment enrollment1, Enrollment enrollment2) {
             Date date1 = enrollment1.getCoverageBeginDate();
             Date date2 = enrollment2.getCoverageBeginDate();
             //descending order
             return date2.compareTo(date1);

         }

     };
     public static Comparator<Enrollment> EnrollmentIdComparator = new Comparator<Enrollment>() {

         public int compare(Enrollment enrollment1, Enrollment enrollment2) {

             long memberEnrollmentID1 = Long.valueOf(enrollment1.getMemberEnrollmentId());
             long memberEnrollmentID2 = Long.valueOf(enrollment2.getMemberEnrollmentId());
             //descending order
             return Math.toIntExact(memberEnrollmentID2 - memberEnrollmentID1);
         }

     };
     public static Comparator<Enrollment> EnrollmentCoverageEndDateComparator = new Comparator<Enrollment>() {

         public int compare(Enrollment enrollment1, Enrollment enrollment2) {
             Date date1 = enrollment1.getCoverageEndDate();
             Date date2 = enrollment2.getCoverageEndDate();
             //descending order
             return date2.compareTo(date1);
         }


     };*/
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public Enrollment getWinningEnrollment(List<Enrollment> enrollments) {

        Collections.sort(enrollments, new EnrollmentComparator(
                new EnrollmentCoverageEndDateComparator(),
                new EnrollmentCoverageBeginDateComparator(),
                new EnrollmentIdComparator())
        );

        /*Collections.sort(enrollments, EnrollmentCoverageEndDateComparator);
        Collections.sort(enrollments, EnrollmentCoverageBeginDateComparator);
        Collections.sort(enrollments, EnrollmentIdComparator);*/
        return enrollments.get(0);
    }

    // Pass the winning enrollment Id and iterate and get the metal level
    public void getMetalLevel(MemberAttribute memberAttribute, Set<Enrollment> enrollments, Map<String, ModelHhsMetalLevel> hhsMetalLevel) {
        Enrollment metalLevel = enrollments.stream().filter(enrollment -> enrollment.getMemberEnrollmentId() == memberAttribute.getWinningEnrollmentId()).findAny().orElse(null);
        memberAttribute.setMetalLevel(hhsMetalLevel.get(metalLevel.getMetalLevel()).getMetalLevelDescription());
    }


    public void getAttributedPractitionerId(PatientProfile patientProfile, List<ProviderProfile> providerProfiles, MemberAttribute memberAttribute) {
        Set<Enrollment> enrollments = patientProfile.getEnrollments();
        if (enrollments != null && enrollments.size() > 0) {
            String clientProviderId = enrollments.iterator().next().getClientProviderId();
            if (providerProfiles != null && providerProfiles.size() > 0) {
                ProviderProfile resultedProviderProfile = providerProfiles.stream().filter(providerProfile -> providerProfile.getClientProviderId().equalsIgnoreCase(clientProviderId)).findAny().orElse(null);
                memberAttribute.setAttributedPractitionerId(resultedProviderProfile != null ? Integer.valueOf(resultedProviderProfile.getProviderId()) : 0);
            }
        }
    }
}

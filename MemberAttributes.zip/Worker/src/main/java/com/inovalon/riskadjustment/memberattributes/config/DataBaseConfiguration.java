package com.inovalon.riskadjustment.memberattributes.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class DataBaseConfiguration {

    @Value("${inovalon.risk-adjustment.database.gap-result-connection-string}")
    private String gapResultsDatabaseUrl;

    @Value("${inovalon.risk-adjustment.database.gap-result-username}")
    private String gapResultsDatabaseUsername;

    @Value("${inovalon.risk-adjustment.database.gap-result-password}")
    private String gapResultsDatabasePassword;

    @Value("${inovalon.risk-adjustment.database.intervention-result-connection-string}")
    private String interventionResultsDatabaseUrl;

    @Value("${inovalon.risk-adjustment.database.intervention-result-username}")
    private String interventionResultsDatabaseUsername;

    @Value("${inovalon.risk-adjustment.database.intervention-result-password}")
    private String interventionResultsDatabasePassword;

    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-connection-string}")
    private String interventionPlanResultDatabaseUrl;
    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-username}")
    private String interventionPlanResultDatabaseUsername;
    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-password}")
    private String interventionPlanResultDatabasePassword;


    @Bean(name ="planResultDataSource")
    public DataSource getPlanResultDataSource(){
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(interventionPlanResultDatabaseUrl);
        dataSource.setUsername(interventionPlanResultDatabaseUsername);
        dataSource.setPassword(interventionPlanResultDatabasePassword);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(1);
        dataSource.setIdleTimeout(60000);
        return dataSource;
    }

    @Bean(name ="planResultJdbcTemplate")
    public JdbcTemplate getPlanResultJdbcTemplate(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(getPlanResultDataSource());
        return jdbcTemplate;
    }

    @Bean(name ="interventionResultDataSource")
    public DataSource getInterventionResultDataSource(){
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(interventionResultsDatabaseUrl);
        dataSource.setUsername(interventionResultsDatabaseUsername);
        dataSource.setPassword(interventionResultsDatabasePassword);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(1);
        dataSource.setIdleTimeout(60000);
        return dataSource;
    }

    @Bean(name ="interventionResultJdbcTemplate")
    public JdbcTemplate getInterventionResultJdbcTemplate(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(getInterventionResultDataSource());
        return jdbcTemplate;
    }

    @Primary
    @Bean(name ="gapResultDataSource")
    public DataSource getGapResultDataSource(){
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(gapResultsDatabaseUrl);
        dataSource.setUsername(gapResultsDatabaseUsername);
        dataSource.setPassword(gapResultsDatabasePassword);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(1);
        dataSource.setIdleTimeout(60000);
        return dataSource;
    }
    @Primary
    @Bean(name ="gapResultJdbcTemplate")
    public JdbcTemplate getGapResultJdbcTemplate(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(getGapResultDataSource());
        return jdbcTemplate;
    }
}

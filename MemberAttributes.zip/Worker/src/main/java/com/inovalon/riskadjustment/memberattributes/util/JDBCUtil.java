package com.inovalon.riskadjustment.memberattributes.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract class JDBCUtil {

    @Autowired
    @Qualifier("gapResultJdbcTemplate")
    private JdbcTemplate gapResultTemplate;

    @Autowired
    @Qualifier("planResultJdbcTemplate")
    private JdbcTemplate interventionResultTemplate;

    @Autowired
    @Qualifier("planResultJdbcTemplate")
    private JdbcTemplate planResultTemplate;


    public Connection getGapResultConnection() throws SQLException {
        return gapResultTemplate.getDataSource().getConnection();
    }

    public Connection getPlanResultConnection() throws SQLException {
        return planResultTemplate.getDataSource().getConnection();
    }

    public Connection getInterventionResultConnection() throws SQLException {
        return interventionResultTemplate.getDataSource().getConnection();
    }


    public void closeConnection(Connection con){
        if(con!=null){
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void closeResources(Connection con, PreparedStatement ps){
        try {
            if (con != null) {
                con.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

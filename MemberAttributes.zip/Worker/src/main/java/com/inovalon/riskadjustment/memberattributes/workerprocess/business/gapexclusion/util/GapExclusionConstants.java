package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util;

public class GapExclusionConstants {

    public static String HCC_MINIMUM_GAP_CONFIDENCE_LEVEL = "MinimumGapConfidenceLevel";
    public static String HCC_HIERARCHY = "HccHierarchy";
    public static String HCC_NEVERLIST = "HccNeverlist";
    public static String HCC_GAP_TYPE_NULL = "HccNeverlistWithNullGapeType";
    public static String HCC_CONVERSION = "HccConversion";
    public static String HCC_AGE_OR_GENDER_EXCLUSION = "HccAgeOrGenderExclusion";
    public static String MISSING_PROFILE="MissingProfile";
    public static String TERMED="Termed";
    public static String DECEASED="Deceased";
}



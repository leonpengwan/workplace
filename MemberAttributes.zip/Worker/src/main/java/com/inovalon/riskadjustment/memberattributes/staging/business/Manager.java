package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;

import com.inovalon.riskadjustment.memberattributes.dataacess.PersistentManager;
import com.inovalon.riskadjustment.memberattributes.dataacess.business.InterventionPlanService;
import com.inovalon.riskadjustment.memberattributes.dataacess.business.MemberEvidenceService;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerInputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerOuputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.WorkerProcessMessage;
import com.inovalon.riskadjustment.memberattributes.staging.messagebus.MessageProducer;
import com.inovalon.riskadjustment.memberattributes.staging.model.InterventionPlanRun;
import com.inovalon.riskadjustment.memberattributes.util.RetrieveInterventionPlanPeriod;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.WorkFlowManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.model.enums.MicroserviceType;
import com.inovalon.riskadjustment.model.enums.Status;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.GapDataSelection;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class Manager {

    @Autowired
    RetrieveInterventionPlan retrieveInterventionPlans;
    //@Autowired private RunProfileRetrieve runProfileRetrieve;
    @Autowired
    private GapSetDetailIdentification gapSetDetailIdentification;

    @Autowired
    private MemberEvidenceService memberEvidenceService;

    @Autowired
    private InterventionConfigurationService interventionConfigurationService;
    @Autowired
    private PatientProfileStaging patientProfileStaging;
    @Autowired
    private RetrieveInterventionPlanPeriod retrieveInterventionPlanPeriod;
    @Autowired
    private ProviderProfileStaging providerProfileStaging;
    @Autowired
    private InterventionPlanService interventionPlanService;
    @Autowired
    private LogWriter logWriter;
    @Autowired
    private WorkFlowManager workFlowManager;
    @Autowired
    private PersistentManager persistentManager;
    @Autowired
    private CacheManager cahCacheManager;
    @Autowired
    private MessageProducer messageBusProducer;


    /**
     * This method is to control data flow
     *
     * @param workerInputMessage
     * @return
     * @throws Exception
     */
    @LogBeforeEvents
    public WorkerOuputMessageAvro processInputBatchMessage(WorkerInputMessageAvro workerInputMessage)  {

        WorkerOuputMessageAvro ouputMessageAvro = new WorkerOuputMessageAvro() {{
            setBatchId(workerInputMessage.getBatchId());
            setRunId(workerInputMessage.getRunId());
            setRunProfileId(workerInputMessage.getRunProfileId());
            setMessageStatus(false);
        }};
        int memberAttributesRunId = workerInputMessage.getRunId();
        Long runProfileId = workerInputMessage.getRunProfileId();

        try {

            //Set runId status to 'In Progress'
            if (workerInputMessage.getRunId() == 0) {//if called directly
                memberAttributesRunId = interventionConfigurationService.retrieveRunIdByRunProfileId(runProfileId, MicroserviceType.MEMBER_ATTRIBUTES);
                interventionConfigurationService.updateRunStatus(memberAttributesRunId, Status.INPROGRESS);
            }

            logWriter.info("MemberAttributesRunId:" + memberAttributesRunId);

            CacheUtil cacheUtil = cahCacheManager.loadDataFromCache(runProfileId);
            // Get run profile
            //RunProfile runProfile = runProfileRetrieve.getRunProfileByRunProfileId(runProfileId,cacheUtil);
            RunProfile runProfile=cacheUtil.getRunProfile();

            // Get selected gapset section
            GapDataSelection gapDataSelection = gapSetDetailIdentification.getGapSetDetail(runProfile);
            String gapSetId = gapDataSelection.getGapSetId();

            logWriter.info("GapSetID:" + gapSetId);

            List<Integer> memberIds = workerInputMessage.getMemberIds();

            logWriter.info("List of MemberIds " + memberIds);

            // if get null member or 0 in the list  break loop
            if (memberIds == null || memberIds.size() == 0) {
               throw new RangException("No members to process in the batch!");
            }
            Date lookBackDate = retrieveInterventionPlanPeriod.getInterventionPlanPeriod(runProfile);

            Date planningDate = runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod().getStart();

            List<InterventionPlanRun> interventionPlanRuns = retrieveInterventionPlans.retrieveInterventionPlanData(runProfile.getClientId(), lookBackDate, planningDate, 4);

            logWriter.info("InterventionPlanRuns:" + interventionPlanRuns);
            List<Integer> interventionPlanRunIds = interventionPlanRuns.stream().map(interventionPlanRun -> interventionPlanRun.getInterventionPlanRunId()).collect(Collectors.toList());

            List<InterventionPlan> interventionPlans = new ArrayList<>();
            logWriter.info("InterventionPlanRunIds:" + interventionPlanRunIds);
            if (interventionPlanRunIds != null && interventionPlanRunIds.size() > 0)
                interventionPlans = interventionPlanService.getInterventionPlanData(interventionPlanRunIds);

            List<MemberEvidence> memberEvidences = memberEvidenceService.retrieveMemberEvidencesForMemberAttributes(gapSetId, memberIds);

            logWriter.info("MemberEvidences:" + memberEvidences);
            List<PatientProfile> patientProfiles = patientProfileStaging.stagePatientProfile(memberIds, runProfile);

            memberEvidences.sort(Comparator.naturalOrder());

            logWriter.info("Staging member evidence successfully to the last memberId = " + memberIds.get(memberIds.size() - 1));
            for (int memberId : memberIds) {
                StagingMessage stagingMessage = new StagingMessage();
                System.out.println("currently processing memberId "+memberId);
                stagingMessage.setRunProfileId(runProfileId);
                stagingMessage.setInterventionPlans(interventionPlans);
                stagingMessage.setMemberAttributesRunId(memberAttributesRunId);
                List<MemberEvidence> localMemberEvidences = memberEvidences.stream().filter(p -> p.getMemberId() == memberId).collect(Collectors.toList());
                stagingMessage.setMemberEvidences(localMemberEvidences);
                PatientProfile localPatientProfile = patientProfiles.stream().filter(p -> p.getMemberId() == memberId).findAny().orElse(null);
                stagingMessage.setPatientProfile(localPatientProfile);
                if (localPatientProfile != null) {
                    List<String> clientProviderIds = localPatientProfile.getEnrollments().stream().map(enrollment -> enrollment.getClientProviderId()).collect(Collectors.toList());
                    List<ProviderProfile> providerProfiles = providerProfileStaging.stageProviderProfile(clientProviderIds, runProfile);
                    stagingMessage.setProviderProfiles(providerProfiles);
                }
                WorkerProcessMessage workerProcessMessage = workFlowManager.workFlowController(stagingMessage, workerInputMessage.getUserInfo(), cacheUtil);
                persistentManager.persistWorkerProcess(workerProcessMessage);
            }

            ouputMessageAvro.setStatusDetail("Batch was successfully processed!");
            ouputMessageAvro.setMessageStatus(true);

        } catch (Exception ex) {
            logWriter.error(String.format("Worker failed for RunProfile :%s RunId : %s BatchId: %s", workerInputMessage.getRunProfileId(), workerInputMessage.getRunId(), workerInputMessage.getBatchId()));
            logWriter.error(Arrays.toString(ex.getStackTrace()));
            logWriter.error(ex.toString());
            String error = String.format("Error: %s | StaceTrace: %s", ex.toString(), Arrays.toString(ex.getStackTrace()));
            ouputMessageAvro.setStatusDetail(error);
        } finally {
            if (workerInputMessage.getRunId() != 0) {//called from mgr
                messageBusProducer.publishMessage(ouputMessageAvro);
            } else { // called directly
                interventionConfigurationService.updateRunStatus(memberAttributesRunId, Status.COMPLETE);
                ouputMessageAvro.setRunId(memberAttributesRunId);
            }
        }

        return ouputMessageAvro;
    }


}

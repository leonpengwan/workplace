package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao.MemberAttributeDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class MemberAttributesServiceImpl implements MemberAttributesService {
    @Autowired
    private MemberAttributeDao memberAttributeDao;

    @Override
    public int persistMemberAttributes(MemberAttribute memberAttribute, String userInfo) {
        try {
            if (memberAttribute == null) {
                System.out.println("json body empty for persist member attributes");
                return 1;
            } else {
               return  memberAttributeDao.saveMemberAttribute(memberAttribute,userInfo);
            }
        } catch (DataIntegrityViolationException violationException) {
            System.out.println("MemberAttributes Persistence: MemberAttributes for member id: " + memberAttribute.getMemberId()
                    + " and MemberAttributesrunId: " + memberAttribute.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        } catch (Exception e) {
            e.printStackTrace();
            return 99;
        }
    }
}

package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.config.ApplicationConfiguration;
import com.inovalon.riskadjustment.memberattributes.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.model.enums.MicroserviceType;
import com.inovalon.riskadjustment.model.enums.Status;
import com.inovalon.riskadjustment.model.servicemodel.common.RunTableModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InterventionConfigurationService {
    @Autowired
    private ApplicationConfiguration applicationConfiguration;
    @Autowired
    private Gateway gateway;
    @Autowired
    private LogWriter logWriter;

    /**
     * Gets runId based on runProfileId.
     *
     * @param runProfileId     runProfileId
     * @param microserviceType Enum Type of microserviceType
     * @return runId.
     */
    public Integer retrieveRunIdByRunProfileId(long runProfileId, MicroserviceType microserviceType) {

        int runId = 0;
        logWriter.info("Getting runId for runProfileId: " + runProfileId + " of Type:" + microserviceType.toString());


        String url = applicationConfiguration.getConfigurationDatabaseServiceBaseUrl()
                .concat("/configdbservice")
                .concat("/runs")
                .concat("?type=").concat(microserviceType.toString())
                .concat("&runProfileId=").concat(String.valueOf(runProfileId));

        System.out.println("calling...:" + url);

        RunTableModel runTableModel = gateway.getData(url, RunTableModel.class);

        runId = runTableModel.getRunId();

        return runId;
    }
    /**
     * Sets the run Id to 'In progress/Complete' status
     *
     * @param runId  runId
     * @param status Status type enum
     */
    public void updateRunStatus(int runId, Status status) {

        logWriter.info("Setting status of runId:" + runId + " to " + status.toString());

        String url = applicationConfiguration.getConfigurationDatabaseServiceBaseUrl()
                .concat("/configdbservice")
                .concat("/setRunStatusAndRetrieveRunProfileId")
                .concat("?microserviceType=").concat(MicroserviceType.MEMBER_ATTRIBUTES.toString())
                .concat("&runId=").concat(String.valueOf(runId))
                .concat("&status=").concat(status.toString());
        logWriter.info("calling ..." + url);

        gateway.getData(url, Integer.class);

    }

    }

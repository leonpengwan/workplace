package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.dataacess.repository.planresultdb.dao.InterventionPlanDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class InterventionPlanServiceImpl implements InterventionPlanService {

    @Autowired
    private InterventionPlanDao interventionPlanDao;


    public List<InterventionPlan> getInterventionPlanData(List<Integer> interventionPlanRunIds) throws SQLException {
        return interventionPlanDao.findByInterventionPlanRunIdIn(interventionPlanRunIds);
    }

}

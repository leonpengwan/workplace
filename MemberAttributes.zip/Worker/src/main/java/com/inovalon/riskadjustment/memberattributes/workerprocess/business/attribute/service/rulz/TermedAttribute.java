package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;


@Service("TermedAttribute")
public class TermedAttribute implements MemberProfileRealization {
    @Autowired
    private LogWriter logWriter;

    /*private static final String pattern = "yyyy-MM-dd HH:mm:ss";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(pattern);*/

    /**
     * Set Termed status= true when EndDate from PatientProfile < planningMonthEndDate
     *
     * @param runProfile
     * @param stagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage stagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        try {
            PatientProfile patientProfile = stagingMessage.getPatientProfile();
            if (memberAttribute.getPlanningMonthStartDate() == null) {
                return;
            }

            //List<Enrollment> enrollments = patientProfile.getEnrollments();

            //for (Enrollment enrollment : patientProfile.getEnrollments()) {
            Enrollment enrollment = patientProfile.getEnrollments().iterator().next();
            Date coverageEndDate = StringToDate.getDate(enrollment.getCoverageEndDate());

            if (coverageEndDate != null) {
                if (coverageEndDate.before(memberAttribute.getPlanningMonthEndDate())) {
                    memberAttribute.setTermed(true);
                }
            }

            //}
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }
    }
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.exception;

public class RangException extends Exception {

    public RangException() {
    }

    public RangException(String message) {
        super(message);
    }

    public RangException(String message, Throwable cause) {
        super(message, cause);
    }

    public RangException(Throwable cause) {
        super(cause);
    }

    public RangException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}

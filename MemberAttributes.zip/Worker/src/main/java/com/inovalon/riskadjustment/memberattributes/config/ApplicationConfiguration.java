package com.inovalon.riskadjustment.memberattributes.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerOuputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.business.Gateway;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.MemberAttributeIdentificationFactory;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.MemberProfileRealizationFactory;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import com.inovalon.riskadjustment.shared.messagebus.producer.KafkaMessageBusPublisher;
import org.redisson.client.codec.Codec;
import org.redisson.codec.SerializationCodec;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ServiceLocatorFactoryBean;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.IOException;
import java.util.ArrayList;

@Configuration
@RefreshScope
@EnableSwagger2
public class ApplicationConfiguration {

    @Value("${inovalon.risk-adjustment.data-services.configuration-url}")
    private String configurationDatabaseServiceBaseUrl;

    @Value("${spring.kafka.producer.topic}")
    private String kafkaProducerTopic;

    @Value("${inovalon.risk-adjustment.input-batch-size}")
    private int inBatchSize;

    @Value("${inovalon.platform-services.patient-profile-url}")
    private String patientProviderProfileServiceBaseUrl;

    @Value("${spring.kafka.consumer.topic}")
    private String kafkaConsumerTopic;

    private Codec codec = new SerializationCodec();


    @Bean
    public FactoryBean rulesLocatorFactoryBean() {
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(MemberProfileRealizationFactory.class);
        return factoryBean;
    }

    @Bean
    public FactoryBean attributeLocatorFactoryBean() {
        ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(MemberAttributeIdentificationFactory.class);
        return factoryBean;
    }


    public String getPatientProviderProfileServiceBaseUrl() {
        return this.patientProviderProfileServiceBaseUrl;
    }



    public String getConfigurationDatabaseServiceBaseUrl() {
        return configurationDatabaseServiceBaseUrl;
    }



    public String getKafkaProducerTopic() {
        return kafkaProducerTopic;
    }


    @Bean
    public Gateway gateway() {
        return new Gateway() {
            @Override
            public <T> T getData(String url, TypeReference<T> type) throws IOException {
                return super.getData(url, type);
            }
        };
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public MessageBusPublisher<WorkerOuputMessageAvro> messageBusPublisher() {
        return new KafkaMessageBusPublisher<>(WorkerOuputMessageAvro.class);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }


    @Bean
    public HttpHeaders header() {
        return new HttpHeaders();
    }

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.inovalon.riskadjustment"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo());
    }
    private ApiInfo apiInfo(){

        return     new ApiInfo("Member Attributes Service API",
                "This Api exposes a method to trigger Member Attributes Service.",
                "1.0", "urn:tos",
                new Contact("NextGenRiskAdjustment", "http://mednet/tech/swd/raci/NextGen/SitePages/Home.aspx", "NextGenRiskAdjustment-DEVTeam@inovalon.com"),
                "Inovalon", "http://www.inovalon.com", new ArrayList());
    }

    @Override
    public String toString() {
        return "ApplicationConfiguration{" +
                "configurationDatabaseServiceBaseUrl='" + configurationDatabaseServiceBaseUrl + '\'' +
                ", kafkaProducerTopic='" + kafkaProducerTopic + '\'' +
                ", inBatchSize=" + inBatchSize +
                ", patientProviderProfileServiceBaseUrl='" + patientProviderProfileServiceBaseUrl + '\'' +
                ", kafkaConsumerTopic='" + kafkaConsumerTopic + '\'' +
                ", codec=" + codec +
                '}';
    }
}

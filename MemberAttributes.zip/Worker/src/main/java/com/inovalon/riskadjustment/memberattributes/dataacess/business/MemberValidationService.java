package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;

public interface MemberValidationService {
    int persistMemberValidation(MemberValidation memberValidation, String userInfo);
}

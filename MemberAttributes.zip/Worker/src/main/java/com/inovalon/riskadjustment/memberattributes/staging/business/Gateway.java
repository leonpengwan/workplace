package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public abstract class Gateway {

    @Autowired
    private Environment env;

    private RestTemplate restTemplate = new RestTemplate();

    @PostConstruct
    public void setRestTemplate() {
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        // Need to define this in Property file
        RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(2000).setConnectTimeout(2000)
                .setSocketTimeout(2000).setStaleConnectionCheckEnabled(false).build();
        SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setTcpNoDelay(true).build();
        // Need to define this in Property file
        PoolingHttpClientConnectionManager poolingHttpClientConnectionManager = new PoolingHttpClientConnectionManager();
        poolingHttpClientConnectionManager.setMaxTotal(800);
        poolingHttpClientConnectionManager.setDefaultMaxPerRoute(700);

        CloseableHttpClient httpClientBuilder = HttpClientBuilder.create()
                .setConnectionManager(poolingHttpClientConnectionManager).setDefaultRequestConfig(requestConfig)
                .setDefaultSocketConfig(socketConfig).build();

        requestFactory.setHttpClient(httpClientBuilder);
        restTemplate = new RestTemplate(requestFactory);
        //restTemplate.setMessageConverters ( messageConverters() );
    }

    private List<HttpMessageConverter<?>> messageConverters() {
        List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
        converters.add(jsonMessageConverter());
        return converters;
    }

    private HttpMessageConverter jsonMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new JSR310Module());
        converter.setObjectMapper(objectMapper);
        return converter;
    }


    /**
     * @param url
     * @param classz
     * @param <T>
     */
    public <T> T getData(String url, Class<T> classz) {

        ResponseEntity<T> responseEntity = null;
        try {
            responseEntity = restTemplate.getForEntity(url, classz);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return responseEntity.getBody();
    }


    public <T> T postData(String url, String jsonString, Class<T> classz) {
        HttpEntity httpEntity = getHttpEntity(jsonString);
        ResponseEntity<T> responseEntity = restTemplate.postForEntity(url, httpEntity, classz);

        return responseEntity.getBody();
    }

    public void putData(String url, String jsonSting) {
        HttpEntity httpEntity = getHttpEntity(jsonSting);
        restTemplate.put(url, httpEntity);
    }

    protected String getRequestData(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public <T> T getData(String url, TypeReference<T> type) throws IOException {
        try {
            ObjectMapper objectMapper = getObjectMapper();
            ResponseEntity<String> responseEntity = restTemplate.getForEntity(url, String.class);
            return objectMapper.readValue(responseEntity.getBody(), type);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }

    public <T> T getObjectFromString(String json, com.fasterxml.jackson.core.type.TypeReference<T> type) throws Exception {
        ObjectMapper objectMapper = getObjectMapper();
        return objectMapper.readValue(json, type);
    }

    public HttpEntity<String> getHttpEntity(String jsonString) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = jsonString == null ? new HttpEntity<String>(httpHeaders) : new HttpEntity<String>(jsonString, httpHeaders);
        return entity;
    }
}

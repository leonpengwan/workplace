package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.model.servicemodel.cache.GroupPlanType;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service("GroupPlanType")
public class GroupPlanTypeService implements MemberAttributeIdentification {
    @Autowired
    private LogWriter logWriter;

    /**
     * This class mainly used to set the Plan group type
     *
     * @param runProfile
     * @param patientProfile
     * @param memberAttribute
     * @param cacheUtil
     * @throws RangException
     */
    @LogBeforeEvents
    @Override
    public void setAttributeValue(RunProfile runProfile, PatientProfile patientProfile, MemberAttribute memberAttribute, CacheUtil cacheUtil) throws RangException {
        try{
            logWriter.info("Beginning of GroupPlanTypeService");
            List<GroupPlanType> groupPlanTypeList = cacheUtil.getGroupPlanTypes();
            Set<Enrollment> enrollments = patientProfile.getEnrollments();
            //GroupPlanType grpPlanType = groupPlanTypeList.stream().filter(groupPlanType -> groupPlanType.getGroupPlanTypeName().equalsIgnoreCase(enrollments.get(0).toString())).findAny().orElse(null);
            memberAttribute.setGroupPlanType(groupPlanTypeList.get(0).getGroupPlanTypeName());
            logWriter.info("Ending of GroupPlanTypeService");
        }catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            throw new RangException(ex);
        }
    }
}

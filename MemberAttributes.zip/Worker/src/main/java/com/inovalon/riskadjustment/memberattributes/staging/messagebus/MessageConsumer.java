package com.inovalon.riskadjustment.memberattributes.staging.messagebus;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerInputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.business.Manager;
import com.inovalon.riskadjustment.shared.messagebus.consumer.KafkaMessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.enums.MessageAcknowledgment;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusListener;
import com.inovalon.riskadjustment.shared.messagebus.model.MessageMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.Duration;
import java.time.Instant;

@Component
public class MessageConsumer implements MessageBusListener<WorkerInputMessageAvro> {

    @Autowired
    private KafkaMessageBusListener<WorkerInputMessageAvro> kafkaMessageBusListener;

    @PostConstruct
    public void Initialize(){
        kafkaMessageBusListener.subscribe(this, WorkerInputMessageAvro.class);
    }

    @Autowired
    private LogWriter logWriter;

    @Autowired
    private Manager manager;

    @Override
    public MessageAcknowledgment OnQueueMessageReceived(WorkerInputMessageAvro workerInputMessage, MessageMetadata messageMetadata) {

        Instant begginning = Instant.now();
        logWriter.debug("Message : " + workerInputMessage.toString());
        logWriter.info("Message received : " + messageMetadata.toString());
        logWriter.info(String.format("Worker received a message! RunProfileId:%s BatchId:%s",workerInputMessage.getRunProfileId(), workerInputMessage.getBatchId()));

        if (workerInputMessage != null) {
            Instant ending = Instant.now();
            workerInputMessage.setStatusDetail(workerInputMessage.getStatusDetail() + "| Time taken:" + (Duration.between(begginning,ending)));
            manager.processInputBatchMessage(workerInputMessage);

            System.out.println("Total taken to complete current batch execution" +(Duration.between(begginning,ending)));
        } else {
            logWriter.warn("Wroker: kafka queue consumed a null avro message");
        }
        //commit always
        return MessageAcknowledgment.Commit;
    }
}

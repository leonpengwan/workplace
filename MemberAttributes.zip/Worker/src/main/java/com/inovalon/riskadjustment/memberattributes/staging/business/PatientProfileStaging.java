package com.inovalon.riskadjustment.memberattributes.staging.business;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.config.ApplicationConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.PatientProfilePayload;
import com.inovalon.riskadjustment.memberattributes.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class PatientProfileStaging {
    @Autowired
    private ApplicationConfiguration applicationConfiguration;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;

    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the list of patient profile based on memberIds
     *
     * @param memberIds
     * @param runProfile *
     * @return It returns list of patientProfile
     * @throws Exception
     */
    @LogBeforeEvents
    //@RetryOnException(maxAttempts = 3, retryDelay = 1000)
    public List<PatientProfile> stagePatientProfile(List<Integer> memberIds, RunProfile runProfile ) throws Exception {
        logWriter.info("Beginning of stagePatientProfile");
        List<PatientProfile> patientProfiles = new ArrayList<>();

        try {
            PatientProfilePayload patientProfilePayload = new PatientProfilePayload();
            patientProfilePayload.ids = memberIds;
            patientProfilePayload.clientShortName = runProfile.getClientShortName();
            patientProfilePayload.projectShortName = runProfile.getProjectShortName();

            String url = applicationConfiguration.getPatientProviderProfileServiceBaseUrl() + MemberAttributesConstants.GET_FULL_PATIENT_PROFILE;
            String json = objectMapper.writeValueAsString(patientProfilePayload);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(json, headers);



            ResponseEntity<List<PatientProfile>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<PatientProfile>>() {
            });
            patientProfiles = responseEntity.getBody();
            logWriter.info("Ending of stagePatientProfile");
        }
         catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
            throw ex;
        }
        return patientProfiles;
    }
}

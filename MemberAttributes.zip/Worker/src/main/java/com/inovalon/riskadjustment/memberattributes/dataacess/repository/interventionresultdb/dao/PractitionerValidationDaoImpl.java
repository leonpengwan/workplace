package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PractitionerValidationDaoImpl implements PractitionerValidationDao {

    private final static String INSERT_QUERY = "insert into dbo.PractitionerValidation " +
            "(MemberAttributesRunId,PractitionerId,InvalidName,InvalidAddress,InvalidPhone,InvalidFax,CreatedBy,ModifiedBy) values(?,?,?,?,?,?,?,?)";
    @Autowired
    @Qualifier("interventionResultJdbcTemplate")
    private JdbcTemplate internvetionPlanResultTemplate;

    @Override
    public int savePratcitionerValidation(PractitionerValidation practitionerValidation, String userInfo) {
        Object[] params = new Object[]{practitionerValidation.getMemberAttributesRunId(), practitionerValidation.getPractitionerId(), practitionerValidation.isInvalidName(), practitionerValidation.isInvalidAddress(),practitionerValidation.isInvalidPhone(), practitionerValidation.isInvalidFax(),userInfo,userInfo};
        int id = internvetionPlanResultTemplate.update(INSERT_QUERY, params);
        return id;
    }
}

package com.inovalon.riskadjustment.memberattributes.staging.messagebus;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerOuputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.config.ApplicationConfiguration;
import com.inovalon.riskadjustment.shared.messagebus.interfaces.MessageBusPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class MessageProducer {

    @Autowired
    private LogWriter logWriter;

    @Autowired
    private ApplicationConfiguration applicationConfiguration;

    @Autowired
    @Qualifier("messageBusPublisher")
    private MessageBusPublisher<WorkerOuputMessageAvro> messageBusPublisher;

    public void publishMessage(WorkerOuputMessageAvro workerProcessMessageAvro) {
        logWriter.info("Publishing Message to topic: " + applicationConfiguration.getKafkaProducerTopic());

        messageBusPublisher.publishMessage(applicationConfiguration.getKafkaProducerTopic(), workerProcessMessageAvro);

    }
}

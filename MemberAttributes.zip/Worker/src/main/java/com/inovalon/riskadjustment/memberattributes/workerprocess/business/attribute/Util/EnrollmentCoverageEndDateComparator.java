package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.Util;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;

import java.util.Comparator;
import java.util.Date;

public class EnrollmentCoverageEndDateComparator implements Comparator<Enrollment> {

    public int compare(Enrollment enrollment1, Enrollment enrollment2) {
        Date date1 = StringToDate.getDate(enrollment1.getCoverageEndDate());
        Date date2 = StringToDate.getDate(enrollment2.getCoverageEndDate());
        //descending order
        return date2.compareTo(date1);
    }
}

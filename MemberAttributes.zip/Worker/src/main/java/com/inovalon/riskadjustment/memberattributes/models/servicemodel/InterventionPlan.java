package com.inovalon.riskadjustment.memberattributes.models.servicemodel;


public class InterventionPlan {
    private long interventionPlanId;
    private int interventionPlanRunId;
    private int memberId;
    private String personId;
    private int interventionYear;
    private int interventionMonth;
    private int interventionTypeId;
    private String interventionPrefix;

    public InterventionPlan() {
    }

    public InterventionPlan(long interventionPlanId, int interventionPlanRunId, int memberId, String personId, int interventionYear, int interventionMonth, int interventionTypeId, String interventionPrefix) {
        this.interventionPlanId = interventionPlanId;
        this.interventionPlanRunId = interventionPlanRunId;
        this.memberId = memberId;
        this.personId = personId;
        this.interventionYear = interventionYear;
        this.interventionMonth = interventionMonth;
        this.interventionTypeId = interventionTypeId;
        this.interventionPrefix = interventionPrefix;
    }

    public long getInterventionPlanId() {
        return interventionPlanId;
    }

    public void setInterventionPlanId(long interventionPlanId) {
        this.interventionPlanId = interventionPlanId;
    }

    public int getInterventionPlanRunId() {
        return interventionPlanRunId;
    }

    public void setInterventionPlanRunId(int interventionPlanRunId) {
        this.interventionPlanRunId = interventionPlanRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public int getInterventionYear() {
        return interventionYear;
    }

    public void setInterventionYear(int interventionYear) {
        this.interventionYear = interventionYear;
    }

    public int getInterventionMonth() {
        return interventionMonth;
    }

    public void setInterventionMonth(int interventionMonth) {
        this.interventionMonth = interventionMonth;
    }

    public int getInterventionTypeId() {
        return interventionTypeId;
    }

    public void setInterventionTypeId(int interventionTypeId) {
        this.interventionTypeId = interventionTypeId;
    }

    public String getInterventionPrefix() {
        return interventionPrefix;
    }

    public void setInterventionPrefix(String interventionPrefix) {
        this.interventionPrefix = interventionPrefix;
    }
}

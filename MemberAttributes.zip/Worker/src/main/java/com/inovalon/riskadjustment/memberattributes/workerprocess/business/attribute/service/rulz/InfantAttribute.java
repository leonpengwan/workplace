package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

@Service("InfantAttribute")
public class InfantAttribute implements MemberProfileRealization {
    @Autowired
    private LogWriter logWriter;

    /*private static final String pattern = "yyyy-MM-dd HH:mm:ss";
    private final static DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);*/

    /**
     * Set the Infant MemberStatus
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        //TODO: Making note that this rule is applicable for HIX clients as per PBI #22166 description
        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();
        Date dob = StringToDate.getDate(patientProfile.getBirthDate());
        try {
            if (dob != null) {
//                LocalDate birthDate = LocalDate.parse(dob, formatter);
                LocalDate birthDate = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate planningStartDate = memberAttribute.getPlanningMonthStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                long age = calculateAgeBetweenTwoDates(birthDate, planningStartDate);

                if (age < 3) {
                    memberAttribute.setAgeExclusionLessThan3(Boolean.TRUE);
                }
            }
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }
        // TODO: Need to check if we need to set infant status when there is no birthdate
        System.out.println("getInfantByMemberId completed");
    }


    /**
     * Calculates years difference between 2 dates
     *
     * @param birthDate
     * @param planningStartDate
     * @return long
     */
    private long calculateAgeBetweenTwoDates(LocalDate birthDate, LocalDate planningStartDate) {
        return ChronoUnit.YEARS.between(birthDate, planningStartDate);
    }
}
package com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute;


public class Validation {
    private MemberValidation memberValidation;
    private PractitionerValidation practitionerValidation;

    public Validation() {
    }

    public MemberValidation getMemberValidation() {
        return memberValidation;
    }

    public void setMemberValidation(MemberValidation memberValidation) {
        this.memberValidation = memberValidation;
    }

    public PractitionerValidation getPractitionerValidation() {
        return practitionerValidation;
    }

    public void setPractitionerValidation(PractitionerValidation practitionerValidation) {
        this.practitionerValidation = practitionerValidation;
    }


}

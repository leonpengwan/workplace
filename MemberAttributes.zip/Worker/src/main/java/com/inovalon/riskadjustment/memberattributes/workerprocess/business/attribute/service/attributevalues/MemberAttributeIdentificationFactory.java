package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import org.springframework.stereotype.Component;

@Component
public interface MemberAttributeIdentificationFactory {

    public MemberAttributeIdentification getMemberAttributeIdentifiaction(String memberAttributeBean);
}

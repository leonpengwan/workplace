package com.inovalon.riskadjustment.memberattributes.dataacess.repository.planresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;

import java.sql.SQLException;
import java.util.List;


public interface InterventionPlanDao {

    public List<InterventionPlan> findByInterventionPlanRunIdIn(List<Integer> interventionPlanRunIds) throws SQLException;
}



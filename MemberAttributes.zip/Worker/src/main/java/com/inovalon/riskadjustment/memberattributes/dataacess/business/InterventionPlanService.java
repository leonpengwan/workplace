package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;

import java.util.List;


public interface InterventionPlanService {

    public List<InterventionPlan> getInterventionPlanData(List<Integer> interventionPlanRunIds) throws Exception;
}

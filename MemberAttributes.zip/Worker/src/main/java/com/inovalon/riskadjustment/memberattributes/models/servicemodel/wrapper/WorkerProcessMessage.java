package com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;

import java.util.List;

public class WorkerProcessMessage {
    private long runProfileId;
    private int memberAttributesRunId;
    private MemberAttribute memberAttribute;
    private List<MemberEvidenceStatus> memberEvidenceStatuses;
    private MemberValidation memberValidation;
    private PractitionerValidation practitionerValidation;
    private String userInfo;

    public WorkerProcessMessage() {
    }

    public WorkerProcessMessage(long runProfileId, int memberAttributesRunId, MemberAttribute memberAttribute, List<MemberEvidenceStatus> memberEvidenceStatuses, MemberValidation memberValidation, PractitionerValidation practitionerValidation, String userInfo) {
        this.runProfileId = runProfileId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.memberAttribute = memberAttribute;
        this.memberEvidenceStatuses = memberEvidenceStatuses;
        this.memberValidation = memberValidation;
        this.practitionerValidation = practitionerValidation;
        this.userInfo = userInfo;
    }

    public PractitionerValidation getPractitionerValidation() {
        return practitionerValidation;
    }

    public void setPractitionerValidation(PractitionerValidation practitionerValidation) {
        this.practitionerValidation = practitionerValidation;
    }

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public MemberAttribute getMemberAttribute() {
        return memberAttribute;
    }

    public void setMemberAttribute(MemberAttribute memberAttribute) {
        this.memberAttribute = memberAttribute;
    }

    public void setMemberAttributes(MemberAttribute memberAttribute) {
        this.memberAttribute = memberAttribute;
    }

    public List<MemberEvidenceStatus> getMemberEvidenceStatuses() {
        return memberEvidenceStatuses;
    }

    public void setMemberEvidenceStatuses(List<MemberEvidenceStatus> memberEvidenceStatuses) {
        this.memberEvidenceStatuses = memberEvidenceStatuses;
    }

    public MemberValidation getMemberValidation() {
        return memberValidation;
    }

    public void setMemberValidation(MemberValidation memberValidation) {
        this.memberValidation = memberValidation;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }
}

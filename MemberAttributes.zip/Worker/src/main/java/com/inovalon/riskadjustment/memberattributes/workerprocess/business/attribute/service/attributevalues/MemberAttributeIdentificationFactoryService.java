package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberAttributeIdentificationFactoryService {


    @Autowired
    private MemberAttributeIdentificationFactory memberAttributeIdentificationFactory;


    public MemberAttributeIdentification beanRequest(AttributeBeansEnum rulzBeanEnum){
        MemberAttributeIdentification memberProfileRealization = memberAttributeIdentificationFactory.getMemberAttributeIdentifiaction(rulzBeanEnum.getValue());
        return memberProfileRealization;
    }

}
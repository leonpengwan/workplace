package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao.PractitionerValidationDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class PractitionerValidationServiceImpl implements PractitionerValidationService {
    @Autowired
    private PractitionerValidationDao practitionerValidationDao;

    @Override
    public int persistPractitionerValidation(PractitionerValidation practitionerValidation, String userInfo) {
        try {
            if (practitionerValidation == null) {
                System.out.println("json body empty for persist practitioner validation");
                return 1;
            } else {

                practitionerValidationDao.savePratcitionerValidation(practitionerValidation,userInfo);
                return 0;
            }
        } catch (DataIntegrityViolationException violationException) {
            System.out.println("MemberAttributes Persistence: PractitionerValidation for member id: " + practitionerValidation.getPractitionerId()
                    + " and MemberAttributesRunId: " + practitionerValidation.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        } catch (Exception e) {
            e.printStackTrace();
            return 99;
        }
    }
}

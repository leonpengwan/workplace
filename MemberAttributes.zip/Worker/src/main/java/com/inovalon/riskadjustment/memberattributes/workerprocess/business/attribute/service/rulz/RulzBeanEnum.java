package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

public enum RulzBeanEnum {

    Termed("TermedAttribute"),
    CurrentlyEnrollment("CurrentlyEnrolledAttribute"),
    Infant("InfantAttribute"),
    Conditional("ConditionalAttribute"),
    PreviousIntervention("PreviousIntervention"),
    Hospice("HospiceIndicatorAttribute"),
    HomeBound("HomeBoundAttribute"),
    NewEnrollee("NewEnrolleeAttribute"),
    PractitionerVisit("PractitionerVisit");

    private String beanName;

    RulzBeanEnum(String termedService) {
        this.beanName = termedService;
    }

    public String getValue() {
        return this.beanName;
    }


}

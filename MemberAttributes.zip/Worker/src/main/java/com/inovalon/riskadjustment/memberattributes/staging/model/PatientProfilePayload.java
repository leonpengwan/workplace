package com.inovalon.riskadjustment.memberattributes.staging.model;

/**
 * Created by kraju on 1/30/2018.
 */
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class PatientProfilePayload {

  @JsonProperty(value = "clientShortName")
  public String clientShortName;

   @JsonProperty(value = "projectShortName")
   public String projectShortName;
   @JsonProperty(value = "ids")
   public List<Integer> ids;
}

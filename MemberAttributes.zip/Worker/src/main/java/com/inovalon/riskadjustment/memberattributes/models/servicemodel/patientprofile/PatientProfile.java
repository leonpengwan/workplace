package com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile;

import java.util.List;
import java.util.Set;

public class PatientProfile {

    private int memberId;
    private String clientMemberId;
    private String fullName;
    private String firstName;
    private String middleName;
    private String lastName;
    private String birthDate;
    private String genderCode;
    private String ssn;
    private String maritalStatus;
    private String deceasedDate;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String county;
    private String stateCode;
    private String zip;
    private String locationUsageTypeCode;
    private String locationUsagePreferenceCode;
    private String emailAddress;
    private String emailUsageTypeCode;
    private String emailUsagePreferenceCode;
    private String phoneNumber;
    private String phoneNumber2;
    private String phoneUsageTypeCode;
    private String phoneUsagePreferenceCode;
    private String ethnicityCode;
    private String ethnicityType;
    private String ethnicitySource;
    private String raceType;
    private String languagesSpoken;
    private String languagesWritten;
    private String languageOther;
    private String languageSpokenSource;
    private String languageWrittenSource;
    private String languageOtherSource;
    private String languageUsageTypeCode;
    private String languageUsagePreferenceCode;
    private String subscriberKey;
    private String medicaidId;
    private String memberIdentifier1;
    private String memberIdentifier2;
    private String memberIdentifier3;
    private String memberIdentifier4;
    private String memberIdentifier5;
    private String memberIdentifier6;
    private String memberIdentifier7;
    private String memberIdentifier8;
    private String memberIdentifier9;
    private String memberIdentifier10;
    private String memberIdentifier11;
    private String memberIdentifier12;
    private String memberIdentifier13;
    private String memberIdentifier14;
    private String memberIdentifier15;
    private String memberIdentifier16;
    private String memberIdentifier17;
    private String memberIdentifier18;
    private String memberIdentifier19;
    private String memberIdentifier20;
    private String feedInstanceId;
    private String udfActiveInd;

    private List<Claim> claims;
    private List<RxClaim> rxClaims;
    private List<LabClaim> labClaims;
    private Set<Enrollment> enrollments;

    public PatientProfile(){}

    public PatientProfile(int memberId, String clientMemberId, String fullName, String firstName, String middleName, String lastName, String birthDate, String genderCode, String ssn, String maritalStatus, String deceasedDate, String addressLine1, String addressLine2, String city, String county, String stateCode, String zip, String locationUsageTypeCode, String locationUsagePreferenceCode, String emailAddress, String emailUsageTypeCode, String emailUsagePreferenceCode, String phoneNumber, String phoneNumber2, String phoneUsageTypeCode, String phoneUsagePreferenceCode, String ethnicityCode, String ethnicityType, String ethnicitySource, String raceType, String languagesSpoken, String languagesWritten, String languageOther, String languageSpokenSource, String languageWrittenSource, String languageOtherSource, String languageUsageTypeCode, String languageUsagePreferenceCode, String subscriberKey, String medicaidId, String memberIdentifier1, String memberIdentifier2, String memberIdentifier3, String memberIdentifier4, String memberIdentifier5, String memberIdentifier6, String memberIdentifier7, String memberIdentifier8, String memberIdentifier9, String memberIdentifier10, String memberIdentifier11, String memberIdentifier12, String memberIdentifier13, String memberIdentifier14, String memberIdentifier15, String memberIdentifier16, String memberIdentifier17, String memberIdentifier18, String memberIdentifier19, String memberIdentifier20, String feedInstanceId, String udfActiveInd, List<Claim> claims, List<RxClaim> rxClaims, List<LabClaim> labClaims, Set<Enrollment> enrollments) {
        this.memberId = memberId;
        this.clientMemberId = clientMemberId;
        this.fullName = fullName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.genderCode = genderCode;
        this.ssn = ssn;
        this.maritalStatus = maritalStatus;
        this.deceasedDate = deceasedDate;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.county = county;
        this.stateCode = stateCode;
        this.zip = zip;
        this.locationUsageTypeCode = locationUsageTypeCode;
        this.locationUsagePreferenceCode = locationUsagePreferenceCode;
        this.emailAddress = emailAddress;
        this.emailUsageTypeCode = emailUsageTypeCode;
        this.emailUsagePreferenceCode = emailUsagePreferenceCode;
        this.phoneNumber = phoneNumber;
        this.phoneNumber2 = phoneNumber2;
        this.phoneUsageTypeCode = phoneUsageTypeCode;
        this.phoneUsagePreferenceCode = phoneUsagePreferenceCode;
        this.ethnicityCode = ethnicityCode;
        this.ethnicityType = ethnicityType;
        this.ethnicitySource = ethnicitySource;
        this.raceType = raceType;
        this.languagesSpoken = languagesSpoken;
        this.languagesWritten = languagesWritten;
        this.languageOther = languageOther;
        this.languageSpokenSource = languageSpokenSource;
        this.languageWrittenSource = languageWrittenSource;
        this.languageOtherSource = languageOtherSource;
        this.languageUsageTypeCode = languageUsageTypeCode;
        this.languageUsagePreferenceCode = languageUsagePreferenceCode;
        this.subscriberKey = subscriberKey;
        this.medicaidId = medicaidId;
        this.memberIdentifier1 = memberIdentifier1;
        this.memberIdentifier2 = memberIdentifier2;
        this.memberIdentifier3 = memberIdentifier3;
        this.memberIdentifier4 = memberIdentifier4;
        this.memberIdentifier5 = memberIdentifier5;
        this.memberIdentifier6 = memberIdentifier6;
        this.memberIdentifier7 = memberIdentifier7;
        this.memberIdentifier8 = memberIdentifier8;
        this.memberIdentifier9 = memberIdentifier9;
        this.memberIdentifier10 = memberIdentifier10;
        this.memberIdentifier11 = memberIdentifier11;
        this.memberIdentifier12 = memberIdentifier12;
        this.memberIdentifier13 = memberIdentifier13;
        this.memberIdentifier14 = memberIdentifier14;
        this.memberIdentifier15 = memberIdentifier15;
        this.memberIdentifier16 = memberIdentifier16;
        this.memberIdentifier17 = memberIdentifier17;
        this.memberIdentifier18 = memberIdentifier18;
        this.memberIdentifier19 = memberIdentifier19;
        this.memberIdentifier20 = memberIdentifier20;
        this.feedInstanceId = feedInstanceId;
        this.udfActiveInd = udfActiveInd;
        this.claims = claims;
        this.rxClaims = rxClaims;
        this.labClaims = labClaims;
        this.enrollments = enrollments;
    }

    public List<Claim> getClaims() {
        return claims;
    }

    public void setClaims(List<Claim> claims) {
        this.claims = claims;
    }

    public List<RxClaim> getRxClaims() {
        return rxClaims;
    }

    public void setRxClaims(List<RxClaim> rxClaims) {
        this.rxClaims = rxClaims;
    }

    public List<LabClaim> getLabClaims() {
        return labClaims;
    }

    public void setLabClaims(List<LabClaim> labClaims) {
        this.labClaims = labClaims;
    }

    public Set<Enrollment> getEnrollments() {
        return enrollments;
    }

    public void setEnrollments(Set<Enrollment> enrollments) {
        this.enrollments = enrollments;
    }

    /**
     * Sets new labClaimInputs.
     *
     * @param labClaimInputs New value of labClaimInputs.
     */
//    public void setLabClaimInputs(List<LabClaimObject> labClaimInputs) {
//        this.labClaimInputs = labClaimInputs;
//    }

    /**
     * Sets new subscriberKey.
     *
     * @param subscriberKey New value of subscriberKey.
     */
    public void setSubscriberKey(String subscriberKey) {
        this.subscriberKey = subscriberKey;
    }

    /**
     * Gets ethnicitySource.
     *
     * @return Value of ethnicitySource.
     */
    public String getEthnicitySource() {
        return ethnicitySource;
    }

    /**
     * Gets memberIdentifier2.
     *
     * @return Value of memberIdentifier2.
     */
    public String getMemberIdentifier2() {
        return memberIdentifier2;
    }

    /**
     * Sets new phoneUsageTypeCode.
     *
     * @param phoneUsageTypeCode New value of phoneUsageTypeCode.
     */
    public void setPhoneUsageTypeCode(String phoneUsageTypeCode) {
        this.phoneUsageTypeCode = phoneUsageTypeCode;
    }

    /**
     * Sets new memberIdentifier19.
     *
     * @param memberIdentifier19 New value of memberIdentifier19.
     */
    public void setMemberIdentifier19(String memberIdentifier19) {
        this.memberIdentifier19 = memberIdentifier19;
    }

    /**
     * Gets languageUsagePreferenceCode.
     *
     * @return Value of languageUsagePreferenceCode.
     */
    public String getLanguageUsagePreferenceCode() {
        return languageUsagePreferenceCode;
    }

    /**
     * Sets new emailUsagePreferenceCode.
     *
     * @param emailUsagePreferenceCode New value of emailUsagePreferenceCode.
     */
    public void setEmailUsagePreferenceCode(String emailUsagePreferenceCode) {
        this.emailUsagePreferenceCode = emailUsagePreferenceCode;
    }

    /**
     * Gets memberIdentifier19.
     *
     * @return Value of memberIdentifier19.
     */
    public String getMemberIdentifier19() {
        return memberIdentifier19;
    }

    /**
     * Sets new lastName.
     *
     * @param lastName New value of lastName.
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets zip.
     *
     * @return Value of zip.
     */
    public String getZip() {
        return zip;
    }

    /**
     * Gets languageOther.
     *
     * @return Value of languageOther.
     */
    public String getLanguageOther() {
        return languageOther;
    }

    /**
     * Gets memberIdentifier12.
     *
     * @return Value of memberIdentifier12.
     */
    public String getMemberIdentifier12() {
        return memberIdentifier12;
    }

    /**
     * Sets new zip.
     *
     * @param zip New value of zip.
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     * Gets locationUsagePreferenceCode.
     *
     * @return Value of locationUsagePreferenceCode.
     */
    public String getLocationUsagePreferenceCode() {
        return locationUsagePreferenceCode;
    }

    /**
     * Sets new memberIdentifier5.
     *
     * @param memberIdentifier5 New value of memberIdentifier5.
     */
    public void setMemberIdentifier5(String memberIdentifier5) {
        this.memberIdentifier5 = memberIdentifier5;
    }

    /**
     * Gets ethnicityCode.
     *
     * @return Value of ethnicityCode.
     */
    public String getEthnicityCode() {
        return ethnicityCode;
    }

    /**
     * Sets new languageOtherSource.
     *
     * @param languageOtherSource New value of languageOtherSource.
     */
    public void setLanguageOtherSource(String languageOtherSource) {
        this.languageOtherSource = languageOtherSource;
    }

    /**
     * Sets new rxClaims.
     *
     * @param rxClaims New value of rxClaims.
     */
//    public void setRxClaimInputs(List<RxClaimObject> rxClaims) {
//        this.rxClaims = rxClaims;
//}


    /**
     * Sets new locationUsagePreferenceCode.
     *
     * @param locationUsagePreferenceCode New value of locationUsagePreferenceCode.
     */
    public void setLocationUsagePreferenceCode(String locationUsagePreferenceCode) {
        this.locationUsagePreferenceCode = locationUsagePreferenceCode;
    }

    /**
     * Sets new memberIdentifier8.
     *
     * @param memberIdentifier8 New value of memberIdentifier8.
     */
    public void setMemberIdentifier8(String memberIdentifier8) {
        this.memberIdentifier8 = memberIdentifier8;
    }

    /**
     * Sets new emailAddress.
     *
     * @param emailAddress New value of emailAddress.
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * Gets memberIdentifier9.
     *
     * @return Value of memberIdentifier9.
     */
    public String getMemberIdentifier9() {
        return memberIdentifier9;
    }

    /**
     * Gets feedInstanceId.
     *
     * @return Value of feedInstanceId.
     */
    public String getFeedInstanceId() {
        return feedInstanceId;
    }

    /**
     * Sets new memberIdentifier15.
     *
     * @param memberIdentifier15 New value of memberIdentifier15.
     */
    public void setMemberIdentifier15(String memberIdentifier15) {
        this.memberIdentifier15 = memberIdentifier15;
    }

    /**
     * Sets new memberIdentifier2.
     *
     * @param memberIdentifier2 New value of memberIdentifier2.
     */
    public void setMemberIdentifier2(String memberIdentifier2) {
        this.memberIdentifier2 = memberIdentifier2;
    }

    /**
     * Gets memberIdentifier13.
     *
     * @return Value of memberIdentifier13.
     */
    public String getMemberIdentifier13() {
        return memberIdentifier13;
    }

    /**
     * Sets new languageSpokenSource.
     *
     * @param languageSpokenSource New value of languageSpokenSource.
     */
    public void setLanguageSpokenSource(String languageSpokenSource) {
        this.languageSpokenSource = languageSpokenSource;
    }

    /**
     * Gets raceType.
     *
     * @return Value of raceType.
     */
    public String getRaceType() {
        return raceType;
    }

    /**
     * Sets new addressLine1.
     *
     * @param addressLine1 New value of addressLine1.
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    /**
     * Sets new ethnicityCode.
     *
     * @param ethnicityCode New value of ethnicityCode.
     */
    public void setEthnicityCode(String ethnicityCode) {
        this.ethnicityCode = ethnicityCode;
    }

    /**
     * Gets stateCode.
     *
     * @return Value of stateCode.
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * Sets new udfActiveInd.
     *
     * @param udfActiveInd New value of udfActiveInd.
     */
    public void setUdfActiveInd(String udfActiveInd) {
        this.udfActiveInd = udfActiveInd;
    }

    /**
     * Gets languageWrittenSource.
     *
     * @return Value of languageWrittenSource.
     */
    public String getLanguageWrittenSource() {
        return languageWrittenSource;
    }

    /**
     * Sets new city.
     *
     * @param city New value of city.
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Sets new feedInstanceId.
     *
     * @param feedInstanceId New value of feedInstanceId.
     */
    public void setFeedInstanceId(String feedInstanceId) {
        this.feedInstanceId = feedInstanceId;
    }

    /**
     * Gets locationUsageTypeCode.
     *
     * @return Value of locationUsageTypeCode.
     */
    public String getLocationUsageTypeCode() {
        return locationUsageTypeCode;
    }

    /**
     * Gets languageOtherSource.
     *
     * @return Value of languageOtherSource.
     */
    public String getLanguageOtherSource() {
        return languageOtherSource;
    }

    /**
     * Sets new memberIdentifier1.
     *
     * @param memberIdentifier1 New value of memberIdentifier1.
     */
    public void setMemberIdentifier1(String memberIdentifier1) {
        this.memberIdentifier1 = memberIdentifier1;
    }

    /**
     * Gets memberIdentifier4.
     *
     * @return Value of memberIdentifier4.
     */
    public String getMemberIdentifier4() {
        return memberIdentifier4;
    }

    /**
     * Gets emailUsagePreferenceCode.
     *
     * @return Value of emailUsagePreferenceCode.
     */
    public String getEmailUsagePreferenceCode() {
        return emailUsagePreferenceCode;
    }

    /**
     * Gets fullName.
     *
     * @return Value of fullName.
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Sets new birthDate.
     *
     * @param birthDate New value of birthDate.
     */
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * Gets memberId.
     *
     * @return Value of memberId.
     */
//    public MemberIdObject getMemberId() {
//        return memberId;
//    }
    public int getMemberId() {
        return memberId;
    }

    /**
     * Sets new ethnicitySource.
     *
     * @param ethnicitySource New value of ethnicitySource.
     */
    public void setEthnicitySource(String ethnicitySource) {
        this.ethnicitySource = ethnicitySource;
    }

    /**
     * Gets claimInputs.
     *
     * @return Value of claimInputs.
     */
//    public List<ClaimObject> getClaimInputs() {
//        return claimInputs;
//    }


    /**
     * Sets new genderCode.
     *
     * @param genderCode New value of genderCode.
     */
    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    /**
     * Gets medicaidId.
     *
     * @return Value of medicaidId.
     */
    public String getMedicaidId() {
        return medicaidId;
    }

    /**
     * Sets new memberIdentifier9.
     *
     * @param memberIdentifier9 New value of memberIdentifier9.
     */
    public void setMemberIdentifier9(String memberIdentifier9) {
        this.memberIdentifier9 = memberIdentifier9;
    }

    /**
     * Sets new memberIdentifier20.
     *
     * @param memberIdentifier20 New value of memberIdentifier20.
     */
    public void setMemberIdentifier20(String memberIdentifier20) {
        this.memberIdentifier20 = memberIdentifier20;
    }

    /**
     * Gets city.
     *
     * @return Value of city.
     */
    public String getCity() {
        return city;
    }

    /**
     * Gets ethnicityType.
     *
     * @return Value of ethnicityType.
     */
    public String getEthnicityType() {
        return ethnicityType;
    }

    /**
     * Sets new emailUsageTypeCode.
     *
     * @param emailUsageTypeCode New value of emailUsageTypeCode.
     */
    public void setEmailUsageTypeCode(String emailUsageTypeCode) {
        this.emailUsageTypeCode = emailUsageTypeCode;
    }

    /**
     * Sets new memberIdentifier16.
     *
     * @param memberIdentifier16 New value of memberIdentifier16.
     */
    public void setMemberIdentifier16(String memberIdentifier16) {
        this.memberIdentifier16 = memberIdentifier16;
    }

    /**
     * Gets emailUsageTypeCode.
     *
     * @return Value of emailUsageTypeCode.
     */
    public String getEmailUsageTypeCode() {
        return emailUsageTypeCode;
    }

    /**
     * Sets new languageWrittenSource.
     *
     * @param languageWrittenSource New value of languageWrittenSource.
     */
    public void setLanguageWrittenSource(String languageWrittenSource) {
        this.languageWrittenSource = languageWrittenSource;
    }

    /**
     * Sets new fullName.
     *
     * @param fullName New value of fullName.
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * Gets udfActiveInd.
     *
     * @return Value of udfActiveInd.
     */
    public String getUdfActiveInd() {
        return udfActiveInd;
    }

    /**
     * Gets ssn.
     *
     * @return Value of ssn.
     */
    public String getSsn() {
        return ssn;
    }

    /**
     * Gets memberIdentifier6.
     *
     * @return Value of memberIdentifier6.
     */
    public String getMemberIdentifier6() {
        return memberIdentifier6;
    }

    /**
     * Gets memberIdentifier10.
     *
     * @return Value of memberIdentifier10.
     */
    public String getMemberIdentifier10() {
        return memberIdentifier10;
    }

    /**
     * Sets new languageUsagePreferenceCode.
     *
     * @param languageUsagePreferenceCode New value of languageUsagePreferenceCode.
     */
    public void setLanguageUsagePreferenceCode(String languageUsagePreferenceCode) {
        this.languageUsagePreferenceCode = languageUsagePreferenceCode;
    }

    /**
     * Sets new memberIdentifier17.
     *
     * @param memberIdentifier17 New value of memberIdentifier17.
     */
    public void setMemberIdentifier17(String memberIdentifier17) {
        this.memberIdentifier17 = memberIdentifier17;
    }

    /**
     * Gets phoneNumber.
     *
     * @return Value of phoneNumber.
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets new phoneNumber2.
     *
     * @param phoneNumber2 New value of phoneNumber2.
     */
    public void setPhoneNumber2(String phoneNumber2) {
        this.phoneNumber2 = phoneNumber2;
    }

    /**
     * Gets maritalStatus.
     *
     * @return Value of maritalStatus.
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets new deceasedDate.
     *
     * @param deceasedDate New value of deceasedDate.
     */
    public void setDeceasedDate(String deceasedDate) {
        this.deceasedDate = deceasedDate;
    }

    /**
     * Sets new memberIdentifier3.
     *
     * @param memberIdentifier3 New value of memberIdentifier3.
     */
    public void setMemberIdentifier3(String memberIdentifier3) {
        this.memberIdentifier3 = memberIdentifier3;
    }

    /**
     * Sets new memberIdentifier4.
     *
     * @param memberIdentifier4 New value of memberIdentifier4.
     */
    public void setMemberIdentifier4(String memberIdentifier4) {
        this.memberIdentifier4 = memberIdentifier4;
    }

    /**
     * Gets languagesWritten.
     *
     * @return Value of languagesWritten.
     */
    public String getLanguagesWritten() {
        return languagesWritten;
    }

    /**
     * Gets memberIdentifier1.
     *
     * @return Value of memberIdentifier1.
     */
    public String getMemberIdentifier1() {
        return memberIdentifier1;
    }

    /**
     * Gets memberIdentifier20.
     *
     * @return Value of memberIdentifier20.
     */
    public String getMemberIdentifier20() {
        return memberIdentifier20;
    }

    /**
     * Sets new memberIdentifier14.
     *
     * @param memberIdentifier14 New value of memberIdentifier14.
     */
    public void setMemberIdentifier14(String memberIdentifier14) {
        this.memberIdentifier14 = memberIdentifier14;
    }

    /**
     * Gets addressLine2.
     *
     * @return Value of addressLine2.
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets new languageUsageTypeCode.
     *
     * @param languageUsageTypeCode New value of languageUsageTypeCode.
     */
    public void setLanguageUsageTypeCode(String languageUsageTypeCode) {
        this.languageUsageTypeCode = languageUsageTypeCode;
    }

    /**
     * Gets memberIdentifier14.
     *
     * @return Value of memberIdentifier14.
     */
    public String getMemberIdentifier14() {
        return memberIdentifier14;
    }

    /**
     * Sets new languagesWritten.
     *
     * @param languagesWritten New value of languagesWritten.
     */
    public void setLanguagesWritten(String languagesWritten) {
        this.languagesWritten = languagesWritten;
    }

    /**
     * Sets new firstName.
     *
     * @param firstName New value of firstName.
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets memberIdentifier7.
     *
     * @return Value of memberIdentifier7.
     */
    public String getMemberIdentifier7() {
        return memberIdentifier7;
    }

    /**
     * Sets new memberIdentifier18.
     *
     * @param memberIdentifier18 New value of memberIdentifier18.
     */
    public void setMemberIdentifier18(String memberIdentifier18) {
        this.memberIdentifier18 = memberIdentifier18;
    }

    /**
     * Sets new county.
     *
     * @param county New value of county.
     */
    public void setCounty(String county) {
        this.county = county;
    }

    /**
     * Gets phoneUsageTypeCode.
     *
     * @return Value of phoneUsageTypeCode.
     */
    public String getPhoneUsageTypeCode() {
        return phoneUsageTypeCode;
    }

    /**
     * Sets new phoneNumber.
     *
     * @param phoneNumber New value of phoneNumber.
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Gets phoneNumber2.
     *
     * @return Value of phoneNumber2.
     */
    public String getPhoneNumber2() {
        return phoneNumber2;
    }

    /**
     * Sets new memberIdentifier13.
     *
     * @param memberIdentifier13 New value of memberIdentifier13.
     */
    public void setMemberIdentifier13(String memberIdentifier13) {
        this.memberIdentifier13 = memberIdentifier13;
    }

    /**
     * Gets deceasedDate.
     *
     * @return Value of deceasedDate.
     */
    public String getDeceasedDate() {
        return deceasedDate;
    }

    /**
     * Gets id.
     *
     * @return Value of id.
     */
//    public String getId() {
//        return id;
//    }

    /**
     * Gets clientMemberId.
     *
     * @return Value of clientMemberId.
     */
    public String getClientMemberId() {
        return clientMemberId;
    }

    /**
     * Gets subscriberKey.
     *
     * @return Value of subscriberKey.
     */
    public String getSubscriberKey() {
        return subscriberKey;
    }

    /**
     * Gets county.
     *
     * @return Value of county.
     */
    public String getCounty() {
        return county;
    }

    /**
     * Gets firstName.
     *
     * @return Value of firstName.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets new locationUsageTypeCode.
     *
     * @param locationUsageTypeCode New value of locationUsageTypeCode.
     */
    public void setLocationUsageTypeCode(String locationUsageTypeCode) {
        this.locationUsageTypeCode = locationUsageTypeCode;
    }

    /**
     * Sets new memberId.
     *
     * @param memberId New value of memberId.
     */
//    public void setMemberId(MemberIdObject memberId) {
//        this.memberId = memberId;
//    }
    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    /**
     * Gets memberIdentifier5.
     *
     * @return Value of memberIdentifier5.
     */
    public String getMemberIdentifier5() {
        return memberIdentifier5;
    }

    /**
     * Sets new memberIdentifier6.
     *
     * @param memberIdentifier6 New value of memberIdentifier6.
     */
    public void setMemberIdentifier6(String memberIdentifier6) {
        this.memberIdentifier6 = memberIdentifier6;
    }

    /**
     * Sets new phoneUsagePreferenceCode.
     *
     * @param phoneUsagePreferenceCode New value of phoneUsagePreferenceCode.
     */
    public void setPhoneUsagePreferenceCode(String phoneUsagePreferenceCode) {
        this.phoneUsagePreferenceCode = phoneUsagePreferenceCode;
    }

    /**
     * Gets languageUsageTypeCode.
     *
     * @return Value of languageUsageTypeCode.
     */
    public String getLanguageUsageTypeCode() {
        return languageUsageTypeCode;
    }

    /**
     * Gets languagesSpoken.
     *
     * @return Value of languagesSpoken.
     */
    public String getLanguagesSpoken() {
        return languagesSpoken;
    }

    /**
     * Gets middleName.
     *
     * @return Value of middleName.
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets new claimInputs.
     *
     * @param claimInputs New value of claimInputs.
     */
//    public void setClaimInputs(List<ClaimObject> claimInputs) {
//        this.claimInputs = claimInputs;
//    }


    /**
     * Gets memberIdentifier18.
     *
     * @return Value of memberIdentifier18.
     */
    public String getMemberIdentifier18() {
        return memberIdentifier18;
    }

    /**
     * Gets memberIdentifier11.
     *
     * @return Value of memberIdentifier11.
     */
    public String getMemberIdentifier11() {
        return memberIdentifier11;
    }

    /**
     * Gets genderCode.
     *
     * @return Value of genderCode.
     */
    public String getGenderCode() {
        return genderCode;
    }

    /**
     * Gets rxClaims.
     *
     * @return Value of rxClaims.
     */
//    public List<RxClaimObject> getRxClaimInputs() {
//        return rxClaims;
//    }


    /**
     * Sets new medicaidId.
     *
     * @param medicaidId New value of medicaidId.
     */
    public void setMedicaidId(String medicaidId) {
        this.medicaidId = medicaidId;
    }

    /**
     * Gets memberIdentifier8.
     *
     * @return Value of memberIdentifier8.
     */
    public String getMemberIdentifier8() {
        return memberIdentifier8;
    }

    /**
     * Sets new ssn.
     *
     * @param ssn New value of ssn.
     */
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    /**
     * Sets new clientMemberId.
     *
     * @param clientMemberId New value of clientMemberId.
     */
    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    /**
     * Gets phoneUsagePreferenceCode.
     *
     * @return Value of phoneUsagePreferenceCode.
     */
    public String getPhoneUsagePreferenceCode() {
        return phoneUsagePreferenceCode;
    }

    /**
     * Sets new stateCode.
     *
     * @param stateCode New value of stateCode.
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    /**
     * Sets new languageOther.
     *
     * @param languageOther New value of languageOther.
     */
    public void setLanguageOther(String languageOther) {
        this.languageOther = languageOther;
    }

    /**
     * Sets new memberIdentifier10.
     *
     * @param memberIdentifier10 New value of memberIdentifier10.
     */
    public void setMemberIdentifier10(String memberIdentifier10) {
        this.memberIdentifier10 = memberIdentifier10;
    }

    /**
     * Sets new raceType.
     *
     * @param raceType New value of raceType.
     */
    public void setRaceType(String raceType) {
        this.raceType = raceType;
    }

    /**
     * Sets new maritalStatus.
     *
     * @param maritalStatus New value of maritalStatus.
     */
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * Gets birthDate.
     *
     * @return Value of birthDate.
     */
    public String getBirthDate() {
        return birthDate;
    }

    /**
     * Gets labClaimInputs.
     *
     * @return Value of labClaimInputs.
     */
//    public List<LabClaimObject> getLabClaimInputs() {
//        return labClaimInputs;
//    }


    /**
     * Sets new addressLine2.
     *
     * @param addressLine2 New value of addressLine2.
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    /**
     * Sets new memberIdentifier12.
     *
     * @param memberIdentifier12 New value of memberIdentifier12.
     */
    public void setMemberIdentifier12(String memberIdentifier12) {
        this.memberIdentifier12 = memberIdentifier12;
    }

    /**
     * Sets new id.
     *
     * @param id New value of id.
     */
//    public void setId(String id) {
//        this.id = id;
//    }

    /**
     * Gets addressLine1.
     *
     * @return Value of addressLine1.
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Gets memberIdentifier15.
     *
     * @return Value of memberIdentifier15.
     */
    public String getMemberIdentifier15() {
        return memberIdentifier15;
    }

    /**
     * Sets new languagesSpoken.
     *
     * @param languagesSpoken New value of languagesSpoken.
     */
    public void setLanguagesSpoken(String languagesSpoken) {
        this.languagesSpoken = languagesSpoken;
    }

    /**
     * Sets new middleName.
     *
     * @param middleName New value of middleName.
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Gets emailAddress.
     *
     * @return Value of emailAddress.
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Gets lastName.
     *
     * @return Value of lastName.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets new memberIdentifier7.
     *
     * @param memberIdentifier7 New value of memberIdentifier7.
     */
    public void setMemberIdentifier7(String memberIdentifier7) {
        this.memberIdentifier7 = memberIdentifier7;
    }

    /**
     * Gets memberIdentifier16.
     *
     * @return Value of memberIdentifier16.
     */
    public String getMemberIdentifier16() {
        return memberIdentifier16;
    }

    /**
     * Gets memberIdentifier3.
     *
     * @return Value of memberIdentifier3.
     */
    public String getMemberIdentifier3() {
        return memberIdentifier3;
    }

    /**
     * Gets memberIdentifier17.
     *
     * @return Value of memberIdentifier17.
     */
    public String getMemberIdentifier17() {
        return memberIdentifier17;
    }

    /**
     * Sets new memberIdentifier11.
     *
     * @param memberIdentifier11 New value of memberIdentifier11.
     */
    public void setMemberIdentifier11(String memberIdentifier11) {
        this.memberIdentifier11 = memberIdentifier11;
    }

    /**
     * Gets languageSpokenSource.
     *
     * @return Value of languageSpokenSource.
     */
    public String getLanguageSpokenSource() {
        return languageSpokenSource;
    }

    /**
     * Sets new ethnicityType.
     *
     * @param ethnicityType New value of ethnicityType.
     */
    public void setEthnicityType(String ethnicityType) {
        this.ethnicityType = ethnicityType;
    }

    /**
     * Gets enrollmentInputs.
     *
     * @return Value of enrollmentInputs.
     */
//    public Set<EnrollmentObject> getEnrollmentInputs() {
//        return enrollmentInputs;
//    }


    /**
     * Sets new enrollmentInputs.
     *
     */
//    public void setEnrollmentInputs(Set<EnrollmentObject> enrollmentInputs) {
//        this.enrollmentInputs = enrollmentInputs;
//    }


    @Override
    public String toString() {
        return "PatientProfileInput{" +
//                "id='" + id + '\'' +
                ", memberId=" + memberId +
                ", clientMemberId='" + clientMemberId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", genderCode='" + genderCode + '\'' +
                ", ssn='" + ssn + '\'' +
                ", maritalStatus='" + maritalStatus + '\'' +
                ", deceasedDate='" + deceasedDate + '\'' +
                ", addressLine1='" + addressLine1 + '\'' +
                ", addressLine2='" + addressLine2 + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", stateCode='" + stateCode + '\'' +
                ", zip='" + zip + '\'' +
                ", locationUsageTypeCode='" + locationUsageTypeCode + '\'' +
                ", locationUsagePreferenceCode='" + locationUsagePreferenceCode + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", emailUsageTypeCode='" + emailUsageTypeCode + '\'' +
                ", emailUsagePreferenceCode='" + emailUsagePreferenceCode + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", phoneNumber2='" + phoneNumber2 + '\'' +
                ", phoneUsageTypeCode='" + phoneUsageTypeCode + '\'' +
                ", phoneUsagePreferenceCode='" + phoneUsagePreferenceCode + '\'' +
                ", ethnicityCode='" + ethnicityCode + '\'' +
                ", ethnicityType='" + ethnicityType + '\'' +
                ", ethnicitySource='" + ethnicitySource + '\'' +
                ", raceType='" + raceType + '\'' +
                ", languagesSpoken='" + languagesSpoken + '\'' +
                ", languagesWritten='" + languagesWritten + '\'' +
                ", languageOther='" + languageOther + '\'' +
                ", languageSpokenSource='" + languageSpokenSource + '\'' +
                ", languageWrittenSource='" + languageWrittenSource + '\'' +
                ", languageOtherSource='" + languageOtherSource + '\'' +
                ", languageUsageTypeCode='" + languageUsageTypeCode + '\'' +
                ", languageUsagePreferenceCode='" + languageUsagePreferenceCode + '\'' +
                ", subscriberKey='" + subscriberKey + '\'' +
                ", medicaidId='" + medicaidId + '\'' +
                ", memberIdentifier1='" + memberIdentifier1 + '\'' +
                ", memberIdentifier2='" + memberIdentifier2 + '\'' +
                ", memberIdentifier3='" + memberIdentifier3 + '\'' +
                ", memberIdentifier4='" + memberIdentifier4 + '\'' +
                ", memberIdentifier5='" + memberIdentifier5 + '\'' +
                ", memberIdentifier6='" + memberIdentifier6 + '\'' +
                ", memberIdentifier7='" + memberIdentifier7 + '\'' +
                ", memberIdentifier8='" + memberIdentifier8 + '\'' +
                ", memberIdentifier9='" + memberIdentifier9 + '\'' +
                ", memberIdentifier10='" + memberIdentifier10 + '\'' +
                ", memberIdentifier11='" + memberIdentifier11 + '\'' +
                ", memberIdentifier12='" + memberIdentifier12 + '\'' +
                ", memberIdentifier13='" + memberIdentifier13 + '\'' +
                ", memberIdentifier14='" + memberIdentifier14 + '\'' +
                ", memberIdentifier15='" + memberIdentifier15 + '\'' +
                ", memberIdentifier16='" + memberIdentifier16 + '\'' +
                ", memberIdentifier17='" + memberIdentifier17 + '\'' +
                ", memberIdentifier18='" + memberIdentifier18 + '\'' +
                ", memberIdentifier19='" + memberIdentifier19 + '\'' +
                ", memberIdentifier20='" + memberIdentifier20 + '\'' +
                ", feedInstanceId='" + feedInstanceId + '\'' +
                ", udfActiveInd='" + udfActiveInd + '\'' +
                ", claimInputs=" + claims +
                ", rxClaims=" + rxClaims +
                ", labClaimInputs=" + labClaims +
                ", enrollmentInputs=" + enrollments +
                '}';
    }

}

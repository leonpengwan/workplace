package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Service("NewEnrolleeAttribute")
public class NewEnrolleeAttribute implements MemberProfileRealization {
    @Autowired
    private LogWriter logWriter;


    //    private final static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private final static SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");

    /**
     * Get MemberId from Gap
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
//        int previousEnrollmentIsPresent = 0;
//        int currentYearEnrollmentIsPresent = 0;

        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();
        // for loop to check if a member is not enrolled in any health plan in
        // the calendar year prior to the planning calendar year
        // and their enrollments start date is Jan 1 of the planning calendar
        // year or later
        if (patientProfile.getEnrollments() != null) {
            memberAttribute.setNewEnrollee(true);
            for (Enrollment enrollment : patientProfile.getEnrollments()) {
                try {

                    // capture enrollments begin and end dates
                    Date enrollmentStartDate = StringToDate.getDate(enrollment.getCoverageBeginDate());
                    Date enrollmentEndDate = StringToDate.getDate(enrollment.getCoverageEndDate());
                    //int year = patientProfile.getPlanningMonthStartDate().getYear()
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(memberAttribute.getPlanningMonthStartDate());
                    int year = cal.get(Calendar.YEAR) - 1;
                    cal.set(cal.get(Calendar.YEAR), 0, 01);
                    Date planYearStartDate = cal.getTime();
                    cal.set(cal.get(Calendar.YEAR), 11, 31);
                    Date planningYearEndDate = cal.getTime();


                    // capture dates for current plan year
                    //String planYearStartDateString = "01/01/" + Integer.toString(cal.get(Calendar.YEAR));
                    //Date planYearStartDate = formatter1.parse(planYearStartDateString);
                    // capture dates to check for previous calendar year

                    String priorYearStartDateString = "01/01/" + Integer.toString(year);
                    Date priorYearStartDate = formatter1.parse(priorYearStartDateString);

                    String priorYearEndDateString = "12/31/" + Integer.toString(year);
                    Date priorYearEndDate = formatter1.parse(priorYearEndDateString);
                    if (((enrollmentStartDate.after(priorYearStartDate) || enrollmentStartDate.equals(priorYearStartDate)) && enrollmentStartDate.before(priorYearEndDate))
                            ||
                            (enrollmentEndDate.after(priorYearStartDate) && (enrollmentEndDate.before(priorYearEndDate) || enrollmentEndDate.equals(priorYearEndDate)))
                            ||
                            (enrollmentStartDate.before(priorYearStartDate) && enrollmentEndDate.after(priorYearEndDate))
                            ) {
                        memberAttribute.setNewEnrollee(false);
                        break;
                    }

                    /*if ((enrollmentStartDate.before(planYearStartDate) && enrollmentEndDate.after(planYearStartDate)) ||
                            (enrollmentStartDate.after(planYearStartDate) && (enrollmentEndDate.after(planYearStartDate) && enrollmentEndDate.before(planningYearEndDate)))
                            || (enrollmentStartDate.after(planYearStartDate) && enrollmentEndDate.after(planningYearEndDate))) {
                        currentYearEnrollmentIsPresent++;
                        break;
                    }*/

                   /* if ((enrollmentStartDate.compareTo(priorYearStartDate) >= 0
                            && enrollmentStartDate.compareTo(priorYearEndDate) <= 0)
                            || (enrollmentEndDate.compareTo(priorYearStartDate) >= 0
                            && enrollmentEndDate.compareTo(priorYearEndDate) <= 0)) {
                        previousEnrollmentIsPresent += 1;
                    }

                    if (enrollmentStartDate.compareTo(planYearStartDate) >= 0) {
                        currentYearEnrollmentIsPresent += 1;
                    }*/

                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }
        /*if (previousEnrollmentIsPresent == 0 && currentYearEnrollmentIsPresent > 0) {
            memberAttribute.setNewEnrollee(true);
        }*/
        logWriter.info("getNewEnroleeStatusByMemberId completed");
    }
}
package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;

import java.util.List;

public interface GapExclusionService {

    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatusList, CacheUtil cacheUtil, MemberAttribute memberAttribute);
}

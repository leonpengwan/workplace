package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberProfileRealizationFactoryService {


    @Autowired private MemberProfileRealizationFactory memberProfileRealizationFactory;

   /* @Autowired
    private List<MemberProfileRealization> memberProfileRealizations;
*/
    //private static final Map<String, MemberProfileRealization> myServiceCache = new HashMap<>();

    /*@Autowired
    private MemberProfileRealizationFactory memberProfileRealizationFactory;*/

    /*@PostConstruct
    public void initMyServiceCache() {
        for(MemberProfileRealization service : memberProfileRealizations) {
            myServiceCache.put(service.getClass().getSimpleName(), service);
        }
    }*/


    public MemberProfileRealization beanRequest(RulzBeanEnum rulzBeanEnum){
        MemberProfileRealization memberProfileRealization = memberProfileRealizationFactory.getMemberProfileRealization(rulzBeanEnum.getValue());
        return memberProfileRealization;
    }

}

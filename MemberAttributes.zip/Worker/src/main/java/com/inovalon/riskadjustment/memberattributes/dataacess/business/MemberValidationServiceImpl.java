package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao.MemberValidationDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class MemberValidationServiceImpl implements MemberValidationService {
    @Autowired
    private MemberValidationDao memberValidationEntityDao;

    @Override
    public int persistMemberValidation(MemberValidation memberValidation, String userInfo) {
        try {
            if (memberValidation == null) {
                System.out.println("json body empty for persist member validation");
                return 1;
            } else {

                memberValidationEntityDao.saveMemberValidation(memberValidation,userInfo);
                return 0;
            }
        } catch (DataIntegrityViolationException violationException) {
            System.out.println("MemberAttributes Persistence: MemberValidation for member id: " + memberValidation.getMemberId()
                    + " and MemberAttributesRunId: " + memberValidation.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        } catch (Exception e) {
            e.printStackTrace();
            return 99;
        }
    }
}

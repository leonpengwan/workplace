package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import org.springframework.stereotype.Component;

@Component
public interface MemberProfileRealizationFactory {

    public MemberProfileRealization getMemberProfileRealization(String memberProfileRealization);

}

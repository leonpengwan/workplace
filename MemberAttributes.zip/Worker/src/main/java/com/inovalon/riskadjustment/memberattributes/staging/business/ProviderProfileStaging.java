package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.config.ApplicationConfiguration;
import com.inovalon.riskadjustment.memberattributes.staging.model.ProviderProfilePayload;
import com.inovalon.riskadjustment.memberattributes.util.MemberAttributesConstants;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProviderProfileStaging {
    @Autowired
    private ApplicationConfiguration applicationConfiguration;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private HttpHeaders headers;
    @Autowired
    private LogWriter logWriter;

    /**
     * This method will get the list of providerProfiles based on clientProviderIds,clientShortName and projectShortName
     *
     * @param ids
     * @param runProfile *
     * @return It returns list of providerProfiles
     * @throws Exception
     */
    @LogBeforeEvents
    public List<ProviderProfile> stageProviderProfile(List<String> ids, RunProfile runProfile) throws Exception {
        logWriter.info("Beginning of stagePatientProfile");
        List<ProviderProfile> providerProfiles = new ArrayList<>();

        try {

            ProviderProfilePayload providerProfilePayload = new ProviderProfilePayload();
            providerProfilePayload.ids = ids;
            providerProfilePayload.clientShortName = runProfile.getClientShortName();
            providerProfilePayload.projectShortName = runProfile.getProjectShortName();

            String url = applicationConfiguration.getPatientProviderProfileServiceBaseUrl() + MemberAttributesConstants.GET_FULL_PROVIDER_PROFILE;
            String json = objectMapper.writeValueAsString(providerProfilePayload);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(json, headers);
            ResponseEntity<List<ProviderProfile>> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<List<ProviderProfile>>() {
            });
            providerProfiles = responseEntity.getBody();
            logWriter.info("Ending of stagePatientProfile");
        } catch (RestClientException restException) {
            logWriter.error(restException.getMessage(), restException);
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(), ex);
            throw ex;
        }
        return providerProfiles;
    }
}

package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;

import java.util.List;

public interface MemberEvidenceStatusService {
    int persistMemberEvidence(List<MemberEvidenceStatus> memberEvidenceStatuses, String userInfo);
}

package com.inovalon.riskadjustment.memberattributes.util;

import org.apache.commons.lang.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDate {

    private static final DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");


    public static Date getDate(CharSequence date){
        try {
            if(date!=null && !StringUtils.isEmpty(date.toString()))
                return formatter.parse(date.toString());
        } catch (ParseException e) {
            System.out.println("Date parsing exception"+e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public static String getStringDate(Date date){
        try {
            if(date!=null && !StringUtils.isEmpty(date.toString()))
                return formatter.format(date);
        } catch (Exception e) {
            System.out.println("Date parsing exception"+e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}

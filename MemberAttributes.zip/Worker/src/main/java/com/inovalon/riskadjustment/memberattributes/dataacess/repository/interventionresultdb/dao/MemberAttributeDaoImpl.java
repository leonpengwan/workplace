package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.util.JDBCUtil;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MemberAttributeDaoImpl extends JDBCUtil implements MemberAttributeDao {


    @Autowired @Qualifier("interventionResultJdbcTemplate") private JdbcTemplate interventionPlanResultTemplate;


    private final static String INSERT_QUERY = "insert into dbo.memberattributes(MemberAttributesRunId," +
            "MemberId,PersonId,MissingProfile,NewEnrollee,Termed,MissingLastName," +
            "MissingFirstName,MissingDateOfBirth,CurrentlyEnrolled,Deceased," +
            "Hospice,Homebound,AgeGroup,AgeExclusionLessThan3,Age," +
            "AgeGroupId,MetalLevel,GroupPlanType,State," +
            "AttributedPractitionerId,WinningEnrollmentId,NoPreviousIntervention,PastEFIntervention," +
            "PastSMEIntervention,PcpVisit,TotalReachAttempts,SuccessfulReachAttempts,NotReached," +
            "ReachRateCategoryId,CompletedEFSoapNote,Institutional,CreatedBy,ModifiedBy,PlanId) " +
            "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
    @Override
    public int saveMemberAttribute(MemberAttribute memberAttribute, String userInfo) {
        Object[] params = new Object[]{memberAttribute.getMemberAttributesRunId(), memberAttribute.getMemberId(), memberAttribute.getPersonId(),
                memberAttribute.isMissingProfile(), memberAttribute.isNewEnrollee(), memberAttribute.isTermed(), memberAttribute.isMissingLastName(),
                memberAttribute.isMissingFirstName(), memberAttribute.isMissingDateOfBirth(), memberAttribute.isCurrentlyEnrolled(), memberAttribute.isDeceased(),
                memberAttribute.isHospice(), memberAttribute.isHomebound(),memberAttribute.getAgeGroup(),memberAttribute.isAgeExclusionLessThan3(), memberAttribute.getAge(),
                memberAttribute.getAgeGroupId(),  memberAttribute.getMetalLevel(), memberAttribute.getGroupPlanType(), memberAttribute.getState(),
                memberAttribute.getAttributedPractitionerId(),   memberAttribute.getWinningEnrollmentId(), memberAttribute.isNoPreviousIntervention(), memberAttribute.isPastEfIntervention(),
                memberAttribute.isPastSmeIntervention(), memberAttribute.isPcpVisit(), memberAttribute.getTotalReachAttempts(), memberAttribute.getSuccessfulReachAttempts(), memberAttribute.getNotReached(),
                memberAttribute.getReachRateCategoryId(), memberAttribute.isCompletedEfSoapNote(), memberAttribute.isInstitutional(),userInfo,userInfo,memberAttribute.getPlanId()};
        int Id = interventionPlanResultTemplate.update(INSERT_QUERY, params);
        return Id;
    }
}

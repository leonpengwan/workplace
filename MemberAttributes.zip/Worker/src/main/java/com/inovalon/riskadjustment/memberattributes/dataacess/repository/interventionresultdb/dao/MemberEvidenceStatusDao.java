package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;

import java.util.List;

public interface MemberEvidenceStatusDao {

    List<Integer> saveMemberEvidenceStatuses(List<MemberEvidenceStatus> memberEvidenceStatusEntities, String userInfo);
}

package com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute;

public class MemberEvidenceStatus {
    private long memberEvidenceStatusId;
    private int memberAttributesRunId;
    private long memberEvidenceId;
    private int gapSetDetailId;
    private int memberId;
    private String personId="";
    private int practitionerId;
    private int encounterId;
    private String encounterServiceDate="";
    private String hccCode="";
    private String originalHccCode="";
    private double gapConfidenceValue;
    private String gapConfidenceLevel="";
    private String gapType="";
    private int exclusionId;
    private String measureKey="";
    private int saGapValue;

    public MemberEvidenceStatus() {
    }

    public MemberEvidenceStatus(long memberEvidenceStatusId, int memberAttributesRunId, long memberEvidenceId, Integer gapSetDetailId, Integer memberId, String personId, Integer practitionerId, Integer encounterId, String encounterServiceDate, String hccCode, String originalHccCode, Double gapConfidenceValue, String gapConfidenceLevel, String gapType, int exclusionId, String measureKey, int saGapValue) {
        this.memberEvidenceStatusId = memberEvidenceStatusId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.memberEvidenceId = memberEvidenceId;
        this.gapSetDetailId = gapSetDetailId;
        this.memberId = memberId;
        this.personId = personId;
        this.practitionerId = practitionerId;
        this.encounterId = encounterId;
        this.encounterServiceDate = encounterServiceDate;
        this.hccCode = hccCode;
        this.originalHccCode = originalHccCode;
        this.gapConfidenceValue = gapConfidenceValue;
        this.gapConfidenceLevel = gapConfidenceLevel;
        this.gapType = gapType;
        this.exclusionId = exclusionId;
        this.measureKey = measureKey;
        this.saGapValue = saGapValue;
    }

    public long getMemberEvidenceStatusId() {
        return memberEvidenceStatusId;
    }

    public void setMemberEvidenceStatusId(long memberEvidenceStatusId) {
        this.memberEvidenceStatusId = memberEvidenceStatusId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public long getMemberEvidenceId() {
        return memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    public Integer getGapSetDetailId() {
        return gapSetDetailId;
    }

    public void setGapSetDetailId(Integer gapSetDetailId) {
        this.gapSetDetailId = gapSetDetailId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public Integer getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(Integer practitionerId) {
        this.practitionerId = practitionerId;
    }

    public Integer getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(Integer encounterId) {
        this.encounterId = encounterId;
    }

    public String getEncounterServiceDate() {
        return encounterServiceDate;
    }

    public void setEncounterServiceDate(String encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    public String getHccCode() {
        return hccCode;
    }

    public void setHccCode(String hccCode) {
        this.hccCode = hccCode;
    }

    public String getOriginalHccCode() {
        return originalHccCode;
    }

    public void setOriginalHccCode(String originalHccCode) {
        this.originalHccCode = originalHccCode;
    }

    public Double getGapConfidenceValue() {
        return gapConfidenceValue;
    }

    public void setGapConfidenceValue(Double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    public String getGapConfidenceLevel() {
        return gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    public String getGapType() {
        return gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    public int getExclusionId() {
        return exclusionId;
    }

    public void setExclusionId(int exclusionId) {
        this.exclusionId = exclusionId;
    }

    public String getMeasureKey() {
        return measureKey;
    }

    public void setMeasureKey(String measureKey) {
        this.measureKey = measureKey;
    }

    public int getSaGapValue() {
        return saGapValue;
    }

    public void setSaGapValue(int saGapValue) {
        this.saGapValue = saGapValue;
    }
}

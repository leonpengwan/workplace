package com.inovalon.riskadjustment.memberattributes.dataacess.repository.gapresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.util.JDBCUtil;
import com.inovalon.riskadjustment.memberattributes.util.QueryBuilder;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pwan on 1/31/2018.
 */
@Repository
public class MemberEvidenceEntityDaoImpl extends JDBCUtil implements MemberEvidenceEntityDao {

    @Override
    public List<MemberEvidence> findByGapSetDetailIdAndMemberIds(String gapSetId, List<Integer> memberIds) throws SQLException {
        List<MemberEvidence> memberEvidences = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet;

        StringBuilder idList = QueryBuilder.buildPrepareStatement(memberIds.size());
        String GAPSETDETAILS_ID_AND_MEMBERID = "select * from dbo.MemberEvidence where memberId in ("+idList+") and GapSetId=?";
        try{
            connection = getGapResultConnection();
            preparedStatement = connection.prepareStatement(GAPSETDETAILS_ID_AND_MEMBERID);
            for (int i = 0; i < memberIds.size(); i++) {
                preparedStatement.setInt(i+1,memberIds.get(i));
            }
            preparedStatement.setString(memberIds.size()+1,gapSetId);
            resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    MemberEvidence memberEvidence = new MemberEvidence();
                    memberEvidence.setEncounterId(resultSet.getInt("EncounterId"));
                    memberEvidence.setEncounterServiceDate(resultSet.getDate("EncounterServiceDate")!=null?resultSet.getDate("EncounterServiceDate").toString():"");
                    memberEvidence.setGapConfidenceLevel(resultSet.getString("GapConfidenceLevel"));
                    memberEvidence.setGapConfidenceValue(resultSet.getDouble("GapConfidenceValue"));
                    memberEvidence.setGapSetId(resultSet.getString("GapSetId"));
                    memberEvidence.setGapType(resultSet.getString("GapType"));
                    memberEvidence.setHcc(resultSet.getString("Hcc"));
                    memberEvidence.setMemberId(resultSet.getInt("MemberId"));
                    memberEvidence.setMemberEvidenceId(resultSet.getLong("MemberEvidenceId"));
                    memberEvidence.setPersonId(resultSet.getString("PersonId"));
                    memberEvidence.setPractitionerId(resultSet.getInt("PractitionerId"));
                    memberEvidence.setSaGapValue(resultSet.getInt("SAGapValue"));
                    memberEvidence.setMeasureKey(resultSet.getString("MeasureKey"));
                    memberEvidences.add(memberEvidence);
                }
        }finally {
            closeResources(connection,preparedStatement);
        }
        return memberEvidences;

        /*return jdbcTemplate.execute(GAPSETDETAILS_ID_AND_MEMBERID, new PreparedStatementCallback<List<MemberEvidence>>() {
            @Override
            public List<MemberEvidence> doInPreparedStatement(PreparedStatement preparedStatement) throws SQLException, DataAccessException {
                preparedStatement.setString(1, gapSetId);
                preparedStatement.setArray(2, jdbcTemplate.getDataSource().getConnection().createArrayOf("text", memberIds.toArray()));
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    MemberEvidence memberEvidence = new MemberEvidence();
                    memberEvidence.setEncounterId(resultSet.getInt("EncounterId"));
                    memberEvidence.setEncounterServiceDate(resultSet.getDate("EncounterServiceDate").toString());
                    memberEvidence.setGapConfidenceLevel(resultSet.getString("GapConfidenceLevel"));
                    memberEvidence.setGapConfidenceValue(resultSet.getDouble("GapConfidenceValue"));
                    memberEvidence.setGapSetId(resultSet.getString("GapSetId"));
                    memberEvidence.setGapType(resultSet.getString("GapType"));
                    memberEvidence.setHcc(resultSet.getString("Hcc"));
                    memberEvidence.setMemberId(resultSet.getInt("MemberId"));
                    memberEvidence.setMemberEvidenceId(resultSet.getLong("MemberEvidenceId"));
                    memberEvidence.setPersonId(resultSet.getString("PersonId"));
                    memberEvidence.setPractitionerId(resultSet.getInt("PractitionerId"));
                    memberEvidences.add(memberEvidence);
                }
                return memberEvidences;
            }
        });*/
    }
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.Address;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.Name;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheManager;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.util.ValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
public class PractitionerValidationService {

    @Autowired
    CacheManager cacheManager;
    @LogBeforeEvents
    public PractitionerValidation validatePractitioner(StagingMessage stagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        PatientProfile patientProfile = stagingMessage.getPatientProfile();
        Set<String> validatedProviderIds = cacheUtil.getValidatedProviderIds();
        String clientProviderId = getClientProviderId(patientProfile, memberAttribute);
        //if(!validatedProviderIds.contains(clientProviderId)) {
        List<ProviderProfile> providerProfiles = stagingMessage.getProviderProfiles();
        if (!StringUtils.isEmpty(clientProviderId)) {
            Optional<ProviderProfile> result = providerProfiles.stream().filter(t -> clientProviderId.equals(t.getClientProviderId())).findFirst();
            if (result.isPresent()) {
                ProviderProfile providerProfile = result.get();
                PractitionerValidation practitionerValidation = validateProviderProfile(providerProfile, stagingMessage.getMemberAttributesRunId());
                //cacheManager.addValidatedClientProviderIdInCache(stagingMessage.getRunProfileId(), clientProviderId);
                return practitionerValidation;
            }
        }
        //}

        return null;
    }
    @LogBeforeEvents
    private String getClientProviderId(PatientProfile patientProfile, MemberAttribute memberAttribute) {

        Set<Enrollment> enrollments = patientProfile.getEnrollments();
        if (!CollectionUtils.isEmpty(enrollments)) {
            Iterator<Enrollment> enrollmentIterator = enrollments.iterator();
            while (enrollmentIterator.hasNext()) {
                Enrollment enrollment = enrollmentIterator.next();
                if (enrollment.getMemberEnrollmentId() == memberAttribute.getWinningEnrollmentId()) {
                    return enrollment.getClientProviderId();
                }
            }
        }
        return null;
    }

    /**
     * It validates ProviderProfile providerProfiles and returns PractitionerValidation
     *
     * @param provierProfile
     * @param memberAttributesRunId
     * @return It returns validation result of ProviderProfile providerProfiles as PractitionerValidation
     */
    @LogAfterEvents
    private PractitionerValidation validateProviderProfile(ProviderProfile provierProfile, int memberAttributesRunId) {
        PractitionerValidation practitionerValidation = new PractitionerValidation();
        Address providerAddress = provierProfile.getAddress().get(0);
        boolean isValidPhoneNumber = ValidationUtil.validatePhoneOrFaxNumber(providerAddress.getPhone());
        boolean isValidFaxNumber = ValidationUtil.validatePhoneOrFaxNumber(providerAddress.getFaxNumber1());
        Name name = provierProfile.getName().get(0);
        boolean isValidPcpName = ValidationUtil.validatePcpName(name.getFirstName(), name.getLastName());
        boolean isValidAddress = ValidationUtil.validateAddress(providerAddress.getAddressLine1(), providerAddress.getAddressLine2(),
                providerAddress.getCity(), providerAddress.getState(), providerAddress.getZip());
        practitionerValidation.setInvalidName(!isValidPcpName);
        practitionerValidation.setInvalidFax(!isValidFaxNumber);
        practitionerValidation.setInvalidPhone(!isValidPhoneNumber);
        practitionerValidation.setInvalidAddress(!isValidAddress);
        practitionerValidation.setMemberAttributesRunId(memberAttributesRunId);
        practitionerValidation.setPractitionerId(Integer.valueOf(provierProfile.getProviderId()));
        return practitionerValidation;
    }


}

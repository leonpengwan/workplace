package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.util.ValidationUtil;
import org.springframework.stereotype.Component;


@Component
public class MemberValidationService {

    /**
     * It validates PatientProfile and returns MemberValidation
     *
     * @param patientProfile
     * @param memberAttributesRunId
     * @return It returns validation result of PatientProfile as MemberValidation
     */
    public MemberValidation validateMember(PatientProfile patientProfile, int memberAttributesRunId) {

        MemberValidation memberValidation = new MemberValidation();

        memberValidation.setMemberId(patientProfile.getMemberId());
        boolean isValidAddress = ValidationUtil.validateAddress(patientProfile.getAddressLine1(),
                patientProfile.getAddressLine2(), patientProfile.getCity(),
                patientProfile.getStateCode(), patientProfile.getZip());
        boolean isValidPhoneNumber = ValidationUtil.validatePhoneOrFaxNumber(patientProfile.getPhoneNumber());
        memberValidation.setInValidAddress(!isValidAddress);
        memberValidation.setInValidPhone(!isValidPhoneNumber);
        memberValidation.setMemberId(patientProfile.getMemberId());
        memberValidation.setPersonId(String.valueOf(patientProfile.getMemberId()));
        //memberValidation.setMemberValidationId();
        memberValidation.setMemberAttributesRunId(memberAttributesRunId);
        return memberValidation;
    }


}

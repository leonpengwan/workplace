package com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.Validation;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service.MemberValidationService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.validation.service.PractitionerValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by pwan on 1/15/2018.
 */
@Component
public class ValidationManager {

    @Autowired
    private MemberValidationService memberValidationService;

    @Autowired
    private PractitionerValidationService practitionerValidationService;

    @LogBeforeEvents
    public Validation manageValidation(StagingMessage stagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil){

        Validation validation = new Validation();

        MemberValidation memberValidation = memberValidationService.validateMember(stagingMessage.getPatientProfile(), memberAttribute.getMemberAttributesRunId());

        PractitionerValidation practitionerValidation = practitionerValidationService.validatePractitioner(stagingMessage, memberAttribute, cacheUtil);

//        validation.setMemberValidation(validationMapper.memberValidationToMemberValidationAvro(memberValidation));
//        validation.setPractitionerValidation(validationMapper.practitionerValidationToPractitionerValidationAvro(practitionerValidation));
        validation.setMemberValidation(memberValidation);
        validation.setPractitionerValidation(practitionerValidation);
        return validation;
    }
}

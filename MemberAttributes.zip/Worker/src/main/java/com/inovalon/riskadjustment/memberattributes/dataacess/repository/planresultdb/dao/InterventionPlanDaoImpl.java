package com.inovalon.riskadjustment.memberattributes.dataacess.repository.planresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.util.JDBCUtil;
import com.inovalon.riskadjustment.memberattributes.util.QueryBuilder;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class InterventionPlanDaoImpl extends JDBCUtil implements InterventionPlanDao {


    @Autowired
    @Qualifier("planResultJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<InterventionPlan> findByInterventionPlanRunIdIn(List<Integer> interventionPlanRunIds) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet;
        List<InterventionPlan> interventionPlans = new ArrayList<>();
        StringBuilder idList = QueryBuilder.buildPrepareStatement(interventionPlanRunIds.size());
        String INTERVENTION_RUNID = "select * from dbo.InterventionPlan where InterventionPlanRunId in("+idList+")";

        try{
            connection = getPlanResultConnection();
            preparedStatement = connection.prepareStatement(INTERVENTION_RUNID);
            for (int i = 0; i < interventionPlanRunIds.size(); i++) {
                preparedStatement.setInt(i + 1, interventionPlanRunIds.get(i));
            }

                resultSet = preparedStatement.executeQuery();
                while(resultSet.next()){
                    InterventionPlan interventionPlan = new InterventionPlan();
                    interventionPlan.setInterventionMonth(resultSet.getInt("InterventionMonth"));
                    interventionPlan.setInterventionPlanId( resultSet.getLong("InterventionPlanId"));
                    interventionPlan.setInterventionPlanRunId(resultSet.getInt("InterventionPlanRunId"));
                    interventionPlan.setInterventionPrefix( resultSet.getString("InterventionPrefix"));
                    interventionPlan.setInterventionTypeId( resultSet.getInt("InterventionTypeId"));
                    interventionPlan.setInterventionYear( resultSet.getInt("InterventionYear"));
                    interventionPlan.setMemberId(resultSet.getInt("MemberId"));
                    interventionPlan.setPersonId(resultSet.getString("PersonId"));
                    interventionPlans.add(interventionPlan);
                }
        }finally {
            closeResources(connection,preparedStatement);
        }

        //preparedStatement.setArray(1,connection.createArrayOf("$VALUETYPE", interventionPlanRunIds.toArray()));


        return interventionPlans;


        /*return jdbcTemplate.execute(INTERVENTION_RUNID, new PreparedStatementCallback<List<InterventionPlan>>() {
            @Override
            public List<InterventionPlan> doInPreparedStatement(PreparedStatement preparedStatement) throws SQLException, DataAccessException {
                preparedStatement.setArray(1, jdbcTemplate.getDataSource().getConnection().createArrayOf("text", interventionPlanRunIds.toArray()));
                ResultSet resultSet = preparedStatement.executeQuery();
                while(resultSet.next()){
                    InterventionPlan interventionPlan = new InterventionPlan();
                    interventionPlan.setInterventionMonth(resultSet.getInt("InterventionMonth"));
                    interventionPlan.setInterventionPlanId( resultSet.getLong("InterventionPlanId"));
                    interventionPlan.setInterventionPlanRunId(resultSet.getInt("InterventionPlanRunId"));
                    interventionPlan.setInterventionPrefix( resultSet.getString("InterventionPrefix"));
                    interventionPlan.setInterventionTypeId( resultSet.getInt("InterventionTypeId"));
                    interventionPlan.setInterventionYear( resultSet.getInt("InterventionYear"));
                    interventionPlan.setMemberId(resultSet.getInt("MemberId"));
                    interventionPlan.setPersonId(resultSet.getString("PersonId"));
                    interventionPlans.add(interventionPlan);
                }
                return  interventionPlans;
            }
        });*/
    }
}

package com.inovalon.riskadjustment.memberattributes.util;

public class QueryBuilder {

    public static StringBuilder buildPrepareStatement(int size){
        StringBuilder idList = new StringBuilder();
       for (int i=0;i<size;i++){
            if (idList.length() > 0) {
                idList.append(",");
            }
            idList.append("?");
        }
        return idList;
    }
}

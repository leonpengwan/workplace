package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

public enum AttributeBeansEnum {

    StateDetermine("StateDetermine"),
    AgeDetermine("AgeDetermine"),
    AgeGroupDetermine("AgeGroupDetermine"),
    GroupPlanType("GroupPlanType");

    private String value;

    AttributeBeansEnum(String values) {
        this.value = values;
    }

    public String getValue() {
        return value;
    }
}

package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao.MemberEvidenceStatusDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberEvidenceStatusServiceImpl implements MemberEvidenceStatusService {
    @Autowired
    private MemberEvidenceStatusDao memberEvidenceStatusDao;

    @Override
    public int persistMemberEvidence(List<MemberEvidenceStatus> memberEvidenceStatuses, String userInfo) {
        try {
            if (memberEvidenceStatuses.isEmpty()) {
                System.out.println("json body empty for persist member evidence status");
                return 1;
            } else {

                memberEvidenceStatusDao.saveMemberEvidenceStatuses(memberEvidenceStatuses,userInfo);
                return 0;
            }
        } catch (DataIntegrityViolationException violationException) {
            System.out.println("MemberAttributes Persistence: MemberEvidenceStatus for member id: " + memberEvidenceStatuses.get(0).getMemberId()
                    + " and MemberAttributesRunId: " + memberEvidenceStatuses.get(0).getMemberAttributesRunId()
                    + ") already existed in table");
            return 2;
        } catch (Exception e) {
            e.printStackTrace();
            return 99;
        }
    }

}

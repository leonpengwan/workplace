package com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro;

import java.util.List;

public class Message {

   private  int batchId;
   private  java.lang.Long runProfileId;
   private  java.util.List<java.lang.Integer> memberIds;

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public Long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(Long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public List<Integer> getMemberIds() {
        return memberIds;
    }

    public void setMemberIds(List<Integer> memberIds) {
        this.memberIds = memberIds;
    }
}

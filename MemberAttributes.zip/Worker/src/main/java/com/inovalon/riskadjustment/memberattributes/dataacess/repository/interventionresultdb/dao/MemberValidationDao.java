package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberValidation;

public interface MemberValidationDao {
    int saveMemberValidation(MemberValidation memberValidation, String userInfo);
}

package com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro;

import java.util.List;

public class WorkerInputMessage {

    private long runProfileId;
    private int runId;
    private int batchId;
    private List<String> personIds;
    private String userInfo;
    private List<Integer> memberIds;
    private String statusDetail;
    private boolean messageStatus;

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getRunId() {
        return runId;
    }

    public void setRunId(int runId) {
        this.runId = runId;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public List<String> getPersonIds() {
        return personIds;
    }

    public void setPersonIds(List<String> personIds) {
        this.personIds = personIds;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public List<Integer> getMemberIds() {
        return memberIds;
    }

    public void setMemberIds(List<Integer> memberIds) {
        this.memberIds = memberIds;
    }

    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    public boolean isMessageStatus() {
        return messageStatus;
    }

    public void setMessageStatus(boolean messageStatus) {
        this.messageStatus = messageStatus;
    }
}

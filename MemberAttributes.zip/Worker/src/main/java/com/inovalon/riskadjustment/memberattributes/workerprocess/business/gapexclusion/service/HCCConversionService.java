package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccConversionExclusionList;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component("HCCConversion")
public class HCCConversionService implements GapExclusionService{
    @Autowired
    private LogWriter logWriter;

    /**
     * @param runProfile
     * @param memberEvidenceStatusList
     * @param cacheUtil
     * @param memberAttribute
     */
    @LogBeforeEvents
    @Override
    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatusList, CacheUtil cacheUtil, MemberAttribute memberAttribute) {

        try {
            //key of the map 'clientId-hccCode'
            Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = cacheUtil.getHhsHccConversionExclusion();

            //Get the exclusion id
            ExclusionTypeModel hccConversionModel = cacheUtil.getExclusionTypeModelMap().get(GapExclusionConstants.HCC_CONVERSION);

            for (MemberEvidenceStatus memberEvidenceStatus : memberEvidenceStatusList) {
                if (memberEvidenceStatus.getExclusionId() == 0) {
                    ModelHhsHccConversionExclusionList modelHhsHccConversionExclusionList = hccConversionExclusionListMap.get(runProfile.getClientId() + "-" + memberEvidenceStatus.getHccCode());
                    if (modelHhsHccConversionExclusionList == null) {
                        modelHhsHccConversionExclusionList = hccConversionExclusionListMap.get("0-" + memberEvidenceStatus.getHccCode());
                    }
                    if (modelHhsHccConversionExclusionList != null && modelHhsHccConversionExclusionList.isConverted()) {
                        //memberEvidenceStatus.setExclusionId(hccConversionModel.getExclusionId());
                        memberEvidenceStatus.setOriginalHccCode(modelHhsHccConversionExclusionList.getHccCode());
                        memberEvidenceStatus.setHccCode(modelHhsHccConversionExclusionList.getLowestLevelHccCode());
                    }

                }
            }

        } catch (Exception e) {
            logWriter.info ( "Exception while processing HCC Conversion. Message: " + e.getStackTrace ( ) );
        }
    }
}
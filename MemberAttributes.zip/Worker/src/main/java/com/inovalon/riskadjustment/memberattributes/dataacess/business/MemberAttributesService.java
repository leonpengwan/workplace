package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;

public interface MemberAttributesService {
    int persistMemberAttributes(MemberAttribute memberAttribute, String userInfo);
}

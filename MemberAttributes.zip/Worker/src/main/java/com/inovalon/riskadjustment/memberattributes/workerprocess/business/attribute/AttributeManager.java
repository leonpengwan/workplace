package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.AttributeBeansEnum;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.MemberAttributeIdentification;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues.MemberAttributeIdentificationFactoryService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.MemberProfileRealization;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.MemberProfileRealizationFactoryService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.RulzBeanEnum;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.patient.service.PatientService;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by pwan on 1/15/2018.
 */
@Component
public class AttributeManager {

    private final static DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    private PatientService patientService;

    @Autowired
    private MemberProfileRealizationFactoryService memberProfileRealizationFactory;

    @Autowired
    private MemberAttributeIdentificationFactoryService memberAttributeIdentificationFactoryService;

    @Autowired
    private LogWriter logWriter;

    /**
     * @param memberAttribute
     * @param runProfile
     * @param stagingMessage
     * @param cacheUtil
     * @throws Exception
     */
    @LogBeforeEvents

    public void getMemberAttributeAvro(MemberAttribute memberAttribute, RunProfile runProfile, StagingMessage stagingMessage, CacheUtil cacheUtil) throws Exception {

        PatientProfile patientProfile = stagingMessage.getPatientProfile();

        if (patientProfile == null) {
            memberAttribute.setMissingProfile(true);
            return;
        }
        memberAttribute.setMemberId(patientProfile.getMemberId());
        Enrollment winningEnrolment = patientService.getWinningEnrollment(new ArrayList<>(patientProfile.getEnrollments()));
        logWriter.info("WinningEnrollmentId: " + winningEnrolment.getMemberEnrollmentId());
        memberAttribute.setWinningEnrollmentId(winningEnrolment.getMemberEnrollmentId());
        logWriter.info("Extracting MetalLevel starts");
        patientService.getMetalLevel(memberAttribute, patientProfile.getEnrollments(), cacheUtil.getHhsMetalLevel());
        logWriter.info("Applying attribute for memberid: " + patientProfile.getMemberId());
        retrievePlanningDate(runProfile, memberAttribute);


        patientService.getAttributedPractitionerId(patientProfile, stagingMessage.getProviderProfiles(), memberAttribute);

        //Set the member attribute plan id
        memberAttribute.setPlanId(winningEnrolment.getEnrollmentBenefitPlanId());

        //Set the member Attribute for MissingFirstName
        memberAttribute.setMissingFirstName(StringUtils.isEmpty(patientProfile.getFirstName()));

        //Set the member Attribute for MissingLastName
        memberAttribute.setMissingLastName(StringUtils.isEmpty(patientProfile.getLastName()));

        //apply rule#3 by passing the same above member object reference
        memberAttribute.setMissingDateOfBirth(patientProfile.getBirthDate() != null ? false : true);

        //Set the member Attribute for deceased
        memberAttribute.setDeceased(patientProfile.getDeceasedDate() != null ? true : false);

        for (RulzBeanEnum className : RulzBeanEnum.values()) {
            MemberProfileRealization memberProfileRealization = memberProfileRealizationFactory.beanRequest(className);

            memberProfileRealization.applyRules(runProfile, stagingMessage, memberAttribute, cacheUtil);
        }

        for (AttributeBeansEnum className : AttributeBeansEnum.values()) {

            MemberAttributeIdentification memberAttributeIdentification = memberAttributeIdentificationFactoryService.beanRequest(className);
            //MemberAttributeIdentification memberAttributeIdentification = (MemberAttributeIdentification) applicationContext.getBean(className.getValue());
            memberAttributeIdentification.setAttributeValue(runProfile, patientProfile, memberAttribute, cacheUtil);
        }

        return;
    }


    /**
     * @param runProfile
     * @param memberAttribute
     * @return
     */
    @LogBeforeEvents
    private void retrievePlanningDate(RunProfile runProfile, MemberAttribute memberAttribute) {

        if (runProfile != null && runProfile.getSections() != null &&
                runProfile.getSections().getInterventionPlanTimeframe() != null &&
                runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod() != null) {
            Date planningMonthStartDate = runProfile.getSections().getInterventionPlanTimeframe().getInterventionPlanPeriod().getStart();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(planningMonthStartDate);
            calendar.set(Calendar.DATE, calendar.getActualMinimum(calendar.DAY_OF_MONTH));
            memberAttribute.setPlanningMonthStartDate(calendar.getTime());
            calendar.set(Calendar.DATE, calendar.getActualMaximum(calendar.DAY_OF_MONTH));
            memberAttribute.setPlanningMonthEndDate(calendar.getTime());

        }


    }
}

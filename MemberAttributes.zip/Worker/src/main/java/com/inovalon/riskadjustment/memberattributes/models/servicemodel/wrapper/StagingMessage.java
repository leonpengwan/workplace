package com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile.ProviderProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;

import java.util.List;

public class StagingMessage {
    private long runProfileId;
    private int MemberAttributesRunId;
    private List<MemberEvidence> memberEvidences;
    private PatientProfile patientProfile;
    private List<ProviderProfile> providerProfiles;
    private List<InterventionPlan> interventionPlans;


    public StagingMessage() {
    }

    public StagingMessage(long runProfileId, int memberAttributesRunId, List<MemberEvidence> memberEvidences, PatientProfile patientProfile, List<ProviderProfile> providerProfiles, List<InterventionPlan> interventionPlans) {
        this.runProfileId = runProfileId;
        MemberAttributesRunId = memberAttributesRunId;
        this.memberEvidences = memberEvidences;
        this.patientProfile = patientProfile;
        this.providerProfiles = providerProfiles;
        this.interventionPlans = interventionPlans;
    }

    public long getRunProfileId() {
        return runProfileId;
    }

    public void setRunProfileId(long runProfileId) {
        this.runProfileId = runProfileId;
    }

    public int getMemberAttributesRunId() {
        return MemberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        MemberAttributesRunId = memberAttributesRunId;
    }

    public List<MemberEvidence> getMemberEvidences() {
        return memberEvidences;
    }

    public void setMemberEvidences(List<MemberEvidence> memberEvidences) {
        this.memberEvidences = memberEvidences;
    }

    public PatientProfile getPatientProfile() {
        return patientProfile;
    }

    public void setPatientProfile(PatientProfile patientProfile) {
        this.patientProfile = patientProfile;
    }

    public List<ProviderProfile> getProviderProfiles() {
        return providerProfiles;
    }

    public void setProviderProfiles(List<ProviderProfile> providerProfiles) {
        this.providerProfiles = providerProfiles;
    }

    public List<InterventionPlan> getInterventionPlans() {
        return interventionPlans;
    }

    public void setInterventionPlans(List<InterventionPlan> interventionPlans) {
        this.interventionPlans = interventionPlans;
    }
}

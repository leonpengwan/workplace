package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;

public interface MemberAttributeDao {
    int saveMemberAttribute(MemberAttribute memberAttribute, String userInfo);
}

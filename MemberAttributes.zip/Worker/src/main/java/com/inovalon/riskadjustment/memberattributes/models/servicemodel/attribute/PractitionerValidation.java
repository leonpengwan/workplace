package com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute;


public class PractitionerValidation {
    private int practitionerValidationId;
    private int memberAttributesRunId;
    private int practitionerId;
    private boolean invalidName;
    private boolean invalidAddress;
    private boolean invalidPhone;
    private boolean invalidFax;

    public PractitionerValidation() {
    }

    public PractitionerValidation(int practitionerValidationId, int memberAttributesRunId, int practitionerId, boolean invalidName, boolean invalidAddress, boolean invalidPhone, boolean invalidFax) {
        this.practitionerValidationId = practitionerValidationId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.practitionerId = practitionerId;
        this.invalidName = invalidName;
        this.invalidAddress = invalidAddress;
        this.invalidPhone = invalidPhone;
        this.invalidFax = invalidFax;
    }

    public int getPractitionerValidationId() {
        return practitionerValidationId;
    }

    public void setPractitionerValidationId(int practitionerValidationId) {
        this.practitionerValidationId = practitionerValidationId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public int getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(int practitionerId) {
        this.practitionerId = practitionerId;
    }

    public boolean isInvalidName() {
        return invalidName;
    }

    public void setInvalidName(boolean invalidName) {
        this.invalidName = invalidName;
    }

    public boolean isInvalidAddress() {
        return invalidAddress;
    }

    public void setInvalidAddress(boolean invalidAddress) {
        this.invalidAddress = invalidAddress;
    }

    public boolean isInvalidPhone() {
        return invalidPhone;
    }

    public void setInvalidPhone(boolean invalidPhone) {
        this.invalidPhone = invalidPhone;
    }

    public boolean isInvalidFax() {
        return invalidFax;
    }

    public void setInvalidFax(boolean invalidFax) {
        this.invalidFax = invalidFax;
    }
}

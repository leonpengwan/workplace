package com.inovalon.riskadjustment.memberattributes.dataacess.business;


import com.inovalon.riskadjustment.memberattributes.dataacess.repository.gapresultdb.dao.MemberEvidenceEntityDao;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberEvidenceServiceImpl implements MemberEvidenceService {

    @Autowired
    private MemberEvidenceEntityDao memberEvidenceDao;

    /**
     * @param gapSetId
     * @return size of distinct memberId for a given gapset
     @Override public Integer getMemberCount(String gapSetId) {
     System.out.println("MemberEvidenceServiceImpl:: getMemberCount: begining..");
     Integer count = memberEvidenceDao.getDistinctMemberCountByGapSetId(gapSetId);
     System.out.println("MemberEvidenceServiceImpl:: getMemberCount: Ending..");
     return count;
     }

     *//**
     * @param gapSetId
     * @param size
     * @param memberId
     * @return list of memberIds for a given gapSetId
     * @throws Exception
     *//*
    @Override
    public List<Integer> getGapMemberIds(String gapSetId, int size, int memberId) throws Exception {
        List<Integer> memberIds = new ArrayList<Integer>();
        try {
            PageRequest pageRequest = new PageRequest(0, size, Sort.Direction.ASC, "memberId");
            memberIds = memberEvidenceDao.findGapmemberIds(gapSetId, memberId, pageRequest);

        } catch (Exception e) {
            throw new Exception("Operation is not successfull");
        }
        return memberIds;
    }*/

    /**
     * @param gapSetId
     * @param memberIds
     * @return list of memberEvidences
     * @throws Exception
     */
    @Override
    public List<MemberEvidence> retrieveMemberEvidencesForMemberAttributes(String gapSetId, List<Integer> memberIds) throws Exception {
        return memberEvidenceDao.findByGapSetDetailIdAndMemberIds(gapSetId, memberIds);
    }
}

package com.inovalon.riskadjustment.memberattributes.controller;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerInputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.avro.WorkerOuputMessageAvro;
import com.inovalon.riskadjustment.memberattributes.staging.business.Manager;
import com.inovalon.riskadjustment.model.servicemodel.common.WorkerPayload;
import com.inovalon.riskadjustment.model.servicemodel.common.WorkerResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController

@Api
public class MainController {
    @Autowired
    private Manager manager;


    @ApiOperation(value = "Method to start up process for a specified runProfileId", response = WorkerResponse.class)
    @RequestMapping(value = "/{runProfileId}/start", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public WorkerResponse start(
            @PathVariable(value = "runProfileId") long runProfileId,
            @RequestBody WorkerPayload payload)
            throws Exception {

        WorkerInputMessageAvro workerInputMessage = new WorkerInputMessageAvro();
        workerInputMessage.setRunProfileId(runProfileId);
        workerInputMessage.setUserInfo(payload.getUserInfo());
        workerInputMessage.setMemberIds(payload.getMemberIds());

        WorkerOuputMessageAvro workerOuputMessageAvro=manager.processInputBatchMessage(workerInputMessage);

        WorkerResponse workerResponse = new WorkerResponse(){{
            setStatus(workerOuputMessageAvro.getMessageStatus());
            setRunProfileId(runProfileId);
            setStatusDetail(workerOuputMessageAvro.getStatusDetail().toString());
            setUserInfo(payload.getUserInfo());
            setRunId(workerOuputMessageAvro.getRunId());
        }};
        return workerResponse;
    }
}

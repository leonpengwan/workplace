package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service.GapExclusionBean;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service.GapExclusionService;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.GapDataSelection;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by pwan on 1/15/2018.
 */
@Component
public class GapExclusionManager {
    private final static String SA_GAP = "SA";
    @Autowired
    private LogWriter logWriter;

    @Autowired
    private ApplicationContext applicationContext;
    private static String ExclusionGroup = "GAP";



    @LogBeforeEvents
    public List<MemberEvidenceStatus> HCCExclusions(RunProfile runProfile, MemberAttribute memberAttribute, String genderCode, List<MemberEvidence> memberEvidences, CacheUtil cacheUtil) throws Exception {

        int memberAttributeRunId = memberAttribute.getMemberAttributesRunId();

        int gapSetDetailId = getGapSetDetailIdFromRunProfile(runProfile);

        List<MemberEvidenceStatus> memberEvidenceStatuses = mapMemberEvidenceToMemberEvidenceStatus(memberEvidences, gapSetDetailId, memberAttributeRunId,0);
        if(memberAttribute.isTermed()){
            ExclusionTypeModel exclusionTypeModel = cacheUtil.getExclusionTypeModelMap ( ).get ( GapExclusionConstants.TERMED);
           memberEvidenceStatuses  = mapMemberEvidenceToMemberEvidenceStatus(memberEvidences, gapSetDetailId, memberAttributeRunId,exclusionTypeModel.getExclusionId());
           return memberEvidenceStatuses;
        }else if(memberAttribute.isDeceased()){
            ExclusionTypeModel exclusionTypeModel = cacheUtil.getExclusionTypeModelMap ( ).get ( GapExclusionConstants.DECEASED);
            memberEvidenceStatuses  = mapMemberEvidenceToMemberEvidenceStatus(memberEvidences, gapSetDetailId, memberAttributeRunId,exclusionTypeModel.getExclusionId());
            return memberEvidenceStatuses;
        }
        List<MemberEvidenceStatus> saGaps = new ArrayList<>();
        for (MemberEvidenceStatus  memberEvidenceStatus: memberEvidenceStatuses) {
            if(memberEvidenceStatus.getGapType()!=null && memberEvidenceStatus.getGapType().toUpperCase().contains(SA_GAP)){
                saGaps.add(memberEvidenceStatus);
            }
        }



        // SA gaps
        //List<MemberEvidenceStatus> saGaps = memberEvidenceStatuses.stream().filter(g -> g.getGapType().toUpperCase().contains(SA_GAP)).collect(Collectors.toList());

        // Filter SA gaps for bypassing sa gaps from gap exclusion logic
        memberEvidenceStatuses = memberEvidenceStatuses.stream().filter(g -> !saGaps.contains(g)).collect(Collectors.toList());

        // Only GAP Exclusion Types
        List<ExclusionTypeModel> gapExclusionTypes = cacheUtil.getExclusionTypeModels().stream()
                .filter(type -> type.getExclusionGroup().toUpperCase().equals(this.ExclusionGroup))
                .collect(Collectors.toList());

        // Loop thru all exclusion type by hierarchy
        for (ExclusionTypeModel exclusionTypeModel : gapExclusionTypes) {
            if(GapExclusionBean.values()[exclusionTypeModel.getHierarchy()-1].getType().equalsIgnoreCase("Attribute"))
                continue;
            GapExclusionBean beanName = GapExclusionBean.values()[exclusionTypeModel.getHierarchy() - 1];
            GapExclusionService gapExclusionService = (GapExclusionService) applicationContext.getBean(beanName.getValue());
            gapExclusionService.excludeGaps(runProfile, memberEvidenceStatuses, cacheUtil, memberAttribute);
        }
        memberEvidenceStatuses.addAll(saGaps);
//        return modelToAvroConverter.memberEvidencesToMemberEvidenceAvro(memberEvidenceStatuses);
        return memberEvidenceStatuses;
    }

    private int getGapSetDetailIdFromRunProfile(RunProfile runProfile) {
        //Fetch the gapSetDetailID to fetch memberEvidence data
        for (GapDataSelection gapDataSelection : runProfile.getSections().getGapDataSelection().getGapDataSelections()) {
            if (gapDataSelection.getSelected()) {
                return gapDataSelection.getGapSetDetailId();
            }
        }
        return 0;
    }

   @LogBeforeEvents
    private List<MemberEvidenceStatus> mapMemberEvidenceToMemberEvidenceStatus(List<MemberEvidence> memberEvidences, int gapSetDetailId, int memberStatusRunId, int exclusionId) {
        List<MemberEvidenceStatus> memberEvidenceStatuses = new ArrayList<>(memberEvidences.size());
        for (MemberEvidence memberEvidence : memberEvidences) {
            MemberEvidenceStatus memberEvidenceStatus = new MemberEvidenceStatus();
            memberEvidenceStatus.setMemberEvidenceId(memberEvidence.getMemberEvidenceId());
            memberEvidenceStatus.setGapSetDetailId(gapSetDetailId);
            memberEvidenceStatus.setMemberId(memberEvidence.getMemberId());
            memberEvidenceStatus.setPersonId(memberEvidence.getPersonId());
            memberEvidenceStatus.setPractitionerId(memberEvidence.getPractitionerId());
            memberEvidenceStatus.setEncounterId(memberEvidence.getEncounterId());
            memberEvidenceStatus.setEncounterServiceDate(memberEvidence.getEncounterServiceDate() != null ? memberEvidence.getEncounterServiceDate().toString() : null);
            memberEvidenceStatus.setHccCode(memberEvidence.getHcc());
            memberEvidenceStatus.setGapConfidenceValue(memberEvidence.getGapConfidenceValue());
            memberEvidenceStatus.setGapConfidenceLevel(memberEvidence.getGapConfidenceLevel());
            memberEvidenceStatus.setExclusionId(exclusionId); //All unexcluded records are set to 0
            memberEvidenceStatus.setGapType(memberEvidence.getGapType());
            memberEvidenceStatus.setMemberAttributesRunId(memberStatusRunId);
            memberEvidenceStatus.setSaGapValue(memberEvidence.getSaGapValue());
            memberEvidenceStatus.setMeasureKey(memberEvidence.getMeasureKey() != null ? memberEvidence.getMeasureKey() : null);
            memberEvidenceStatuses.add(memberEvidenceStatus);
        }
        return memberEvidenceStatuses;
    }
}

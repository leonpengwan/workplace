package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;

public interface MemberProfileRealization {

    public void applyRules(RunProfile runProfile, StagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil);
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.attributevalues;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.exception.RangException;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("StateDetermine")
public class StateDetermine implements MemberAttributeIdentification {
    @Autowired
    private LogWriter logWriter;

    /**
     * It is used to identify the state of patient.
     *
     * @param runProfile
     * @param patientProfile
     * @param memberAttribute
     * @param cacheUtil
     * @throws RangException
     */

    @Override
    public void setAttributeValue(RunProfile runProfile, PatientProfile patientProfile, MemberAttribute memberAttribute, CacheUtil cacheUtil) throws RangException {
        try {
            logWriter.info("Beginning of StateDetermine");
            String state = patientProfile.getStateCode();
            memberAttribute.setState(state);
            logWriter.info("Ending of StateDetermine");
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
            throw new RangException(ex);
        }
    }


}

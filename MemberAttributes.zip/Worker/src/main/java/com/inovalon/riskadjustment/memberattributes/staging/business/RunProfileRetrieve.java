package com.inovalon.riskadjustment.memberattributes.staging.business;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.cachewrapper.util.CacheUtil;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.model.servicemodel.cache.RunProfileModel;
import com.inovalon.riskadjustment.model.servicemodel.cache.constant.CacheNameConstant;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RunProfileRetrieve {


    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private LogWriter logWriter;

    @Autowired
    private Gateway gateway;

    /**
     * This method will get the runProfile based on runProfileId
     *
     * @param runProfileId
     * @return It returns runProfile
     */
    @LogBeforeEvents
    public RunProfile getRunProfileByRunProfileId(long runProfileId) throws Exception {
        logWriter.info("Beginning of getRunProfileByRunProfileId method");
        RunProfile runProfile = new RunProfile();
        RunProfileModel model = (RunProfileModel) cacheUtil.getCacheData(CacheNameConstant.RUN_PROFILE, runProfileId);
        runProfile = gateway.getObjectFromString(model.getProfile(), new TypeReference<RunProfile>() {
        });
        return runProfile;
    }
}

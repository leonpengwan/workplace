package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service("HospiceIndicatorAttribute")
public class HospiceIndicatorAttribute implements MemberProfileRealization {

    /**
     * Set the Hospice MemberStatus
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();
        if (!Objects.isNull(patientProfile.getEnrollments())) {
            Enrollment enrollment = patientProfile.getEnrollments().iterator().next();
            if (enrollment.getMemberEnrollmentId() == memberAttribute.getWinningEnrollmentId()) {
                if ("Y".equalsIgnoreCase(enrollment.getHospiceInd())) {
                    memberAttribute.setHospice(Boolean.TRUE);
                }
            }
        }
    }
}

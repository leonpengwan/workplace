package com.inovalon.riskadjustment.memberattributes.dataacess.repository.gapresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;

import java.sql.SQLException;
import java.util.List;

public interface MemberEvidenceEntityDao /*extends JpaRepository<MemberEvidenceEntity, Integer>*/ {

    List<MemberEvidence> findByGapSetDetailIdAndMemberIds(String gapSetId, List<Integer> memberIds) throws SQLException;
}

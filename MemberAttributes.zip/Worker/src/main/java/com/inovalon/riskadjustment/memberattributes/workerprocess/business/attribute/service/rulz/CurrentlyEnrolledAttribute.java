package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("CurrentlyEnrolledAttribute")
public class CurrentlyEnrolledAttribute implements MemberProfileRealization {
    @Autowired
    private LogWriter logWriter;

    /*private static final String pattern = "yyyy-MM-dd HH:mm:ss";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(pattern);
    */
    //private final static SimpleDateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");


    /**
     * Apply CurrentEnrolled flag for eligible Member
     *
     * @param runProfile
     * @param customizedStagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage customizedStagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {

        PatientProfile patientProfile = customizedStagingMessage.getPatientProfile();

        if (memberAttribute.getPlanningMonthStartDate() == null) {
            return;
        }
        try {
            Date planningMonthStartDate = memberAttribute.getPlanningMonthStartDate();
            Date planningMonthEndDate = memberAttribute.getPlanningMonthEndDate();
            for (Enrollment enrollment : patientProfile.getEnrollments()) {
                Date startDate = StringToDate.getDate(enrollment.getCoverageBeginDate());
                Date endDate = StringToDate.getDate(enrollment.getCoverageEndDate());

                if (endDate != null && startDate != null) {
                    /*Calendar planningMonthStart = Calendar.getInstance();
                    // set date to 1st of that month
                    planningMonthStart.setTime(planningMonthDate);
                    planningMonthStart.set(Calendar.DAY_OF_MONTH, planningMonthStart.getActualMinimum(Calendar.DAY_OF_MONTH));
                    Date planningMonthStartDate = planningMonthStart.getTime();
                    Calendar planningMonthEnd = Calendar.getInstance();
                    planningMonthEnd.setTime(planningMonthStartDate);
                    planningMonthEnd.set(Calendar.DATE, planningMonthEnd.getActualMaximum(Calendar.DAY_OF_MONTH));

                    Calendar enrollmentStartDate = Calendar.getInstance();
                    enrollmentStartDate.setTime(startDate);
                    Calendar enrollmentEndDate = Calendar.getInstance();
                    enrollmentEndDate.setTime(endDate);*/

                    if ((startDate.before(planningMonthStartDate) || startDate.equals(planningMonthStartDate)) &&
                            (endDate.after(planningMonthEndDate) || endDate.equals(planningMonthEndDate))) {
                        memberAttribute.setCurrentlyEnrolled(true);
                        return;
                    }
                }
            }
        } catch (Exception ex) {
            logWriter.error("unable to parse coverageEndDate from String to Date in Enrollment: " + ex.getMessage());

        }
    }


}

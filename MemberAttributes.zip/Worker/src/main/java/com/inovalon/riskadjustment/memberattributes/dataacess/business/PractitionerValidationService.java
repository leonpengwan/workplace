package com.inovalon.riskadjustment.memberattributes.dataacess.business;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;

public interface PractitionerValidationService {
    int persistPractitionerValidation(PractitionerValidation practitionerValidation, String userInfo);
}

package com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache;

import com.inovalon.riskadjustment.model.servicemodel.cache.*;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.modelhhsmetallevel.ModelHhsMetalLevel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;

import java.util.*;

public class CacheUtil {

    private List<ModelHhsHomeBoundCode> modelHhsHomeBoundListCpt = new ArrayList<>();
    private List<ModelHhsHomeBoundCode> modelHhsHomeBoundListHcpcs = new ArrayList<>();
    private List<ModelHhsHomeBoundCode> modelHhsHomeBoundListIcd = new ArrayList<>();
    private RunProfile runProfile;
    private List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies = new ArrayList<>();
    private Map<String, Integer> gapConfidenceLevels = new HashMap<>();
    private Map<String, ModelHhsHccConversionExclusionList> hhsHccConversionExclusion = new HashMap<>();
    private List<AgeGroup> ageGroup = new ArrayList<>();
    private Map<String, ModelHhsMetalLevel> hhsMetalLevel = new HashMap<>();
    private Set<String> validatedProviderIds = new HashSet<String>();
    private Map<String, ExclusionTypeModel> exclusionTypeModelMap = new HashMap<>();
	private List<ExclusionTypeModel> exclusionTypeModels = new ArrayList<>();
	private List<GroupPlanType> groupPlanTypes = new ArrayList<>();

    public List<ModelHhsStateLevelPremiumAmount> getModelHhsStateLevelPremiumAmounts() {
        return modelHhsStateLevelPremiumAmounts;
    }

    public void setModelHhsStateLevelPremiumAmounts(List<ModelHhsStateLevelPremiumAmount> modelHhsStateLevelPremiumAmounts) {
        this.modelHhsStateLevelPremiumAmounts = modelHhsStateLevelPremiumAmounts;
    }

    private List<ModelHhsStateLevelPremiumAmount> modelHhsStateLevelPremiumAmounts = new ArrayList<>();

    public List<ViewModelHhsFactorHcc> getViewModelHhsFactorHccs() {
        return viewModelHhsFactorHccs;
    }

    public void setViewModelHhsFactorHccs(List<ViewModelHhsFactorHcc> viewModelHhsFactorHccs) {
        this.viewModelHhsFactorHccs = viewModelHhsFactorHccs;
    }

    private List<ViewModelHhsFactorHcc> viewModelHhsFactorHccs = new ArrayList<>();

    public List<ModelHhsHccAgeGenderExclusion> getHhsHccAgeGenderExclusions() {
        return hhsHccAgeGenderExclusions;
    }

    public void setHhsHccAgeGenderExclusions(List<ModelHhsHccAgeGenderExclusion> hhsHccAgeGenderExclusions) {
        this.hhsHccAgeGenderExclusions = hhsHccAgeGenderExclusions;
    }

    private List<ModelHhsHccAgeGenderExclusion> hhsHccAgeGenderExclusions = new ArrayList<>();

    public Map<String, ModelHhsMetalLevel> getHhsMetalLevel() {
        return hhsMetalLevel;
    }

    public List<AgeGroup> getAgeGroup() {
        return ageGroup;
    }

    public Map<String, ModelHhsHccConversionExclusionList> getHhsHccConversionExclusion() {
        return hhsHccConversionExclusion;
    }

    public Map<String, Integer> getGapConfidenceLevels() {
        return gapConfidenceLevels;
    }

    public CacheUtil() {
        modelHhsHomeBoundListCpt = new ArrayList<>();
        modelHhsHomeBoundListHcpcs = new ArrayList<>();
        modelHhsHomeBoundListIcd = new ArrayList<>();
    }

    public List<ModelHhsHomeBoundCode> getModelHhsHomeBoundListCpt() {
        return modelHhsHomeBoundListCpt;
    }

    public void setModelHhsHomeBoundListCpt(List<ModelHhsHomeBoundCode> modelHhsHomeBoundListCpt) {
        this.modelHhsHomeBoundListCpt = modelHhsHomeBoundListCpt;
    }

    public List<ModelHhsHomeBoundCode> getModelHhsHomeBoundListHcpcs() {
        return modelHhsHomeBoundListHcpcs;
    }

    public void setModelHhsHomeBoundListHcpcs(List<ModelHhsHomeBoundCode> modelHhsHomeBoundListHcpcs) {
        this.modelHhsHomeBoundListHcpcs = modelHhsHomeBoundListHcpcs;
    }

    public List<ModelHhsHomeBoundCode> getModelHhsHomeBoundListIcd() {
        return modelHhsHomeBoundListIcd;
    }

    public void setModelHhsHomeBoundListIcd(List<ModelHhsHomeBoundCode> modelHhsHomeBoundListIcd) {
        this.modelHhsHomeBoundListIcd = modelHhsHomeBoundListIcd;
    }

    public RunProfile getRunProfile() {
        return runProfile;
    }

    public void setRunProfile(RunProfile runProfile) {
        this.runProfile = runProfile;
    }

    public List<ModelHhsHccCodeHierarchy> getHhsHccCodeHierarchies() {
        return hhsHccCodeHierarchies;
    }

    public void setHhsHccCodeHierarchies(List<ModelHhsHccCodeHierarchy> hhsHccCodeHierarchies) {
        this.hhsHccCodeHierarchies = hhsHccCodeHierarchies;
    }

    public void setGapConfidenceLevels(Map<String, Integer> gapConfidenceLevels) {
        this.gapConfidenceLevels = gapConfidenceLevels;
    }


    public void setHhsHccConversionExclusion(Map<String, ModelHhsHccConversionExclusionList> hhsHccConversionExclusion) {
        this.hhsHccConversionExclusion = hhsHccConversionExclusion;
    }

    public void setAgeGroup(List<AgeGroup> ageGroup) {
        this.ageGroup = ageGroup;
    }

		public void setHhsMetalLevel(Map<String, ModelHhsMetalLevel> hhsMetalLevel) {
			this.hhsMetalLevel = hhsMetalLevel;
		}


	public Map<String, ExclusionTypeModel> getExclusionTypeModelMap() {
		return exclusionTypeModelMap;
	}

	public void setExclusionTypeModelMap(Map<String, ExclusionTypeModel> exclusionTypeModelMap) {
		this.exclusionTypeModelMap = exclusionTypeModelMap;
	}

    public Set<String> getValidatedProviderIds() {
        return validatedProviderIds;
    }

	public List<ExclusionTypeModel> getExclusionTypeModels() {
		return exclusionTypeModels;
	}

	public void setExclusionTypeModels(List<ExclusionTypeModel> exclusionTypeModels) {
		this.exclusionTypeModels = exclusionTypeModels;
	}

	public List<GroupPlanType> getGroupPlanTypes() {
		return groupPlanTypes;
	}

	public void setGroupPlanTypes(List<GroupPlanType> groupPlanTypes) {
		this.groupPlanTypes = groupPlanTypes;
	}
    public void setValidatedProviderIds(Set<String> validatedProviderIds) {
        this.validatedProviderIds = validatedProviderIds;
    }

}

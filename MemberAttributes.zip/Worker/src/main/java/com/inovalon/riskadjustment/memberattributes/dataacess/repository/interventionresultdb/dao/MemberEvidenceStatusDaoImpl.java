package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


@Repository
public class MemberEvidenceStatusDaoImpl implements MemberEvidenceStatusDao {


    @Autowired @Qualifier("interventionResultJdbcTemplate") private JdbcTemplate internvetionPlanResultTemplate;


    private final static String INSERT_QUERY = "insert into dbo.MemberEvidenceStatus (" +
            "MemberAttributesRunId," +
            "MemberEvidenceId," +
            "GapSetDetailId," +
            "MemberId," +
            "PersonId," +
            "PractitionerId," +
            "EncounterId," +
            "EncounterServiceDate," +
            "HccCode," +
            "OriginalHccCode," +
            "GapConfidenceValue," +
            "GapConfidenceLevel," +
            "GapType," +
            "ExclusionId," +
            "MeasureKey," +
            "SAGapValue,ModifiedBy,CreatedBy) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    @Override
    public List<Integer> saveMemberEvidenceStatuses(List<MemberEvidenceStatus> memberEvidenceStatuses, String userInfo) {
        List<Integer> ids = new ArrayList<>();
        for (MemberEvidenceStatus memberEvidenceStatus:memberEvidenceStatuses) {
            Object[] params = new Object[]{
                    memberEvidenceStatus.getMemberAttributesRunId(),
                    memberEvidenceStatus.getMemberEvidenceId(),
                    memberEvidenceStatus.getGapSetDetailId(),
                    memberEvidenceStatus.getMemberId(),
                    memberEvidenceStatus.getPersonId(),
                    memberEvidenceStatus.getPractitionerId(),
                    memberEvidenceStatus.getEncounterId(),
                    memberEvidenceStatus.getEncounterServiceDate(),
                    memberEvidenceStatus.getHccCode(),
                    memberEvidenceStatus.getOriginalHccCode(),
                    memberEvidenceStatus.getGapConfidenceValue(),
                    memberEvidenceStatus.getGapConfidenceLevel(),
                    memberEvidenceStatus.getGapType(),
                    memberEvidenceStatus.getExclusionId(),
                    memberEvidenceStatus.getMeasureKey(),
                    memberEvidenceStatus.getSaGapValue(),userInfo,userInfo};
            int id = internvetionPlanResultTemplate.update(INSERT_QUERY, params);
            ids.add(id);
        }

        return ids;

    }
}

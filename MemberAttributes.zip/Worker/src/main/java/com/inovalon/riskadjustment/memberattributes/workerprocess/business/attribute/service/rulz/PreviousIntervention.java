package com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.InterventionPlan;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service("PreviousIntervention")
public class PreviousIntervention implements MemberProfileRealization {

    /**
     * @param runProfile
     * @param stagingMessage
     * @param memberAttribute
     * @param cacheUtil
     */
    @LogBeforeEvents
    @Override
    public void applyRules(RunProfile runProfile, StagingMessage stagingMessage, MemberAttribute memberAttribute, CacheUtil cacheUtil) {
        List<InterventionPlan> interventionPlanList = stagingMessage.getInterventionPlans();
        if (CollectionUtils.isEmpty(interventionPlanList)) {
            memberAttribute.setNoPreviousIntervention(true);
        }


    }
}

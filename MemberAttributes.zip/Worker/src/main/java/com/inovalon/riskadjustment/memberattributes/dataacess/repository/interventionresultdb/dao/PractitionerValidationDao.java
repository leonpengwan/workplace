package com.inovalon.riskadjustment.memberattributes.dataacess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.PractitionerValidation;


public interface PractitionerValidationDao {
    int savePratcitionerValidation(PractitionerValidation practitionerValidation, String userInfo);
}

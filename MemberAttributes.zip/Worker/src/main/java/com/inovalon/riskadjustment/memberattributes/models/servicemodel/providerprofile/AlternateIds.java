package com.inovalon.riskadjustment.memberattributes.models.servicemodel.providerprofile;

public class AlternateIds {

    private String providerId;
    private String providerAltId1;
    private String providerAltId2;
    private String providerAltid3;
    private String providerAltId4;
    private String providerAltId5;
    private String providerAltId6;
    private String providerAltId7;
    private String providerAltid8;
    private String providerAltid9;
    private String providerAltId10;

    public AlternateIds() {

    }

    public AlternateIds(String providerId, String providerAltId1, String providerAltId2, String providerAltid3, String providerAltId4, String providerAltId5, String providerAltId6, String providerAltId7, String providerAltid8, String providerAltid9, String providerAltId10, String altId10) {
        this.providerId = providerId;
        this.providerAltId1 = providerAltId1;
        this.providerAltId2 = providerAltId2;
        this.providerAltid3 = providerAltid3;
        this.providerAltId4 = providerAltId4;
        this.providerAltId5 = providerAltId5;
        this.providerAltId6 = providerAltId6;
        this.providerAltId7 = providerAltId7;
        this.providerAltid8 = providerAltid8;
        this.providerAltid9 = providerAltid9;
        this.providerAltId10 = providerAltId10;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getProviderAltId1() {
        return providerAltId1;
    }

    public void setProviderAltId1(String providerAltId1) {
        this.providerAltId1 = providerAltId1;
    }

    public String getProviderAltId2() {
        return providerAltId2;
    }

    public void setProviderAltId2(String providerAltId2) {
        this.providerAltId2 = providerAltId2;
    }

    public String getProviderAltid3() {
        return providerAltid3;
    }

    public void setProviderAltid3(String providerAltid3) {
        this.providerAltid3 = providerAltid3;
    }

    public String getProviderAltId4() {
        return providerAltId4;
    }

    public void setProviderAltId4(String providerAltId4) {
        this.providerAltId4 = providerAltId4;
    }

    public String getProviderAltId5() {
        return providerAltId5;
    }

    public void setProviderAltId5(String providerAltId5) {
        this.providerAltId5 = providerAltId5;
    }

    public String getProviderAltId6() {
        return providerAltId6;
    }

    public void setProviderAltId6(String providerAltId6) {
        this.providerAltId6 = providerAltId6;
    }

    public String getProviderAltId7() {
        return providerAltId7;
    }

    public void setProviderAltId7(String providerAltId7) {
        this.providerAltId7 = providerAltId7;
    }

    public String getProviderAltid8() {
        return providerAltid8;
    }

    public void setProviderAltid8(String providerAltid8) {
        this.providerAltid8 = providerAltid8;
    }

    public String getProviderAltid9() {
        return providerAltid9;
    }

    public void setProviderAltid9(String providerAltid9) {
        this.providerAltid9 = providerAltid9;
    }

    public String getProviderAltId10() {
        return providerAltId10;
    }

    public void setProviderAltId10(String providerAltId10) {
        this.providerAltId10 = providerAltId10;
    }
}

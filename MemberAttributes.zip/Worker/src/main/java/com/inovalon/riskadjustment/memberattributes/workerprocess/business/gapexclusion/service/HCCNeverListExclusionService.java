package com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.service;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.gapexclusion.util.GapExclusionConstants;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberEvidenceStatus;
import com.inovalon.riskadjustment.model.servicemodel.cache.ModelHhsHccConversionExclusionList;
import com.inovalon.riskadjustment.model.servicemodel.gapconfidencelevel.ExclusionTypeModel;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component("HCCNeverList")
public class HCCNeverListExclusionService implements GapExclusionService{
    @Autowired
    private LogWriter logWriter;

    private final static String GAP_TYPE_CEDI="CEDI";
    private final static String GAP_TYPE_UCCC="UCCC";
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public void excludeGaps(RunProfile runProfile, List<MemberEvidenceStatus> memberEvidenceStatuses, CacheUtil cacheUtil, MemberAttribute memberAttribute) {

        try {

            //key of the map 'clientId-hccCode'
            Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = cacheUtil.getHhsHccConversionExclusion();

            ExclusionTypeModel neverListExclusionTypeModel = cacheUtil.getExclusionTypeModelMap().get(GapExclusionConstants.HCC_NEVERLIST);
            ExclusionTypeModel neverListNullExclusionTypeModel = cacheUtil.getExclusionTypeModelMap().get(GapExclusionConstants.HCC_GAP_TYPE_NULL);

            for (MemberEvidenceStatus memberEvidenceStatus : memberEvidenceStatuses) {
                if (memberEvidenceStatus.getExclusionId() == 0) {
                    String gapType = memberEvidenceStatus.getGapType();

                    if (StringUtils.isBlank(gapType)) {
                        memberEvidenceStatus.setExclusionId(neverListNullExclusionTypeModel.getExclusionId());
                    } else {
                        gapType = gapType.toUpperCase().contains(GAP_TYPE_CEDI) ? GAP_TYPE_CEDI : (gapType.toUpperCase().contains(GAP_TYPE_UCCC) ? GAP_TYPE_UCCC : "Unknown");
                        ModelHhsHccConversionExclusionList modelHhsHccConversionExclusionList = hccConversionExclusionListMap.get(runProfile.getClientId() + "-" + memberEvidenceStatus.getHccCode());
                        modelHhsHccConversionExclusionList = Objects.isNull(modelHhsHccConversionExclusionList) ? hccConversionExclusionListMap.get("0-" + memberEvidenceStatus.getHccCode()) : null;
                        if (!Objects.isNull(modelHhsHccConversionExclusionList)) {
                            if ((gapType.equalsIgnoreCase(GAP_TYPE_CEDI) && (modelHhsHccConversionExclusionList.isExcludedCEDI() != null ? modelHhsHccConversionExclusionList.isExcludedCEDI() : false))
                                    || (gapType.equalsIgnoreCase(GAP_TYPE_UCCC) && (modelHhsHccConversionExclusionList.isExcludedUCCC() != null ? modelHhsHccConversionExclusionList.isExcludedUCCC() : false))) {
                                memberEvidenceStatus.setExclusionId(neverListExclusionTypeModel.getExclusionId());
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logWriter.error("Exception while processing HCC NeverList Exclusion. Message: " + e.getStackTrace());

        }
    }


    // Key for the map will be 'clientId-hccCode'. This will be used for Neverlist exclusion and HCC conversion
    private Map<String, ModelHhsHccConversionExclusionList> mapHccConversionExclusionListByClientIdAndHcc(List<ModelHhsHccConversionExclusionList> modelHhsHccConversionExclusionLists) {
        Map<String, ModelHhsHccConversionExclusionList> hccConversionExclusionListMap = new HashMap<>();
        try {
            modelHhsHccConversionExclusionLists.forEach(element -> {
                hccConversionExclusionListMap.put(element.getClientId() + "-" + element.getHccCode(), element);
            });
        } catch (Exception e) {
            logWriter.error("Failed to get modelHhsHccConversionExclusionLists!"+e.getMessage());
        }
        return hccConversionExclusionListMap;
    }
}
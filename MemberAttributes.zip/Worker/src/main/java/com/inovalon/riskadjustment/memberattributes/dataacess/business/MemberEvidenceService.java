package com.inovalon.riskadjustment.memberattributes.dataacess.business;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.MemberEvidence;

import java.util.List;

public interface MemberEvidenceService {
   /* Integer getMemberCount(String gapSetId);

    List<Integer> getGapMemberIds(String gapSetId, int size, int memberId) throws Exception;
*/
    List<MemberEvidence> retrieveMemberEvidencesForMemberAttributes(String gapSetId, List<Integer> memberIds) throws Exception;
}

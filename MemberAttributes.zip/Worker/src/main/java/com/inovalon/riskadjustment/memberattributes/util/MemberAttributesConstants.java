package com.inovalon.riskadjustment.memberattributes.util;


public class MemberAttributesConstants {
    //public static final String GET_MEMBER_EVIDENCE_BY_GAP_SET_DETAIL_ID_PER_BATCH = "/riskanalytics/gapresult/retrieveMemberEvidencesWithGapSetDetailIdAndMemberId";
    public static final String GET_RUN_PROFILE = "/configdbservice/retrieverunprofile";
    public static final String GET_MEMBER_IDS_BY_BATCH = "/risk-analytics/gap-result/gapMembers";
    public static final String GET_MEMBER_EVIDENCE_BY_GAP_SET_DETAIL_ID_ON_MEMBER_IDS = "/risk-analytics/gap-result/retrieveMemberEvidencesByMemberIds";
    public static final String GET_MEMBER_ATTRIBUTES_RUN_ID_BY_RUN_PROFILE_ID = "/configdbservice/retrieveMemberAttributesRunId";
    public static final String GET_STATUS_UPDATED = "/configdbservice/updateMemberAttributesStatus";
    public static final String GET_FULL_PATIENT_PROFILE = "/patient-profiles";
    public static final String GET_FULL_PROVIDER_PROFILE="/provider-profiles?idType=clientproviderid";
    public static final String GET_INTERVENTION_PLANS = "/risk-analytics/intervention-plan-result/intervention-plans";
    public static final String GET_INTERVENTION_PLAN_RUN_IDS = "/configdbservice/retrieveInterventionPlanRun";


}

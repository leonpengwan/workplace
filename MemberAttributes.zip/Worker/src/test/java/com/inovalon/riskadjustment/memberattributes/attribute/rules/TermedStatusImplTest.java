package com.inovalon.riskadjustment.memberattributes.attribute.rules;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.TermedAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Ignore
public class TermedStatusImplTest {

    @InjectMocks
    private TermedAttribute termedAttribute;
    private StagingMessage message;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;
    private Date date;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        memberAttribute = new MemberAttribute();
        message = new StagingMessage();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        cacheUtil = new CacheUtil();
        runProfile = new RunProfile();
        Calendar calendar = Calendar.getInstance();
        date = calendar.getTime();

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void isTermedTrue() {
        PatientProfile patientProfile = new PatientProfile();
        message.setPatientProfile(patientProfile);
        Set<Enrollment> enrollmentList = new HashSet<>();
        patientProfile.setEnrollments(enrollmentList);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageEndDate = new Date(date.getYear(), 0, 25);
        enrollment.setCoverageEndDate(coverageEndDate.toString());
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        termedAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isTermed should be true", true, memberAttribute.isTermed());
    }

    @Test
    public void isTermedFalse() {
        PatientProfile patientProfile = new PatientProfile();
        message.setPatientProfile(patientProfile);
        Set<Enrollment> enrollmentList = new HashSet<>();
        patientProfile.setEnrollments(enrollmentList);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageEndDate = new Date(date.getYear(), 12, 31);
        enrollment.setCoverageEndDate(coverageEndDate.toString());
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        termedAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isTermed should be false", false, memberAttribute.isTermed());
    }

}

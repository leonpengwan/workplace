package com.inovalon.riskadjustment.memberattributes.attribute.rules;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.HospiceIndicatorAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Ignore
public class HospiceIndicatorStatusImplTest {

    @InjectMocks
    private HospiceIndicatorAttribute mockHospiceIndicatorAttribute;
    private StagingMessage message;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        message = new StagingMessage();

        memberAttribute = new MemberAttribute();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        memberAttribute.setWinningEnrollmentId(1);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void checkingHospiceIndTrue() {
        PatientProfile patientProfile = new PatientProfile();
        Set<Enrollment> enrollmentList = new HashSet<>();
        Enrollment enrollment = new Enrollment();
        enrollment.setMemberEnrollmentId(1);
        enrollment.setHospiceInd("Y");
        enrollmentList.add(enrollment);
        patientProfile.setEnrollments(enrollmentList);
        message.setPatientProfile(patientProfile);
        mockHospiceIndicatorAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Hospice should be true", true, memberAttribute.isHospice());

    }

    @Test
    public void checkingHospiceIndFalse() {
        PatientProfile patientProfile = new PatientProfile();
        Set<Enrollment> enrollmentList = new HashSet<>();
        Enrollment enrollment = new Enrollment();
        enrollment.setMemberEnrollmentId(1);
        enrollment.setHospiceInd("N");
        enrollmentList.add(enrollment);
        patientProfile.setEnrollments(enrollmentList);
        message.setPatientProfile(patientProfile);
        mockHospiceIndicatorAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Hospice should be false", false, memberAttribute.isHospice());

    }

    /*@Test
    public void checkingHospiceIndNull() {
        patientProfileWithWinningEnrollment.getPatientProfile().getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        enrollment.setMemberEnrollmentId(1);
        patientProfileWithWinningEnrollment.getPatientProfile().getEnrollments().add(enrollment);
        mockHospiceIndicatorService.getHospiceIndStatusByMemberId(patientProfileWithWinningEnrollment, memberStatus);
        assertEquals("Hospice should be false", false, memberStatus.isHospiceInd());

    }*/
}



package com.inovalon.riskadjustment.memberattributes.attribute.rules;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Claim;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.PractitionerVisit;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Ignore
public class PractitionerVisitImplTest {

    @InjectMocks
    private PractitionerVisit mockPractitionerVisit;
    private StagingMessage message;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;
    private MemberAttribute memberAttribute;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        cacheUtil = new CacheUtil();
        message = new StagingMessage();
        runProfile = new RunProfile();
        memberAttribute = new MemberAttribute();
        memberAttribute.setPlanningMonthStartDate(Calendar.getInstance().getTime());

    }

    @After
    public void destory() {

    }


    @Test
    public void getPractitionerVisitFailCase() {
        PatientProfile patientProfile = new PatientProfile();
        List<Claim> claimList = new ArrayList<>();
        patientProfile.setClaims(claimList);

        Date currentDate = Calendar.getInstance().getTime();
        Calendar cal = Calendar.getInstance();
        cal.set(currentDate.getYear() - 2, currentDate.getMonth(), currentDate.getDate());
        Claim claim = new Claim();
        claim.setAdmissionDate(cal.getTime().toString());
        patientProfile.getClaims().add(claim);
        message.setPatientProfile(patientProfile);
        mockPractitionerVisit.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isTermed should be true", false, memberAttribute.isPcpVisit());
    }

    @Test
    public void getPractitionerVisitTrueCase() {

        PatientProfile patientProfile = new PatientProfile();
        List<Claim> claimList = new ArrayList<>();
        patientProfile.setClaims(claimList);

        Date currentDate = Calendar.getInstance().getTime();
        Calendar cal = Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) - 1, Calendar.DATE);
        Claim claim = new Claim();
        claim.setClientProviderId("1");
        claim.setAdmissionDate(cal.getTime().toString());

        patientProfile.getClaims().add(claim);
        message.setPatientProfile(patientProfile);
        mockPractitionerVisit.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isTermed should be true", true, memberAttribute.isPcpVisit());
    }

}

package com.inovalon.riskadjustment.memberattributes.attribute.values;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Ignore
public class StateDetermineImpl {

    @MockBean
    private StateDetermineImpl stateDetermine;
    private RunProfile runprofile;
    private MemberAttribute memberAttribute;
    private PatientProfile patientProfile;
    private CacheUtil cacheUtil;

    @Before
    public void init(){
        runprofile = new RunProfile();
        memberAttribute = new MemberAttribute();
        //memberAttribute.setPlanningMonthStartDate();
    }

    @Test
    public void test(){

    }
}

package com.inovalon.riskadjustment.memberattributes.attribute.rules;

import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.InfantAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Ignore
public class InfantStatusImplTest {

    @InjectMocks
    private InfantAttribute mockInfantAttribute;
    private StagingMessage message;
    private MemberAttribute memberAttribute;
    private RunProfile runProfile;
    private CacheUtil cacheUtil;
    private Date date;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        memberAttribute = new MemberAttribute();
        message = new StagingMessage();
        PatientProfile patientProfile = new PatientProfile();
        message.setPatientProfile(patientProfile);
        runProfile = new RunProfile();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        Calendar calendar = Calendar.getInstance();
        date = calendar.getTime();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void checkingInfantWithEmptyBirthDate() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        patientProfile.setBirthDate(null);
        message.setPatientProfile(patientProfile);
        mockInfantAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("By default isAgeExclusionLessThan3 is false when birth date is empty", false, memberAttribute.isAgeExclusionLessThan3());
    }

    @Test
    public void checkingInfantEligible() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        patientProfile.setBirthDate(new Date(date.getYear() - 1, 01, 25, 00, 00).toString());
        message.setPatientProfile(patientProfile);
        mockInfantAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Eligible as age difference is less than 3", true, memberAttribute.isAgeExclusionLessThan3());
    }

    @Test
    public void checkingInfantInEligible() throws ParseException {
        PatientProfile patientProfile = new PatientProfile();
        patientProfile.setBirthDate(new Date(date.getYear() - 5, 01, 25, 00, 00).toString());
        message.setPatientProfile(patientProfile);
        mockInfantAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("Eligible as age difference is not less than 3", false, memberAttribute.isAgeExclusionLessThan3());
    }
}



package com.inovalon.riskadjustment.memberattributes.attribute.rules;


import com.inovalon.riskadjustment.memberattributes.models.servicemodel.attribute.MemberAttribute;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.Enrollment;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.patientprofile.PatientProfile;
import com.inovalon.riskadjustment.memberattributes.models.servicemodel.wrapper.StagingMessage;
import com.inovalon.riskadjustment.memberattributes.util.StringToDate;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.attribute.service.rulz.CurrentlyEnrolledAttribute;
import com.inovalon.riskadjustment.memberattributes.workerprocess.business.cache.CacheUtil;
import com.inovalon.riskadjustment.model.servicemodel.runProfile.RunProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = CurrentlyEnrolledStatusImplTest.class)
@Ignore
public class CurrentlyEnrolledStatusImplTest {

    @InjectMocks
    private CurrentlyEnrolledAttribute currentlyEnrolledAttribute;
    private StagingMessage message;
    private MemberAttribute memberAttribute;
    private CacheUtil cacheUtil;
    private RunProfile runProfile;
    private Date date;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Calendar calendar = Calendar.getInstance();
        message = new StagingMessage();
        memberAttribute = new MemberAttribute();
        runProfile = new RunProfile();
        memberAttribute.setPlanningMonthStartDate(new Date(System.currentTimeMillis()));
        memberAttribute.setPlanningMonthEndDate(new Date(memberAttribute.getPlanningMonthStartDate().getYear(), 11, 31));
        date = calendar.getTime();

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void isCurrentlyEnrolledStatusTrue() {
        PatientProfile patientProfile = new PatientProfile();
        Set<Enrollment> enrollments = new HashSet<>();
        patientProfile.setEnrollments(enrollments);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageBeginDate = new Date(date.getYear(), 0, 1);
        Date coverageEndDate = new Date(date.getYear(), 11, 31);
        enrollment.setCoverageBeginDate(StringToDate.getStringDate(coverageBeginDate));
        enrollment.setCoverageEndDate(StringToDate.getStringDate(coverageEndDate));
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        currentlyEnrolledAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isCurrentlyEnrolled should be true", true, memberAttribute.isCurrentlyEnrolled());
    }

    @Test
    public void isCurrentlyEnrolledStatusFalse() {
        PatientProfile patientProfile = new PatientProfile();
        Set<Enrollment> enrollments = new HashSet<>();
        patientProfile.setEnrollments(enrollments);
        patientProfile.getEnrollments().clear();
        Enrollment enrollment = new Enrollment();
        Date coverageBeginDate = new Date(date.getYear() - 1, 10, 2);
        Date coverageEndDate = new Date(date.getYear() - 1, 11, 1);
        enrollment.setCoverageBeginDate(StringToDate.getStringDate(coverageBeginDate));
        enrollment.setCoverageEndDate(StringToDate.getStringDate(coverageEndDate));
        patientProfile.getEnrollments().add(enrollment);
        message.setPatientProfile(patientProfile);
        currentlyEnrolledAttribute.applyRules(runProfile, message, memberAttribute, cacheUtil);
        assertEquals("MemberStatus.isCurrentlyEnrolled should be false", false, memberAttribute.isCurrentlyEnrolled());
    }
}

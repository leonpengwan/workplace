package com.inovalon.riskadjustment.memberattributes.sharedmodel;


public class MemberAttributes {
    private int memberAttributesId;
    private int memberAttributesRunId;
    private int memberId;
    private String personId;
    private boolean missingProfile;
    private boolean newEnrollee;
    private boolean termed;
    private boolean missingLastName;
    private boolean missingFirstName;
    private boolean missingDateOfBirth;
    private boolean currentlyEnrolled;
    private boolean deceased;
    private boolean hospice;
    private boolean homebound;
    private String ageGroup;
    private boolean ageExclusionLessThan3;
    private int age;
    private int ageGroupId;
    private String metalLevel;
    private String groupPlanType;
    private String state;
    private int attributedPractitionerId;
    private long winningEnrollmentId;
    private boolean noPreviousIntervention;
    private boolean pastEfIntervention;
    private boolean pastSmeIntervention;
    private boolean pcpVisit;
    private int totalReachAttempts;
    private int successfulReachAttempts;
    private int notReached;
    private int reachRateCategoryId;
    private boolean completedEfSoapNote;

    public MemberAttributes() {
    }

    public MemberAttributes(int memberAttributesId, int memberAttributesRunId, int memberId, String personId, boolean missingProfile, boolean newEnrollee, boolean termed, boolean missingLastName, boolean missingFirstName, boolean missingDateOfBirth, boolean currentlyEnrolled, boolean deceased, boolean hospice, boolean homebound, String ageGroup, boolean ageExclusionLessThan3, int age, int ageGroupId, String metalLevel, String groupPlanType, String state, int attributedPractitionerId, long winningEnrollmentId, boolean noPreviousIntervention, boolean pastEfIntervention, boolean pastSmeIntervention, boolean pcpVisit, int totalReachAttempts, int successfulReachAttempts, int notReached, int reachRateCategoryId, boolean completedEfSoapNote) {
        this.memberAttributesId = memberAttributesId;
        this.memberAttributesRunId = memberAttributesRunId;
        this.memberId = memberId;
        this.personId = personId;
        this.missingProfile = missingProfile;
        this.newEnrollee = newEnrollee;
        this.termed = termed;
        this.missingLastName = missingLastName;
        this.missingFirstName = missingFirstName;
        this.missingDateOfBirth = missingDateOfBirth;
        this.currentlyEnrolled = currentlyEnrolled;
        this.deceased = deceased;
        this.hospice = hospice;
        this.homebound = homebound;
        this.ageGroup = ageGroup;
        this.ageExclusionLessThan3 = ageExclusionLessThan3;
        this.age = age;
        this.ageGroupId = ageGroupId;
        this.metalLevel = metalLevel;
        this.groupPlanType = groupPlanType;
        this.state = state;
        this.attributedPractitionerId = attributedPractitionerId;
        this.winningEnrollmentId = winningEnrollmentId;
        this.noPreviousIntervention = noPreviousIntervention;
        this.pastEfIntervention = pastEfIntervention;
        this.pastSmeIntervention = pastSmeIntervention;
        this.pcpVisit = pcpVisit;
        this.totalReachAttempts = totalReachAttempts;
        this.successfulReachAttempts = successfulReachAttempts;
        this.notReached = notReached;
        this.reachRateCategoryId = reachRateCategoryId;
        this.completedEfSoapNote = completedEfSoapNote;
    }

    public int getMemberAttributesId() {
        return memberAttributesId;
    }

    public void setMemberAttributesId(int memberAttributesId) {
        this.memberAttributesId = memberAttributesId;
    }

    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public boolean isMissingProfile() {
        return missingProfile;
    }

    public void setMissingProfile(boolean missingProfile) {
        this.missingProfile = missingProfile;
    }

    public boolean isNewEnrollee() {
        return newEnrollee;
    }

    public void setNewEnrollee(boolean newEnrollee) {
        this.newEnrollee = newEnrollee;
    }

    public boolean isTermed() {
        return termed;
    }

    public void setTermed(boolean termed) {
        this.termed = termed;
    }

    public boolean isMissingLastName() {
        return missingLastName;
    }

    public void setMissingLastName(boolean missingLastName) {
        this.missingLastName = missingLastName;
    }

    public boolean isMissingFirstName() {
        return missingFirstName;
    }

    public void setMissingFirstName(boolean missingFirstName) {
        this.missingFirstName = missingFirstName;
    }

    public boolean isMissingDateOfBirth() {
        return missingDateOfBirth;
    }

    public void setMissingDateOfBirth(boolean missingDateOfBirth) {
        this.missingDateOfBirth = missingDateOfBirth;
    }

    public boolean isCurrentlyEnrolled() {
        return currentlyEnrolled;
    }

    public void setCurrentlyEnrolled(boolean currentlyEnrolled) {
        this.currentlyEnrolled = currentlyEnrolled;
    }

    public boolean isDeceased() {
        return deceased;
    }

    public void setDeceased(boolean deceased) {
        this.deceased = deceased;
    }

    public boolean isHospice() {
        return hospice;
    }

    public void setHospice(boolean hospice) {
        this.hospice = hospice;
    }

    public boolean isHomebound() {
        return homebound;
    }

    public void setHomebound(boolean homebound) {
        this.homebound = homebound;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public boolean isAgeExclusionLessThan3() {
        return ageExclusionLessThan3;
    }

    public void setAgeExclusionLessThan3(boolean ageExclusionLessThan3) {
        this.ageExclusionLessThan3 = ageExclusionLessThan3;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAgeGroupId() {
        return ageGroupId;
    }

    public void setAgeGroupId(int ageGroupId) {
        this.ageGroupId = ageGroupId;
    }

    public String getMetalLevel() {
        return metalLevel;
    }

    public void setMetalLevel(String metalLevel) {
        this.metalLevel = metalLevel;
    }

    public String getGroupPlanType() {
        return groupPlanType;
    }

    public void setGroupPlanType(String groupPlanType) {
        this.groupPlanType = groupPlanType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getAttributedPractitionerId() {
        return attributedPractitionerId;
    }

    public void setAttributedPractitionerId(int attributedPractitionerId) {
        this.attributedPractitionerId = attributedPractitionerId;
    }

    public long getWinningEnrollmentId() {
        return winningEnrollmentId;
    }

    public void setWinningEnrollmentId(long winningEnrollmentId) {
        this.winningEnrollmentId = winningEnrollmentId;
    }

    public boolean isNoPreviousIntervention() {
        return noPreviousIntervention;
    }

    public void setNoPreviousIntervention(boolean noPreviousIntervention) {
        this.noPreviousIntervention = noPreviousIntervention;
    }

    public boolean isPastEfIntervention() {
        return pastEfIntervention;
    }

    public void setPastEfIntervention(boolean pastEfIntervention) {
        this.pastEfIntervention = pastEfIntervention;
    }

    public boolean isPastSmeIntervention() {
        return pastSmeIntervention;
    }

    public void setPastSmeIntervention(boolean pastSmeIntervention) {
        this.pastSmeIntervention = pastSmeIntervention;
    }

    public boolean isPcpVisit() {
        return pcpVisit;
    }

    public void setPcpVisit(boolean pcpVisit) {
        this.pcpVisit = pcpVisit;
    }

    public int getTotalReachAttempts() {
        return totalReachAttempts;
    }

    public void setTotalReachAttempts(int totalReachAttempts) {
        this.totalReachAttempts = totalReachAttempts;
    }

    public int getSuccessfulReachAttempts() {
        return successfulReachAttempts;
    }

    public void setSuccessfulReachAttempts(int successfulReachAttempts) {
        this.successfulReachAttempts = successfulReachAttempts;
    }

    public int getNotReached() {
        return notReached;
    }

    public void setNotReached(int notReached) {
        this.notReached = notReached;
    }

    public int getReachRateCategoryId() {
        return reachRateCategoryId;
    }

    public void setReachRateCategoryId(int reachRateCategoryId) {
        this.reachRateCategoryId = reachRateCategoryId;
    }

    public boolean isCompletedEfSoapNote() {
        return completedEfSoapNote;
    }

    public void setCompletedEfSoapNote(boolean completedEfSoapNote) {
        this.completedEfSoapNote = completedEfSoapNote;
    }
}

package com.inovalon.riskadjustment.memberattributes.sharedmodel;


import java.sql.Timestamp;

import static java.lang.Math.toIntExact;

public class MemberEvidence implements Comparable<MemberEvidence>{
    private long memberEvidenceId;
    private Integer gapSetDetailId;
    private Integer memberId;
    private String personId;
    private Integer practitionerId;
    private Integer encounterId;
    private Timestamp encounterServiceDate;
    private String hcc;
    private Double gapConfidenceValue;
    private String gapConfidenceLevel;
    private String gapType;

    public MemberEvidence() {
    }

    public MemberEvidence(long memberEvidenceId, Integer gapSetDetailId, Integer memberId, String personId, Integer practitionerId, Integer encounterId, Timestamp encounterServiceDate, String hcc, Double gapConfidenceValue, String gapConfidenceLevel, String gapType) {
        this.memberEvidenceId = memberEvidenceId;
        this.gapSetDetailId = gapSetDetailId;
        this.memberId = memberId;
        this.personId = personId;
        this.practitionerId = practitionerId;
        this.encounterId = encounterId;
        this.encounterServiceDate = encounterServiceDate;
        this.hcc = hcc;
        this.gapConfidenceValue = gapConfidenceValue;
        this.gapConfidenceLevel = gapConfidenceLevel;
        this.gapType = gapType;
    }

    public long getMemberEvidenceId() {
        return this.memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    public Integer getGapSetDetailId() {
        return this.gapSetDetailId;
    }

    public void setGapSetDetailId(Integer gapSetDetailId) {
        this.gapSetDetailId = gapSetDetailId;
    }

    public Integer getMemberId() {
        return this.memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return this.personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public Integer getPractitionerId() {
        return this.practitionerId;
    }

    public void setPractitionerId(Integer practitionerId) {
        this.practitionerId = practitionerId;
    }

    public Integer getEncounterId() {
        return this.encounterId;
    }

    public void setEncounterId(Integer encounterId) {
        this.encounterId = encounterId;
    }

    public Timestamp getEncounterServiceDate() {
        return this.encounterServiceDate;
    }

    public void setEncounterServiceDate(Timestamp encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    public String getHcc() {
        return this.hcc;
    }

    public void setHcc(String hcc) {
        this.hcc = hcc;
    }

    public Double getGapConfidenceValue() {
        return this.gapConfidenceValue;
    }

    public void setGapConfidenceValue(Double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    public String getGapConfidenceLevel() {
        return this.gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    public String getGapType() {
        return this.gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    @Override
    public int compareTo(MemberEvidence memberEvidence){
        int compareMemberId = ((MemberEvidence) memberEvidence).getMemberId();

        return toIntExact(this.memberId - compareMemberId);
    }
}

package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberEvidenceStatusEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberEvidenceStatusEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberEvidenceStatusServiceImpl implements MemberEvidenceStatusService {
    @Autowired private MemberEvidenceStatusEntityDao memberEvidenceStatusEntityDao;
    @Autowired
    private LogWriter logWriter;
    @LogBeforeEvents
    @Override
    public int persistMemberEvidence(List<MemberEvidenceStatusEntity> memberEvidenceStatusEntities){
        try{
            if(memberEvidenceStatusEntities.isEmpty()){
                logWriter.info("json body empty for persist member evidence status");
                return 1;
            }else {

                memberEvidenceStatusEntityDao.save(memberEvidenceStatusEntities);
                return 0;
            }
        }
        catch(DataIntegrityViolationException violationException){
            logWriter.info("MemberAttributes Persistence: MemberEvidenceStatus for member id: "+ memberEvidenceStatusEntities.get(0).getMemberId()
                    + " and MemberAttributesRunId: " + memberEvidenceStatusEntities.get(0).getMemberAttributesRunId()
                    + ") already existed in table");
            return 2;
        }
        catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            return 99;
        }
    }

}

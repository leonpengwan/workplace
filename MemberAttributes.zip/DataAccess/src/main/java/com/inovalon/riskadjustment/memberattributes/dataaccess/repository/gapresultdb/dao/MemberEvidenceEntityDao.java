package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.dao;

import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model.MemberEvidenceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MemberEvidenceEntityDao extends JpaRepository<MemberEvidenceEntity, Integer> {

    @Query("select count(distinct memberId) from MemberEvidenceEntity where  gapSetDetailId=?1")
    public Integer getDistinctMemberCountByGapSetDetailId(int gapSetDetailId);

    @Query("select count(distinct memberId) from MemberEvidenceEntity where  gapSetId=?1")
    public Integer getDistinctMemberCountByGapSetId(String gapSetId);


    @Query("select distinct memberId from MemberEvidenceEntity where gapSetId = :gapSetId and memberId > :memberId")
    public List<Integer> findGapmemberIds( @Param("gapSetId") String gapSetId, @Param("memberId") int memberId, Pageable pageable );


    @Query("select e from MemberEvidenceEntity e where e.gapSetId = :gapSetId and e.memberId in (:memberIds)")
    List<MemberEvidenceEntity> findByGapSetDetailIdAndMemberIds( @Param("gapSetId") String gapSetId, @Param("memberIds") List<Integer> memberIds );
}

package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model.InterventionPlanEntity;

import java.util.List;


public interface InterventionPlanService {

    public List<InterventionPlanEntity> getInterventionPlanData( List<Integer>interventionPlanRunIds) throws Exception;
}

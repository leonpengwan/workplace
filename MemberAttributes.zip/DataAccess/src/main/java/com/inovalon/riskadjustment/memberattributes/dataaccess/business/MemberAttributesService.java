package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberAttributesEntity;

public interface MemberAttributesService {
    int persistMemberAttributes(MemberAttributesEntity memberAttributesEntity);
}

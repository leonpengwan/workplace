package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by pwan on 2/7/2018.
 */
@Entity
@Table(name = "MemberEvidence", schema = "dbo")
public class MemberEvidenceEntity {
    private long memberEvidenceId;
    private Integer memberId;
    private String personId;
    private Integer practitionerId;
    private Integer encounterId;
    private Timestamp encounterServiceDate;
    private String hcc;
    private Double gapConfidenceValue;
    private String gapConfidenceLevel;
    private String gapType;
    private String gapSetId;
    private String measureKey;
    private Integer saGapValue;

    @Id
    @Column(name = "MemberEvidenceId")
    public long getMemberEvidenceId() {
        return memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    @Basic
    @Column(name = "MemberId")
    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    @Basic
    @Column(name = "PersonId")
    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "PractitionerId")
    public Integer getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(Integer practitionerId) {
        this.practitionerId = practitionerId;
    }

    @Basic
    @Column(name = "EncounterId")
    public Integer getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(Integer encounterId) {
        this.encounterId = encounterId;
    }

    @Basic
    @Column(name = "EncounterServiceDate")
    public Timestamp getEncounterServiceDate() {
        return encounterServiceDate;
    }

    public void setEncounterServiceDate(Timestamp encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    @Basic
    @Column(name = "HCC")
    public String getHcc() {
        return hcc;
    }

    public void setHcc(String hcc) {
        this.hcc = hcc;
    }

    @Basic
    @Column(name = "GapConfidenceValue")
    public Double getGapConfidenceValue() {
        return gapConfidenceValue;
    }

    public void setGapConfidenceValue(Double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    @Basic
    @Column(name = "GapConfidenceLevel")
    public String getGapConfidenceLevel() {
        return gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    @Basic
    @Column(name = "GapType")
    public String getGapType() {
        return gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    @Basic
    @Column(name = "GapSetId")
    public String getGapSetId() {
        return gapSetId;
    }

    public void setGapSetId(String gapSetId) {
        this.gapSetId = gapSetId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MemberEvidenceEntity that = (MemberEvidenceEntity) o;

        if (memberEvidenceId != that.memberEvidenceId) return false;
        if (memberId != null ? !memberId.equals(that.memberId) : that.memberId != null) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;
        if (practitionerId != null ? !practitionerId.equals(that.practitionerId) : that.practitionerId != null)
            return false;
        if (encounterId != null ? !encounterId.equals(that.encounterId) : that.encounterId != null) return false;
        if (encounterServiceDate != null ? !encounterServiceDate.equals(that.encounterServiceDate) : that.encounterServiceDate != null)
            return false;
        if (hcc != null ? !hcc.equals(that.hcc) : that.hcc != null) return false;
        if (gapConfidenceValue != null ? !gapConfidenceValue.equals(that.gapConfidenceValue) : that.gapConfidenceValue != null)
            return false;
        if (gapConfidenceLevel != null ? !gapConfidenceLevel.equals(that.gapConfidenceLevel) : that.gapConfidenceLevel != null)
            return false;
        if (gapType != null ? !gapType.equals(that.gapType) : that.gapType != null) return false;
        if (gapSetId != null ? !gapSetId.equals(that.gapSetId) : that.gapSetId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (memberEvidenceId ^ (memberEvidenceId >>> 32));
        result = 31 * result + (memberId != null ? memberId.hashCode() : 0);
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (practitionerId != null ? practitionerId.hashCode() : 0);
        result = 31 * result + (encounterId != null ? encounterId.hashCode() : 0);
        result = 31 * result + (encounterServiceDate != null ? encounterServiceDate.hashCode() : 0);
        result = 31 * result + (hcc != null ? hcc.hashCode() : 0);
        result = 31 * result + (gapConfidenceValue != null ? gapConfidenceValue.hashCode() : 0);
        result = 31 * result + (gapConfidenceLevel != null ? gapConfidenceLevel.hashCode() : 0);
        result = 31 * result + (gapType != null ? gapType.hashCode() : 0);
        result = 31 * result + (gapSetId != null ? gapSetId.hashCode() : 0);
        return result;
    }

    @Basic
    @Column(name = "MeasureKey")
    public String getMeasureKey() {
        return measureKey;
    }

    public void setMeasureKey(String measureKey) {
        this.measureKey = measureKey;
    }

    @Basic
    @Column(name = "SAGapValue")
    public Integer getSaGapValue() {
        return saGapValue;
    }

    public void setSaGapValue(Integer saGapValue) {
        this.saGapValue = saGapValue;
    }
}

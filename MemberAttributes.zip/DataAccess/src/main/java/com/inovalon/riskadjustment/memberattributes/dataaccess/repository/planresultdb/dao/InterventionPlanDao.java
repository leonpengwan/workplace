package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model.InterventionPlanEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface InterventionPlanDao extends JpaRepository<InterventionPlanEntity, Integer> {

    public List<InterventionPlanEntity> findByInterventionPlanRunIdIn(List<Integer>interventionPlanRunIds);
}



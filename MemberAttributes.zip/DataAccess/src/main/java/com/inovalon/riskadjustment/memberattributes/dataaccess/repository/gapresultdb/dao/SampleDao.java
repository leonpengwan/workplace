package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.dao;

/**
 * Created by pwan on 1/31/2018.
 */
public class SampleDao {
}

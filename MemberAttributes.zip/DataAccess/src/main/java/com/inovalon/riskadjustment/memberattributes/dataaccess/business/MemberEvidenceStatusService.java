package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberEvidenceStatusEntity;

import java.util.List;

public interface MemberEvidenceStatusService {
    int persistMemberEvidence(List<MemberEvidenceStatusEntity> memberEvidenceStatusEntities);
}

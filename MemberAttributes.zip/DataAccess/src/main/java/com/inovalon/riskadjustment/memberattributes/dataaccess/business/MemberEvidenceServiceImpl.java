package com.inovalon.riskadjustment.memberattributes.dataaccess.business;


import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.dao.MemberEvidenceEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model.MemberEvidenceEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MemberEvidenceServiceImpl implements  MemberEvidenceService{

    @Autowired
    private MemberEvidenceEntityDao memberEvidenceDao;
    @Autowired
    private LogWriter logWriter;

    /**
     * @param gapSetId
     * @return size of distinct memberId for a given gapset
     */
    @LogAfterEvents
    @Override
    public Integer getMemberCount(String gapSetId) {
        logWriter.info("MemberEvidenceServiceImpl:: getMemberCount: begining..");
        Integer count = memberEvidenceDao.getDistinctMemberCountByGapSetId(gapSetId);
        logWriter.info("MemberEvidenceServiceImpl:: getMemberCount: Ending..");
        return count;
    }

    /**
     * @param gapSetId
     * @param size
     * @param memberId
     * @return list of memberIds for a given gapSetId
     * @throws Exception
     */
    @LogBeforeEvents
    @LogAfterEvents
    @Override
    public List<Integer> getGapMemberIds(String gapSetId , int size , int memberId) throws Exception {
        List<Integer> memberIds =  new ArrayList<Integer>();
        try {
            PageRequest pageRequest = new PageRequest(0, size, Sort.Direction.ASC, "memberId");
            memberIds = memberEvidenceDao.findGapmemberIds(gapSetId, memberId, pageRequest);

        }catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            throw ex;
        }
        return memberIds;
    }

    /**
     * @param gapSetId
     * @param memberIds
     * @return list of memberEvidences
     * @throws Exception
     */
    @LogBeforeEvents
    @Override
    public List<MemberEvidenceEntity> retrieveMemberEvidencesForMemberAttributes(String gapSetId, List<Integer> memberIds) throws Exception{
        return memberEvidenceDao.findByGapSetDetailIdAndMemberIds(gapSetId, memberIds);
    }
}

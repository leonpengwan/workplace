package com.inovalon.riskadjustment.memberattributes.dataaccess.controller;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.business.MemberEvidenceService;
import com.inovalon.riskadjustment.memberattributes.dataaccess.model.servicemodel.MemberEvidenceData;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model.MemberEvidenceEntity;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Api
@RestController
@RequestMapping("/risk-analytics/gap-result")
public class RiskAnalyticsGapResultController {
    @Autowired
    MemberEvidenceService memberEvidenceService;
    @Autowired
    private LogWriter logWriter;

    @ApiOperation( value = "This method return the member list based on given input")
    @CrossOrigin
    @RequestMapping(value="/getMemberCount/{gapSetId}", method= RequestMethod.GET, produces = "application/json")
    public Integer getMemberCount(@ApiParam(value = "gapSetId", required = true) @PathVariable("gapSetId") String gapSetId) throws IOException, NullPointerException{
        return memberEvidenceService.getMemberCount (gapSetId);
    }

    @ApiOperation(value = "This method return the member list in batch based on intput")
    @CrossOrigin
    @RequestMapping(value = "/gapMembers/{gapSetId}/{size}/{memberId}", method = RequestMethod.GET, produces = "application/json")
    public List<Integer> getGapMemberIds( @ApiParam(value = "gapSetId", required = true) @PathVariable("gapSetId") String gapSetId,
                                          @ApiParam(value = "size", required = true) @PathVariable("size") int size,
                                          @ApiParam(value = "memberId", required = true) @PathVariable("memberId") int memberId ) throws Exception {
        List<Integer> members = new ArrayList<Integer>();

        try {
            members = memberEvidenceService.getGapMemberIds(gapSetId, size, memberId);
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
        }

        return members;
    }

    @ApiOperation(value = "This method is used to get memberEvidenceByMemberIds in db.")
    @CrossOrigin
    @RequestMapping(value = "/retrieveMemberEvidencesByMemberIds/{gapSetId}", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")/*As per restfullapi naming conventions*/
    public List<MemberEvidenceEntity> retrieveMemberEvidencesForMemberAttributes( @ApiParam(value = "memberIds", required = true) @RequestBody MemberEvidenceData memberEvidenceData,
                                                                                  @ApiParam(value = "gapSetId", required = true) @PathVariable("gapSetId") String gapSetId)  throws Exception{
        return  memberEvidenceService.retrieveMemberEvidencesForMemberAttributes(gapSetId,memberEvidenceData.getMemberIds());

    }
}

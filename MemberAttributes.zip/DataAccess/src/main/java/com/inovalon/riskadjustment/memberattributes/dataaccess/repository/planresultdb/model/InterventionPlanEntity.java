package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by kraju on 2/8/2018.
 */
@Entity
@Table(name = "InterventionPlan", schema = "dbo")
public class InterventionPlanEntity {
    private long interventionPlanId;
    private int interventionPlanRunId;
    private int memberId;
    private String personId;
    private Integer interventionYear;
    private Integer interventionMonth;
    private Integer interventionTypeId;
    private String interventionPrefix;
    private String createdBy;
    private Timestamp createdDate;
    private String modifiedBy;
    private Timestamp modifiedDate;

    @Id
    @Column(name = "InterventionPlanId")
    public long getInterventionPlanId() {
        return interventionPlanId;
    }

    public void setInterventionPlanId( long interventionPlanId ) {
        this.interventionPlanId = interventionPlanId;
    }

    @Basic
    @Column(name = "InterventionPlanRunId")
    public int getInterventionPlanRunId() {
        return interventionPlanRunId;
    }

    public void setInterventionPlanRunId( int interventionPlanRunId ) {
        this.interventionPlanRunId = interventionPlanRunId;
    }

    @Basic
    @Column(name = "MemberId")
    public int getMemberId() {
        return memberId;
    }

    public void setMemberId( int memberId ) {
        this.memberId = memberId;
    }

    @Basic
    @Column(name = "PersonId")
    public String getPersonId() {
        return personId;
    }

    public void setPersonId( String personId ) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "InterventionYear")
    public Integer getInterventionYear() {
        return interventionYear;
    }

    public void setInterventionYear( Integer interventionYear ) {
        this.interventionYear = interventionYear;
    }

    @Basic
    @Column(name = "InterventionMonth")
    public Integer getInterventionMonth() {
        return interventionMonth;
    }

    public void setInterventionMonth( Integer interventionMonth ) {
        this.interventionMonth = interventionMonth;
    }

    @Basic
    @Column(name = "InterventionTypeId")
    public Integer getInterventionTypeId() {
        return interventionTypeId;
    }

    public void setInterventionTypeId( Integer interventionTypeId ) {
        this.interventionTypeId = interventionTypeId;
    }

    @Basic
    @Column(name = "InterventionPrefix")
    public String getInterventionPrefix() {
        return interventionPrefix;
    }

    public void setInterventionPrefix( String interventionPrefix ) {
        this.interventionPrefix = interventionPrefix;
    }

    @Basic
    @Column(name = "CreatedBy")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy( String createdBy ) {
        this.createdBy = createdBy;
    }

    @Basic
    @Column(name = "CreatedDate")
    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate( Timestamp createdDate ) {
        this.createdDate = createdDate;
    }

    @Basic
    @Column(name = "ModifiedBy")
    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy( String modifiedBy ) {
        this.modifiedBy = modifiedBy;
    }

    @Basic
    @Column(name = "ModifiedDate")
    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate( Timestamp modifiedDate ) {
        this.modifiedDate = modifiedDate;
    }

    @Override
    public boolean equals( Object o ) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InterventionPlanEntity that = (InterventionPlanEntity) o;

        if (interventionPlanId != that.interventionPlanId) return false;
        if (interventionPlanRunId != that.interventionPlanRunId) return false;
        if (memberId != that.memberId) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;
        if (interventionYear != null ? !interventionYear.equals(that.interventionYear) : that.interventionYear != null)
            return false;
        if (interventionMonth != null ? !interventionMonth.equals(that.interventionMonth) : that.interventionMonth != null)
            return false;
        if (interventionTypeId != null ? !interventionTypeId.equals(that.interventionTypeId) : that.interventionTypeId != null)
            return false;
        if (interventionPrefix != null ? !interventionPrefix.equals(that.interventionPrefix) : that.interventionPrefix != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDate != null ? !modifiedDate.equals(that.modifiedDate) : that.modifiedDate != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (interventionPlanId ^ (interventionPlanId >>> 32));
        result = 31 * result + interventionPlanRunId;
        result = 31 * result + memberId;
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (interventionYear != null ? interventionYear.hashCode() : 0);
        result = 31 * result + (interventionMonth != null ? interventionMonth.hashCode() : 0);
        result = 31 * result + (interventionTypeId != null ? interventionTypeId.hashCode() : 0);
        result = 31 * result + (interventionPrefix != null ? interventionPrefix.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDate != null ? modifiedDate.hashCode() : 0);
        return result;
    }
}

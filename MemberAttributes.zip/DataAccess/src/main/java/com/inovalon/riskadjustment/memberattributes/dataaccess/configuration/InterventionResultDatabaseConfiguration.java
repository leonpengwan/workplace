package com.inovalon.riskadjustment.memberattributes.dataaccess.configuration;


import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao"},
        entityManagerFactoryRef = "interventionResultEntityManagerFactory",
        transactionManagerRef = "interventionResultTransactionManager"
)
public class InterventionResultDatabaseConfiguration {
    @Value("${inovalon.risk-adjustment.database.intervention-result-connection-string}")
    private String interventionResultsDatabaseUrl;

    @Value("${inovalon.risk-adjustment.database.intervention-result-username}")
    private String interventionResultsDatabaseUsername;

    @Value("${inovalon.risk-adjustment.database.intervention-result-password}")
    private String interventionResultsDatabasePassword;
    @Value("${spring.jpa.show-sql}")
    private String jpaShowSQl;

    public String getInterventionResultsDatabaseUrl() {
        return interventionResultsDatabaseUrl;
    }

    public String getInterventionResultsDatabaseUsername() {
        return interventionResultsDatabaseUsername;
    }

    public String getInterventionResultsDatabasePassword() {
        return interventionResultsDatabasePassword;
    }

    public String getJpaShowSQl() {
        return jpaShowSQl;
    }

    @Override
    public String toString() {
        return "InterventionResultDatabaseConfiguration{" +
                "interventionResultsDatabaseUrl='" + interventionResultsDatabaseUrl + '\'' +
                '}';
    }

    @Bean(name = "interventionResultDataSource")
    public DataSource interventionResultDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(interventionResultsDatabaseUrl);
        dataSource.setUsername(interventionResultsDatabaseUsername);
        dataSource.setPassword(interventionResultsDatabasePassword);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(10);
        dataSource.setIdleTimeout(10);
        return dataSource;
    }


    @Bean(name = "interventionResultEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean interventionResultEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(interventionResultDataSource());
        em.setPackagesToScan(new String[]{"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model"});
        HibernateJpaVendorAdapter jpaVendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(jpaVendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLServer2012Dialect");
        properties.put("hibernate.show_sql", jpaShowSQl);
        em.setJpaPropertyMap(properties);
        em.setPersistenceUnitName("interventionresultdb");
        return em;
    }


    @Bean(name = "interventionResultTransactionManager")
    public PlatformTransactionManager interventionResultTransactionManager() {
        return new JpaTransactionManager(interventionResultEntityManagerFactory().getObject());
    }
}

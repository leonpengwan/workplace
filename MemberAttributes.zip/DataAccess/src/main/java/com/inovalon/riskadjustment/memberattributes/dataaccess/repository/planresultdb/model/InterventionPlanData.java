package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model;

import java.util.List;

public class InterventionPlanData {

    public  List<Integer>interventionPlanRunIds;

    public InterventionPlanData() {
        super();
    }


    public List<Integer> getInterventionPlanRunIds() {
        return this.interventionPlanRunIds;
    }

    public void setInterventionPlanRunIds( List<Integer> interventionPlanRunIds ) {
        this.interventionPlanRunIds = interventionPlanRunIds;
    }


}

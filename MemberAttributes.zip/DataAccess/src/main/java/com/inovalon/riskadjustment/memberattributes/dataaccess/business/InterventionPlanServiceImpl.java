package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.dao.InterventionPlanDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model.InterventionPlanEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InterventionPlanServiceImpl implements InterventionPlanService {
    @Autowired
    private LogWriter logWriter;
    @Autowired
    private InterventionPlanDao interventionPlanDao;
    @LogBeforeEvents
    @LogAfterEvents
    public List<InterventionPlanEntity> getInterventionPlanData( List<Integer>interventionPlanRunIds ) {
        try
        {

            List<InterventionPlanEntity> interventionPlanEntities = interventionPlanDao.findByInterventionPlanRunIdIn(interventionPlanRunIds);

            return interventionPlanEntities;

        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
            throw ex;
        }
    }

}

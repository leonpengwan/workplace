package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model;

import javax.persistence.*;


@Entity
@Table(name = "PractitionerValidation", schema = "dbo")
public class PractitionerValidationEntity {
    private int practitionerValidationId;
    private int memberAttributesRunId;
    private int practitionerId;
    private boolean invalidName;
    private boolean invalidAddress;
    private boolean invalidPhone;
    private boolean invalidFax;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PractitionerValidationId")
    public int getPractitionerValidationId() {
        return practitionerValidationId;
    }

    public void setPractitionerValidationId(int practitionerValidationId) {
        this.practitionerValidationId = practitionerValidationId;
    }

    @Basic
    @Column(name = "MemberAttributesRunId")
    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    @Basic
    @Column(name = "PractitionerId")
    public int getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(int practitionerId) {
        this.practitionerId = practitionerId;
    }

    @Basic
    @Column(name = "InvalidName")
    public boolean isInvalidName() {
        return invalidName;
    }

    public void setInvalidName(boolean invalidName) {
        this.invalidName = invalidName;
    }

    @Basic
    @Column(name = "InvalidAddress")
    public boolean isInvalidAddress() {
        return invalidAddress;
    }

    public void setInvalidAddress(boolean invalidAddress) {
        this.invalidAddress = invalidAddress;
    }

    @Basic
    @Column(name = "InvalidPhone")
    public boolean isInvalidPhone() {
        return invalidPhone;
    }

    public void setInvalidPhone(boolean invalidPhone) {
        this.invalidPhone = invalidPhone;
    }

    @Basic
    @Column(name = "InvalidFax")
    public boolean isInvalidFax() {
        return invalidFax;
    }

    public void setInvalidFax(boolean invalidFax) {
        this.invalidFax = invalidFax;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PractitionerValidationEntity that = (PractitionerValidationEntity) o;

        if (practitionerValidationId != that.practitionerValidationId) return false;
        if (memberAttributesRunId != that.memberAttributesRunId) return false;
        if (practitionerId != that.practitionerId) return false;
        if (invalidName != that.invalidName) return false;
        if (invalidAddress != that.invalidAddress) return false;
        if (invalidPhone != that.invalidPhone) return false;
        if (invalidFax != that.invalidFax) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = practitionerValidationId;
        result = 31 * result + memberAttributesRunId;
        result = 31 * result + practitionerId;
        result = 31 * result + (invalidName ? 1 : 0);
        result = 31 * result + (invalidAddress ? 1 : 0);
        result = 31 * result + (invalidPhone ? 1 : 0);
        result = 31 * result + (invalidFax ? 1 : 0);
        return result;
    }
}

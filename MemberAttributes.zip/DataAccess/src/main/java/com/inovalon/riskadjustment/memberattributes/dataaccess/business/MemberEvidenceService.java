package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model.MemberEvidenceEntity;

import java.util.List;

public interface MemberEvidenceService {
    Integer getMemberCount(String gapSetId);

    List<Integer> getGapMemberIds(String gapSetId , int size , int memberId) throws Exception;
    List<MemberEvidenceEntity> retrieveMemberEvidencesForMemberAttributes( String gapSetId, List<Integer> memberIds) throws Exception;
}

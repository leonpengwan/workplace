package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberValidationEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberValidationEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class MemberValidationServiceImpl implements MemberValidationService {
    @Autowired private MemberValidationEntityDao memberValidationEntityDao;
    @Autowired
    private LogWriter logWriter;
    @LogAfterEvents
    @Override
    public int persistMemberValidation(MemberValidationEntity memberValidationEntity){
        try{
            if(memberValidationEntity == null){
                logWriter.info("json body empty for persist member validation");
                return 1;
            }else {

                memberValidationEntityDao.save(memberValidationEntity);
                return 0;
            }
        }
        catch(DataIntegrityViolationException violationException){
            logWriter.info("MemberAttributes Persistence: MemberValidation for member id: "+ memberValidationEntity.getMemberId()
                    + " and MemberAttributesRunId: " + memberValidationEntity.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        }
        catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            return 99;
        }
    }
}

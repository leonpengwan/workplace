package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.PractitionerValidationEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PractitionerValidationEntityDao extends JpaRepository<PractitionerValidationEntity, Integer>{
}

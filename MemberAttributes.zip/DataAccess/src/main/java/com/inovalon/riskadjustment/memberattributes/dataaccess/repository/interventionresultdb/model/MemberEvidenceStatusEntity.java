package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model;

import javax.persistence.*;
import java.sql.Timestamp;


@Entity
@Table(name = "MemberEvidenceStatus", schema = "dbo")
public class MemberEvidenceStatusEntity {
    private long memberEvidenceStatusId;
    private int memberAttributesRunId;
    private long memberEvidenceId;
    private Integer gapSetDetailId;
    private Integer memberId;
    private String personId;
    private Integer practitionerId;
    private Integer encounterId;
    private Timestamp encounterServiceDate;
    private String hccCode;
    private String originalHccCode;
    private Double gapConfidenceValue;
    private String gapConfidenceLevel;
    private String gapType;
    private int exclusionId;
    private String measureKey;
    private Integer saGapValue;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MemberEvidenceStatusId")
    public long getMemberEvidenceStatusId() {
        return memberEvidenceStatusId;
    }

    public void setMemberEvidenceStatusId(long memberEvidenceStatusId) {
        this.memberEvidenceStatusId = memberEvidenceStatusId;
    }

    @Basic
    @Column(name = "MemberAttributesRunId")
    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    @Basic
    @Column(name = "MemberEvidenceId")
    public long getMemberEvidenceId() {
        return memberEvidenceId;
    }

    public void setMemberEvidenceId(long memberEvidenceId) {
        this.memberEvidenceId = memberEvidenceId;
    }

    @Basic
    @Column(name = "GapSetDetailId")
    public Integer getGapSetDetailId() {
        return gapSetDetailId;
    }

    public void setGapSetDetailId(Integer gapSetDetailId) {
        this.gapSetDetailId = gapSetDetailId;
    }

    @Basic
    @Column(name = "MemberId")
    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    @Basic
    @Column(name = "PersonId")
    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "PractitionerId")
    public Integer getPractitionerId() {
        return practitionerId;
    }

    public void setPractitionerId(Integer practitionerId) {
        this.practitionerId = practitionerId;
    }

    @Basic
    @Column(name = "EncounterId")
    public Integer getEncounterId() {
        return encounterId;
    }

    public void setEncounterId(Integer encounterId) {
        this.encounterId = encounterId;
    }

    @Basic
    @Column(name = "EncounterServiceDate")
    public Timestamp getEncounterServiceDate() {
        return encounterServiceDate;
    }

    public void setEncounterServiceDate(Timestamp encounterServiceDate) {
        this.encounterServiceDate = encounterServiceDate;
    }

    @Basic
    @Column(name = "HccCode")
    public String getHccCode() {
        return hccCode;
    }

    public void setHccCode(String hccCode) {
        this.hccCode = hccCode;
    }

    @Basic
    @Column(name = "OriginalHccCode")
    public String getOriginalHccCode() {
        return originalHccCode;
    }

    public void setOriginalHccCode(String originalHccCode) {
        this.originalHccCode = originalHccCode;
    }

    @Basic
    @Column(name = "GapConfidenceValue")
    public Double getGapConfidenceValue() {
        return gapConfidenceValue;
    }

    public void setGapConfidenceValue(Double gapConfidenceValue) {
        this.gapConfidenceValue = gapConfidenceValue;
    }

    @Basic
    @Column(name = "GapConfidenceLevel")
    public String getGapConfidenceLevel() {
        return gapConfidenceLevel;
    }

    public void setGapConfidenceLevel(String gapConfidenceLevel) {
        this.gapConfidenceLevel = gapConfidenceLevel;
    }

    @Basic
    @Column(name = "GapType")
    public String getGapType() {
        return gapType;
    }

    public void setGapType(String gapType) {
        this.gapType = gapType;
    }

    @Basic
    @Column(name = "ExclusionId")
    public int getExclusionId() {
        return exclusionId;
    }

    public void setExclusionId(int exclusionId) {
        this.exclusionId = exclusionId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MemberEvidenceStatusEntity that = (MemberEvidenceStatusEntity) o;

        if (memberEvidenceStatusId != that.memberEvidenceStatusId) return false;
        if (memberAttributesRunId != that.memberAttributesRunId) return false;
        if (memberEvidenceId != that.memberEvidenceId) return false;
        if (exclusionId != that.exclusionId) return false;
        if (gapSetDetailId != null ? !gapSetDetailId.equals(that.gapSetDetailId) : that.gapSetDetailId != null)
            return false;
        if (memberId != null ? !memberId.equals(that.memberId) : that.memberId != null) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;
        if (practitionerId != null ? !practitionerId.equals(that.practitionerId) : that.practitionerId != null)
            return false;
        if (encounterId != null ? !encounterId.equals(that.encounterId) : that.encounterId != null) return false;
        if (encounterServiceDate != null ? !encounterServiceDate.equals(that.encounterServiceDate) : that.encounterServiceDate != null)
            return false;
        if (hccCode != null ? !hccCode.equals(that.hccCode) : that.hccCode != null) return false;
        if (originalHccCode != null ? !originalHccCode.equals(that.originalHccCode) : that.originalHccCode != null)
            return false;
        if (gapConfidenceValue != null ? !gapConfidenceValue.equals(that.gapConfidenceValue) : that.gapConfidenceValue != null)
            return false;
        if (gapConfidenceLevel != null ? !gapConfidenceLevel.equals(that.gapConfidenceLevel) : that.gapConfidenceLevel != null)
            return false;
        if (gapType != null ? !gapType.equals(that.gapType) : that.gapType != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (memberEvidenceStatusId ^ (memberEvidenceStatusId >>> 32));
        result = 31 * result + memberAttributesRunId;
        result = 31 * result + (int) (memberEvidenceId ^ (memberEvidenceId >>> 32));
        result = 31 * result + (gapSetDetailId != null ? gapSetDetailId.hashCode() : 0);
        result = 31 * result + (memberId != null ? memberId.hashCode() : 0);
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (practitionerId != null ? practitionerId.hashCode() : 0);
        result = 31 * result + (encounterId != null ? encounterId.hashCode() : 0);
        result = 31 * result + (encounterServiceDate != null ? encounterServiceDate.hashCode() : 0);
        result = 31 * result + (hccCode != null ? hccCode.hashCode() : 0);
        result = 31 * result + (originalHccCode != null ? originalHccCode.hashCode() : 0);
        result = 31 * result + (gapConfidenceValue != null ? gapConfidenceValue.hashCode() : 0);
        result = 31 * result + (gapConfidenceLevel != null ? gapConfidenceLevel.hashCode() : 0);
        result = 31 * result + (gapType != null ? gapType.hashCode() : 0);
        result = 31 * result + exclusionId;
        return result;
    }

    @Basic
    @Column(name = "MeasureKey")
    public String getMeasureKey() {
        return measureKey;
    }

    public void setMeasureKey(String measureKey) {
        this.measureKey = measureKey;
    }

    @Basic
    @Column(name = "SAGapValue")
    public Integer getSaGapValue() {
        return saGapValue;
    }

    public void setSaGapValue(Integer saGapValue) {
        this.saGapValue = saGapValue;
    }
}

package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model;

import javax.persistence.*;


@Entity
@Table(name = "MemberValidation", schema = "dbo")
public class MemberValidationEntity {
    private int memberValidationId;
    private int memberAttributesRunId;
    private int memberId;
    private String personId;
    private boolean inValidAddress;
    private boolean inValidPhone;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MemberValidationId")
    public int getMemberValidationId() {
        return memberValidationId;
    }

    public void setMemberValidationId(int memberValidationId) {
        this.memberValidationId = memberValidationId;
    }

    @Basic
    @Column(name = "MemberAttributesRunId")
    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    @Basic
    @Column(name = "MemberId")
    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    @Basic
    @Column(name = "PersonId")
    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "InValidAddress")
    public boolean isInValidAddress() {
        return inValidAddress;
    }

    public void setInValidAddress(boolean inValidAddress) {
        this.inValidAddress = inValidAddress;
    }

    @Basic
    @Column(name = "InValidPhone")
    public boolean isInValidPhone() {
        return inValidPhone;
    }

    public void setInValidPhone(boolean inValidPhone) {
        this.inValidPhone = inValidPhone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MemberValidationEntity that = (MemberValidationEntity) o;

        if (memberValidationId != that.memberValidationId) return false;
        if (memberAttributesRunId != that.memberAttributesRunId) return false;
        if (memberId != that.memberId) return false;
        if (inValidAddress != that.inValidAddress) return false;
        if (inValidPhone != that.inValidPhone) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = memberValidationId;
        result = 31 * result + memberAttributesRunId;
        result = 31 * result + memberId;
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (inValidAddress ? 1 : 0);
        result = 31 * result + (inValidPhone ? 1 : 0);
        return result;
    }
}

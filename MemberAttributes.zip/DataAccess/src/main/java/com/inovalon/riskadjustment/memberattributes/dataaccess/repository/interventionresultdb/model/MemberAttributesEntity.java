package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model;

import javax.persistence.*;

/**
 * Created by pwan on 1/31/2018.
 */
@Entity
@Table(name = "MemberAttributes", schema = "dbo")
public class MemberAttributesEntity {
    private int memberAttributesId;
    private int memberAttributesRunId;
    private int memberId;
    private String personId;
    private boolean missingProfile;
    private boolean newEnrollee;
    private boolean termed;
    private boolean missingLastName;
    private boolean missingFirstName;
    private boolean missingDateOfBirth;
    private boolean currentlyEnrolled;
    private boolean deceased;
    private boolean hospice;
    private boolean homebound;
    private String ageGroup;
    private boolean ageExclusionLessThan3;
    private int age;
    private int ageGroupId;
    private String metalLevel;
    private String groupPlanType;
    private String state;
    private int attributedPractitionerId;
    private long winningEnrollmentId;
    private boolean noPreviousIntervention;
    private boolean pastEfIntervention;
    private boolean pastSmeIntervention;
    private boolean pcpVisit;
    private int totalReachAttempts;
    private int successfulReachAttempts;
    private int notReached;
    private int reachRateCategoryId;
    private boolean completedEfSoapNote;
    private Boolean institutional;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MemberAttributesId")
    public int getMemberAttributesId() {
        return memberAttributesId;
    }

    public void setMemberAttributesId(int memberAttributesId) {
        this.memberAttributesId = memberAttributesId;
    }

    @Basic
    @Column(name = "MemberAttributesRunId")
    public int getMemberAttributesRunId() {
        return memberAttributesRunId;
    }

    public void setMemberAttributesRunId(int memberAttributesRunId) {
        this.memberAttributesRunId = memberAttributesRunId;
    }

    @Basic
    @Column(name = "MemberId")
    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    @Basic
    @Column(name = "PersonId")
    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    @Basic
    @Column(name = "MissingProfile")
    public boolean isMissingProfile() {
        return missingProfile;
    }

    public void setMissingProfile(boolean missingProfile) {
        this.missingProfile = missingProfile;
    }

    @Basic
    @Column(name = "NewEnrollee")
    public boolean isNewEnrollee() {
        return newEnrollee;
    }

    public void setNewEnrollee(boolean newEnrollee) {
        this.newEnrollee = newEnrollee;
    }

    @Basic
    @Column(name = "Termed")
    public boolean isTermed() {
        return termed;
    }

    public void setTermed(boolean termed) {
        this.termed = termed;
    }

    @Basic
    @Column(name = "MissingLastName")
    public boolean isMissingLastName() {
        return missingLastName;
    }

    public void setMissingLastName(boolean missingLastName) {
        this.missingLastName = missingLastName;
    }

    @Basic
    @Column(name = "MissingFirstName")
    public boolean isMissingFirstName() {
        return missingFirstName;
    }

    public void setMissingFirstName(boolean missingFirstName) {
        this.missingFirstName = missingFirstName;
    }

    @Basic
    @Column(name = "MissingDateOfBirth")
    public boolean isMissingDateOfBirth() {
        return missingDateOfBirth;
    }

    public void setMissingDateOfBirth(boolean missingDateOfBirth) {
        this.missingDateOfBirth = missingDateOfBirth;
    }

    @Basic
    @Column(name = "CurrentlyEnrolled")
    public boolean isCurrentlyEnrolled() {
        return currentlyEnrolled;
    }

    public void setCurrentlyEnrolled(boolean currentlyEnrolled) {
        this.currentlyEnrolled = currentlyEnrolled;
    }

    @Basic
    @Column(name = "Deceased")
    public boolean isDeceased() {
        return deceased;
    }

    public void setDeceased(boolean deceased) {
        this.deceased = deceased;
    }

    @Basic
    @Column(name = "Hospice")
    public boolean isHospice() {
        return hospice;
    }

    public void setHospice(boolean hospice) {
        this.hospice = hospice;
    }

    @Basic
    @Column(name = "Homebound")
    public boolean isHomebound() {
        return homebound;
    }

    public void setHomebound(boolean homebound) {
        this.homebound = homebound;
    }

    @Basic
    @Column(name = "AgeGroup")
    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    @Basic
    @Column(name = "AgeExclusionLessThan3")
    public boolean isAgeExclusionLessThan3() {
        return ageExclusionLessThan3;
    }

    public void setAgeExclusionLessThan3(boolean ageExclusionLessThan3) {
        this.ageExclusionLessThan3 = ageExclusionLessThan3;
    }

    @Basic
    @Column(name = "Age")
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Basic
    @Column(name = "AgeGroupId")
    public int getAgeGroupId() {
        return ageGroupId;
    }

    public void setAgeGroupId(int ageGroupId) {
        this.ageGroupId = ageGroupId;
    }

    @Basic
    @Column(name = "MetalLevel")
    public String getMetalLevel() {
        return metalLevel;
    }

    public void setMetalLevel(String metalLevel) {
        this.metalLevel = metalLevel;
    }

    @Basic
    @Column(name = "GroupPlanType")
    public String getGroupPlanType() {
        return groupPlanType;
    }

    public void setGroupPlanType(String groupPlanType) {
        this.groupPlanType = groupPlanType;
    }

    @Basic
    @Column(name = "State")
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Basic
    @Column(name = "AttributedPractitionerId")
    public int getAttributedPractitionerId() {
        return attributedPractitionerId;
    }

    public void setAttributedPractitionerId(int attributedPractitionerId) {
        this.attributedPractitionerId = attributedPractitionerId;
    }

    @Basic
    @Column(name = "WinningEnrollmentId")
    public long getWinningEnrollmentId() {
        return winningEnrollmentId;
    }

    public void setWinningEnrollmentId(long winningEnrollmentId) {
        this.winningEnrollmentId = winningEnrollmentId;
    }

    @Basic
    @Column(name = "NoPreviousIntervention")
    public boolean isNoPreviousIntervention() {
        return noPreviousIntervention;
    }

    public void setNoPreviousIntervention(boolean noPreviousIntervention) {
        this.noPreviousIntervention = noPreviousIntervention;
    }

    @Basic
    @Column(name = "PastEFIntervention")
    public boolean isPastEfIntervention() {
        return pastEfIntervention;
    }

    public void setPastEfIntervention(boolean pastEfIntervention) {
        this.pastEfIntervention = pastEfIntervention;
    }

    @Basic
    @Column(name = "PastSMEIntervention")
    public boolean isPastSmeIntervention() {
        return pastSmeIntervention;
    }

    public void setPastSmeIntervention(boolean pastSmeIntervention) {
        this.pastSmeIntervention = pastSmeIntervention;
    }

    @Basic
    @Column(name = "PcpVisit")
    public boolean isPcpVisit() {
        return pcpVisit;
    }

    public void setPcpVisit(boolean pcpVisit) {
        this.pcpVisit = pcpVisit;
    }

    @Basic
    @Column(name = "TotalReachAttempts")
    public int getTotalReachAttempts() {
        return totalReachAttempts;
    }

    public void setTotalReachAttempts(int totalReachAttempts) {
        this.totalReachAttempts = totalReachAttempts;
    }

    @Basic
    @Column(name = "SuccessfulReachAttempts")
    public int getSuccessfulReachAttempts() {
        return successfulReachAttempts;
    }

    public void setSuccessfulReachAttempts(int successfulReachAttempts) {
        this.successfulReachAttempts = successfulReachAttempts;
    }

    @Basic
    @Column(name = "NotReached")
    public int getNotReached() {
        return notReached;
    }

    public void setNotReached(int notReached) {
        this.notReached = notReached;
    }

    @Basic
    @Column(name = "ReachRateCategoryId")
    public int getReachRateCategoryId() {
        return reachRateCategoryId;
    }

    public void setReachRateCategoryId(int reachRateCategoryId) {
        this.reachRateCategoryId = reachRateCategoryId;
    }

    @Basic
    @Column(name = "CompletedEFSoapNote")
    public boolean isCompletedEfSoapNote() {
        return completedEfSoapNote;
    }

    public void setCompletedEfSoapNote(boolean completedEfSoapNote) {
        this.completedEfSoapNote = completedEfSoapNote;
    }

    @Basic
    @Column(name = "Institutional")
    public Boolean getInstitutional() {
        return institutional;
    }

    public void setInstitutional(Boolean institutional) {
        this.institutional = institutional;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MemberAttributesEntity that = (MemberAttributesEntity) o;

        if (memberAttributesId != that.memberAttributesId) return false;
        if (memberAttributesRunId != that.memberAttributesRunId) return false;
        if (memberId != that.memberId) return false;
        if (missingProfile != that.missingProfile) return false;
        if (newEnrollee != that.newEnrollee) return false;
        if (termed != that.termed) return false;
        if (missingLastName != that.missingLastName) return false;
        if (missingFirstName != that.missingFirstName) return false;
        if (missingDateOfBirth != that.missingDateOfBirth) return false;
        if (currentlyEnrolled != that.currentlyEnrolled) return false;
        if (deceased != that.deceased) return false;
        if (hospice != that.hospice) return false;
        if (homebound != that.homebound) return false;
        if (ageExclusionLessThan3 != that.ageExclusionLessThan3) return false;
        if (age != that.age) return false;
        if (ageGroupId != that.ageGroupId) return false;
        if (attributedPractitionerId != that.attributedPractitionerId) return false;
        if (winningEnrollmentId != that.winningEnrollmentId) return false;
        if (noPreviousIntervention != that.noPreviousIntervention) return false;
        if (pastEfIntervention != that.pastEfIntervention) return false;
        if (pastSmeIntervention != that.pastSmeIntervention) return false;
        if (pcpVisit != that.pcpVisit) return false;
        if (totalReachAttempts != that.totalReachAttempts) return false;
        if (successfulReachAttempts != that.successfulReachAttempts) return false;
        if (notReached != that.notReached) return false;
        if (reachRateCategoryId != that.reachRateCategoryId) return false;
        if (completedEfSoapNote != that.completedEfSoapNote) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;
        if (ageGroup != null ? !ageGroup.equals(that.ageGroup) : that.ageGroup != null) return false;
        if (metalLevel != null ? !metalLevel.equals(that.metalLevel) : that.metalLevel != null) return false;
        if (groupPlanType != null ? !groupPlanType.equals(that.groupPlanType) : that.groupPlanType != null)
            return false;
        if (state != null ? !state.equals(that.state) : that.state != null) return false;
        if (institutional != null ? !institutional.equals(that.institutional) : that.institutional != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = memberAttributesId;
        result = 31 * result + memberAttributesRunId;
        result = 31 * result + memberId;
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (missingProfile ? 1 : 0);
        result = 31 * result + (newEnrollee ? 1 : 0);
        result = 31 * result + (termed ? 1 : 0);
        result = 31 * result + (missingLastName ? 1 : 0);
        result = 31 * result + (missingFirstName ? 1 : 0);
        result = 31 * result + (missingDateOfBirth ? 1 : 0);
        result = 31 * result + (currentlyEnrolled ? 1 : 0);
        result = 31 * result + (deceased ? 1 : 0);
        result = 31 * result + (hospice ? 1 : 0);
        result = 31 * result + (homebound ? 1 : 0);
        result = 31 * result + (ageGroup != null ? ageGroup.hashCode() : 0);
        result = 31 * result + (ageExclusionLessThan3 ? 1 : 0);
        result = 31 * result + age;
        result = 31 * result + ageGroupId;
        result = 31 * result + (metalLevel != null ? metalLevel.hashCode() : 0);
        result = 31 * result + (groupPlanType != null ? groupPlanType.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + attributedPractitionerId;
        result = 31 * result + (int) (winningEnrollmentId ^ (winningEnrollmentId >>> 32));
        result = 31 * result + (noPreviousIntervention ? 1 : 0);
        result = 31 * result + (pastEfIntervention ? 1 : 0);
        result = 31 * result + (pastSmeIntervention ? 1 : 0);
        result = 31 * result + (pcpVisit ? 1 : 0);
        result = 31 * result + totalReachAttempts;
        result = 31 * result + successfulReachAttempts;
        result = 31 * result + notReached;
        result = 31 * result + reachRateCategoryId;
        result = 31 * result + (completedEfSoapNote ? 1 : 0);
        result = 31 * result + (institutional != null ? institutional.hashCode() : 0);
        return result;
    }
}

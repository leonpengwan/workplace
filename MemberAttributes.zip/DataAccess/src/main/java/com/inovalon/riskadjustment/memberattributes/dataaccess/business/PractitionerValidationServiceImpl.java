package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.annotation.LogAfterEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.PractitionerValidationEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.PractitionerValidationEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class PractitionerValidationServiceImpl implements PractitionerValidationService {
    @Autowired private PractitionerValidationEntityDao practitionerValidationEntityDao;
    @Autowired
    private LogWriter logWriter;
    @LogAfterEvents
    @Override
    public int persistPractitionerValidation(PractitionerValidationEntity practitionerValidationEntity){
        try{
            if(practitionerValidationEntity == null){
                System.out.println("json body empty for persist practitioner validation");
                return 1;
            }else {

                practitionerValidationEntityDao.save(practitionerValidationEntity);
                return 0;
            }
        }
        catch(DataIntegrityViolationException violationException){
            logWriter.info("MemberAttributes Persistence: PractitionerValidation for member id: "+ practitionerValidationEntity.getPractitionerId()
                    + " and MemberAttributesRunId: " + practitionerValidationEntity.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        }
        catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            return 99;
        }
    }
}

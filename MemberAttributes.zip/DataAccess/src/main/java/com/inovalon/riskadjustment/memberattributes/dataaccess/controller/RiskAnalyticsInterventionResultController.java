package com.inovalon.riskadjustment.memberattributes.dataaccess.controller;

import com.inovalon.riskadjustment.memberattributes.dataaccess.business.*;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberAttributesEntity;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberEvidenceStatusEntity;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberValidationEntity;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.PractitionerValidationEntity;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberAttributesEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberEvidenceStatusEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberValidationEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.PractitionerValidationEntityDao;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api
@RestController
@RequestMapping("/risk-analytics/intervention-result")
public class RiskAnalyticsInterventionResultController {
    @Autowired private MemberAttributesService memberAttributesService;
    @Autowired private MemberEvidenceStatusService memberEvidenceStatusService;
    @Autowired private MemberValidationService memberValidationService;
    @Autowired private PractitionerValidationService practitionerValidationService;

    @Autowired private MemberAttributesEntityDao memberAttributesEntityDao;

    @Autowired private MemberEvidenceStatusEntityDao memberEvidenceStatusEntityDao;
    @Autowired private MemberValidationEntityDao memberValidationEntityDao;
    @Autowired private PractitionerValidationEntityDao practitionerValidationEntityDao;

    @ApiOperation(value = "this method retrieves member attributes by run id")
    @RequestMapping(value = "/member-attributes", method = RequestMethod.GET)
    public List<MemberAttributesEntity> findMemberAttributes(){
        return memberAttributesEntityDao.findAll();
    }

    @ApiOperation(value = "this method saves data ")
    @RequestMapping(value = "/member-attributes", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public int persistMemberAttributes(@RequestBody MemberAttributesEntity memberAttributesEntity) throws Exception{

        return memberAttributesService.persistMemberAttributes(memberAttributesEntity);
    }


    @ApiOperation(value = "this method saves member evidence status data ")
    @RequestMapping(value = "/member-evidence-statuses", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public int persistMemberEvidence(@RequestBody List<MemberEvidenceStatusEntity> memberEvidenceStatusEntities) throws Exception{

        return memberEvidenceStatusService.persistMemberEvidence(memberEvidenceStatusEntities);
    }

    @ApiOperation(value = "this method saves member validation data ")
    @RequestMapping(value = "/member-validation", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public int persistMemberValidation(@RequestBody MemberValidationEntity memberValidationEntity) throws Exception{

        return memberValidationService.persistMemberValidation(memberValidationEntity);
    }

    @ApiOperation(value = "this method saves practitioner validation data ")
    @RequestMapping(value = "/practitioner-validation", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public int persistPractitionerValidation(@RequestBody PractitionerValidationEntity practitionerValidationEntity) throws Exception{

        return practitionerValidationService.persistPractitionerValidation(practitionerValidationEntity);
    }
}

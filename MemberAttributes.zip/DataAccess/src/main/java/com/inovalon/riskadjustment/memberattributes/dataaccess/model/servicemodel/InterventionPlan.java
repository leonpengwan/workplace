package com.inovalon.riskadjustment.memberattributes.dataaccess.model.servicemodel;

import java.sql.Timestamp;

public class InterventionPlan {
    private long interventionPlanId;
    private int planRunId;
    private int memberId;
    private String personId;
    private Integer interventionYear;
    private String interventionPlanDetail;
    private String createdBy;
    private Timestamp createdDate;
    private String modifiedBy;
    private Timestamp modifiedDate;


    public long getInterventionPlanId() {
        return interventionPlanId;
    }

    public void setInterventionPlanId( long interventionPlanId ) {
        this.interventionPlanId = interventionPlanId;
    }


    public int getPlanRunId() {
        return planRunId;
    }

    public void setPlanRunId( int planRunId ) {
        this.planRunId = planRunId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId( int memberId ) {
        this.memberId = memberId;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId( String personId ) {
        this.personId = personId;
    }

    public Integer getInterventionYear() {
        return interventionYear;
    }

    public void setInterventionYear( Integer interventionYear ) {
        this.interventionYear = interventionYear;
    }

    public String getInterventionPlanDetail() {
        return interventionPlanDetail;
    }

    public void setInterventionPlanDetail( String interventionPlanDetail ) {
        this.interventionPlanDetail = interventionPlanDetail;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy( String createdBy ) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate( Timestamp createdDate ) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy( String modifiedBy ) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate( Timestamp modifiedDate ) {
        this.modifiedDate = modifiedDate;
    }

    @Override
    public boolean equals( Object o ) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InterventionPlan that = (InterventionPlan) o;

        if (interventionPlanId != that.interventionPlanId) return false;
        if (planRunId != that.planRunId) return false;
        if (memberId != that.memberId) return false;
        if (personId != null ? !personId.equals(that.personId) : that.personId != null) return false;
        if (interventionYear != null ? !interventionYear.equals(that.interventionYear) : that.interventionYear != null)
            return false;
        if (interventionPlanDetail != null ? !interventionPlanDetail.equals(that.interventionPlanDetail) : that.interventionPlanDetail != null)
            return false;
        if (createdBy != null ? !createdBy.equals(that.createdBy) : that.createdBy != null) return false;
        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (modifiedBy != null ? !modifiedBy.equals(that.modifiedBy) : that.modifiedBy != null) return false;
        if (modifiedDate != null ? !modifiedDate.equals(that.modifiedDate) : that.modifiedDate != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (interventionPlanId ^ (interventionPlanId >>> 32));
        result = 31 * result + planRunId;
        result = 31 * result + memberId;
        result = 31 * result + (personId != null ? personId.hashCode() : 0);
        result = 31 * result + (interventionYear != null ? interventionYear.hashCode() : 0);
        result = 31 * result + (interventionPlanDetail != null ? interventionPlanDetail.hashCode() : 0);
        result = 31 * result + (createdBy != null ? createdBy.hashCode() : 0);
        result = 31 * result + (createdDate != null ? createdDate.hashCode() : 0);
        result = 31 * result + (modifiedBy != null ? modifiedBy.hashCode() : 0);
        result = 31 * result + (modifiedDate != null ? modifiedDate.hashCode() : 0);
        return result;
    }
}

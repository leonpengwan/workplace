package com.inovalon.riskadjustment.memberattributes.dataaccess.controller;

import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.business.InterventionPlanService;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model.InterventionPlanData;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model.InterventionPlanEntity;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(value="risk-analytics/intervention-plan-result")
@Api
public class RiskAnalyticsPlanResultController {

    @Autowired
    private InterventionPlanService interventionPlanService;
    @Autowired
    private LogWriter logWriter;


    @ApiOperation(value = "This method used to get the interventionPlan data")
    @CrossOrigin
    @RequestMapping(value = "/intervention-plans", method = RequestMethod.POST, produces = "application/json")
    public List<InterventionPlanEntity> retrieveInterventionPlans( @RequestBody InterventionPlanData interventionPlanData)throws Exception{

        try {
            return interventionPlanService.getInterventionPlanData(interventionPlanData.getInterventionPlanRunIds());
        } catch (Exception ex) {
            logWriter.error(ex.getMessage(),ex);
            throw ex;
        }

    }

}
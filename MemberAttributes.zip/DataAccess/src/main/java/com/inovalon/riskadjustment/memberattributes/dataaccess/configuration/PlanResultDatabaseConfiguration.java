package com.inovalon.riskadjustment.memberattributes.dataaccess.configuration;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;


@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.dao"},
        entityManagerFactoryRef = "interventionPlanResultManagerFactory",
        transactionManagerRef = "interventionPlanResultTransactionManager"
)
public class PlanResultDatabaseConfiguration {


    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-connection-string}")
    private String interventionPlanResultDatabaseUrl;
    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-username}")
    private String interventionPlanResultDatabaseUsername;
    @Value("${inovalon.risk-adjustment.database.intervention-plan-result-password}")
    private String interventionPlanResultDatabasePassword;
    @Value("${spring.jpa.show-sql}")
    private String jpaShowSQL;


    public String getInterventionPlanResultDatabaseUrl() {
        return this.interventionPlanResultDatabaseUrl;
    }

    public String getInterventionPlanResultDatabaseUsername() {
        return this.interventionPlanResultDatabaseUsername;
    }

    public String getInterventionPlanResultDatabasePassword() {
        return this.interventionPlanResultDatabasePassword;
    }

    @Override
    public String toString() {
        return "PlanResultDatabaseConfiguration{" +
                "interventionPlanResultDatabaseUrl='" + interventionPlanResultDatabaseUrl + '\'' +
                '}';
    }

    @Primary
    @Bean(name = "interventionPlanResultDataSource")
    public DataSource interventionResultDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(interventionPlanResultDatabaseUrl);
        dataSource.setUsername(interventionPlanResultDatabaseUsername);
        dataSource.setPassword(interventionPlanResultDatabasePassword);
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(10);
        dataSource.setIdleTimeout(10);
        return dataSource;
    }

    @Primary
    @Bean(name = "interventionPlanResultManagerFactory")
    public LocalContainerEntityManagerFactoryBean interventionPlanResultEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(interventionResultDataSource());
        em.setPackagesToScan(new String[]{"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.planresultdb.model"});
        HibernateJpaVendorAdapter jpaVendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(jpaVendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLServer2012Dialect");
        properties.put("hibernate.show_sql", jpaShowSQL);
        em.setJpaPropertyMap(properties);
        em.setPersistenceUnitName("interventionresultdb");
        return em;
    }

    @Primary
    @Bean(name = "interventionPlanResultTransactionManager")
    public PlatformTransactionManager interventionPlanResultTransactionManager() {
        return new JpaTransactionManager(interventionPlanResultEntityManagerFactory().getObject());
    }
}



package com.inovalon.riskadjustment.memberattributes.dataaccess.business;

import com.inovalon.riskadjustment.annotation.LogBeforeEvents;
import com.inovalon.riskadjustment.logger.LogWriter;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao.MemberAttributesEntityDao;
import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberAttributesEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class MemberAttributesServiceImpl implements MemberAttributesService {
    @Autowired private MemberAttributesEntityDao memberAttributesEntityDao;
    @Autowired
    private LogWriter logWriter;
    @LogBeforeEvents
    @Override
    public int persistMemberAttributes(MemberAttributesEntity memberAttributesEntity){
        try{
            if(memberAttributesEntity == null){
                logWriter.info("json body empty for persist member attributes");
                return 1;
            }else {
                memberAttributesEntityDao.save(memberAttributesEntity);
                return 0;
            }
        }
        catch(DataIntegrityViolationException violationException){
            logWriter.info("MemberAttributes Persistence: MemberAttributes for member id: "+ memberAttributesEntity.getMemberId()
                    + " and MemberAttributesrunId: " + memberAttributesEntity.getMemberAttributesRunId()
                    + " already existed in table");
            return 2;
        }
        catch (Exception ex){
            logWriter.error(ex.getMessage(),ex);
            return 99;
        }
    }
}

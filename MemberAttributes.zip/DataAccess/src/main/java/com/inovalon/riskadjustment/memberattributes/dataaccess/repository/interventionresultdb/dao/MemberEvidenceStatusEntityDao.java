package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberEvidenceStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MemberEvidenceStatusEntityDao extends JpaRepository<MemberEvidenceStatusEntity, Integer> {

}

package com.inovalon.riskadjustment.memberattributes.dataaccess.configuration;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.dao"},
        entityManagerFactoryRef = "gapResultEntityManagerFactory",
        transactionManagerRef = "gapResultTransactionManager"
)
public class GapResultDatabaseConfiguration {
    @Value("${inovalon.risk-adjustment.database.gap-result-connection-string}")
    private String gapResultsDatabaseUrl;

    @Value("${inovalon.risk-adjustment.database.gap-result-username}")
    private String gapResultsDatabaseUsername;

    @Value("${inovalon.risk-adjustment.database.gap-result-password}")
    private String gapResultsDatabasePassword;
    @Value("${spring.jpa.show-sql}")
    private String jpaShowSQl;

    public String getGapResultsDatabaseUrl() {
        return gapResultsDatabaseUrl;
    }

    public String getGapResultsDatabaseUsername() {
        return gapResultsDatabaseUsername;
    }

    public String getGapResultsDatabasePassword() {
        return gapResultsDatabasePassword;
    }

    public String getJpaShowSQl() {
        return jpaShowSQl;
    }

    @Override
    public String toString() {
        return "GapResultDatabaseConfiguration{" +
                "gapResultsDatabaseUrl='" + gapResultsDatabaseUrl + '\'' +
                '}';
    }

    @Bean(name = "gapResultDataSource")
    public DataSource interventionResultDataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(getGapResultsDatabaseUrl());
        dataSource.setUsername(getGapResultsDatabaseUsername());
        dataSource.setPassword(getGapResultsDatabasePassword());
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setMaximumPoolSize(10);
        dataSource.setIdleTimeout(10);
        return dataSource;
    }


    @Bean(name = "gapResultEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean interventionResultEntityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(interventionResultDataSource());
        em.setPackagesToScan(new String[]{"com.inovalon.riskadjustment.memberattributes.dataaccess.repository.gapresultdb.model"});
        HibernateJpaVendorAdapter jpaVendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(jpaVendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLServer2012Dialect");
        properties.put("hibernate.show_sql", jpaShowSQl);
        em.setJpaPropertyMap(properties);
        em.setPersistenceUnitName("gapresultdb");
        return em;
    }


    @Bean(name = "interventionResultTransactionManager")
    public PlatformTransactionManager interventionResultTransactionManager() {
        return new JpaTransactionManager(interventionResultEntityManagerFactory().getObject());
    }
}

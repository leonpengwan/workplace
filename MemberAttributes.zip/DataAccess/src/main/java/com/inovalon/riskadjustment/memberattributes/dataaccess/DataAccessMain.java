package com.inovalon.riskadjustment.memberattributes.dataaccess;

import com.inovalon.riskadjustment.memberattributes.dataaccess.configuration.GapResultDatabaseConfiguration;
import com.inovalon.riskadjustment.memberattributes.dataaccess.configuration.InterventionResultDatabaseConfiguration;
import com.inovalon.riskadjustment.memberattributes.dataaccess.configuration.PlanResultDatabaseConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@SpringBootApplication
@ComponentScan(basePackages = {"com.inovalon.riskadjustment"})
public class DataAccessMain {

    public static void main(String[] args){
        SpringApplication.run(DataAccessMain.class, args);
    }

    @Autowired
    GapResultDatabaseConfiguration gapResultDatabaseConfiguration;

    @Autowired
    InterventionResultDatabaseConfiguration interventionResultDatabaseConfiguration;

    @Autowired
    PlanResultDatabaseConfiguration planResultDatabaseConfiguration;

    @PostConstruct
    private void initialize() {

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("+++++++++++++++++++ SERVICE STARTED  ++++++++++++++++++++++++++++");
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("gapResultDatabaseConfiguration :" + gapResultDatabaseConfiguration.toString());
        System.out.println("interventionResultDatabaseConfiguration :" + interventionResultDatabaseConfiguration.toString());
        System.out.println("planResultDatabaseConfiguration :" + planResultDatabaseConfiguration.toString());
    }
}

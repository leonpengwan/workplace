package com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.dao;


import com.inovalon.riskadjustment.memberattributes.dataaccess.repository.interventionresultdb.model.MemberAttributesEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MemberAttributesEntityDao extends JpaRepository<MemberAttributesEntity, Integer> {
    List<MemberAttributesEntity> findAll();
}
